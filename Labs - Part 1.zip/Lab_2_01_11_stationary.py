# In[18]:


import pandas as pd
import numpy as np

# =========================
# SIMULATION CONFIGURATION
# =========================

TOT_DAYS = 50
SIM_TIME = TOT_DAYS * 24 * 60
SIZE = 65
SEED = 42
np.random.seed(SEED)
center = (SIZE // 2, SIZE // 2)

# =========================
# CAR & STATION PARAMETERS
# =========================

CARS = 100
STATIONS = 5
MAX_PARK = 15
MAX_PARK_RECHARGE = 10
TIME_AUTONOMY = 50
RECHARGE_TIME = 30
MIN_DIST_STATION = 8
SIGMA = 9
BETA = 1.5

# =========================
# MOVEMENT & SPEED SETTINGS
# =========================

SPEED_CELLS_PER_TIME = 3.0
AVG_TIME_PER_CELL_WALK = 1.5
SIGMA_WALK = 0.2


# =========================
# CLIENT & DEMAND PARAMETERS
# =========================

NUM_CLIENTS = 20000
AVG_SERVICE_TIME = 20       # mu
ACCEPT_TRESHOLD = 10
TIME_TRESHOLD = 15
ARRIVAL_MEAN = 9

# =========================
# REPLACEMENT PARAMETERS
# =========================

REPLACEMENT_INTERVAL = 60.0
REPLACEMENT_INTERVAL_POS = 60.0
MAX_REPLACEMENT_PER_EVENT = 3
MAX_REPLACEMENT_POSITION = 5
RECORD_INTERVAL = 12*60


# =========================
# DISPLAY FUNCTION
# =========================

def display_config():
    """Display simulation configuration in structured tables."""

    def make_table(data):
        return pd.DataFrame(data, columns=["Parameter", "Description", "Value"])

    # Simulation configuration
    sim_config = make_table([
        ("TOT_DAYS", "Total simulation days", TOT_DAYS),
        ("SIM_TIME", "Total simulation time (minutes)", SIM_TIME),
        ("SIZE", "Grid size (NxN)", SIZE),
        ("center", "Grid center coordinates", center),
        ("SEED", "Random seed for reproducibility", SEED)
    ])

    # Car & stations
    car_station = make_table([
        ("CARS", "Total number of cars", CARS),
        ("STATIONS", "Number of charging stations", STATIONS),
        ("MAX_PARK", "Max normal parking spots per cell", MAX_PARK),
        ("MAX_PARK_RECHARGE", "Max charging parking spots per cell", MAX_PARK_RECHARGE),
        ("TIME_AUTONOMY", "Car autonomy (minutes)", TIME_AUTONOMY),
        ("RECHARGE_TIME", "Recharge time (minutes)", RECHARGE_TIME),
        ("MIN_DIST_STATION", "Minimum distance between stations", MIN_DIST_STATION),
        ("SIGMA", "Standard deviation for distribution", SIGMA),
        ("BETA", "Bias towards outer cells when choosing destination after service", BETA)
    ])

    # Movement
    movement = make_table([
        ("SPEED_CELLS_PER_TIME", "Average speed by car (cells/min)", SPEED_CELLS_PER_TIME),
        ("AVG_TIME_PER_CELL_WALK", "Walking time per cell (minutes)", AVG_TIME_PER_CELL_WALK),
    ])

    # Client & demand
    client_demand = make_table([
        ("NUM_CLIENTS", "Total number of clients", NUM_CLIENTS),
        ("AVG_SERVICE_TIME", "Average service time (minutes)", AVG_SERVICE_TIME),
        ("ACCEPT_TRESHOLD", "Maximum acceptable distance (cells)", ACCEPT_TRESHOLD),
        ("TIME_TRESHOLD", "Minimum remaining autonomy (time) for a car before it must go to recharge.", TIME_TRESHOLD),
        ("AVG_ARRIVAL_TIME", "Average arrival time (minutes)", ARRIVAL_MEAN)
    ])

    # Replacement
    replacement = make_table([
        ("REPLACEMENT_INTERVAL", "Replacement interval (minutes)", REPLACEMENT_INTERVAL),
        ("REPLACEMENT_INTERVAL_POS", "Position-based replacement interval (minutes)", REPLACEMENT_INTERVAL_POS),
        ("MAX_REPLACEMENT_PER_EVENT", "Max cars replaced per event", MAX_REPLACEMENT_PER_EVENT),
        ("MAX_REPLACEMENT_POSITION", "Max cars replaced by distance", MAX_REPLACEMENT_POSITION),
    ])



    # Display all tables
    from IPython.display import display, Markdown
    display(Markdown("###  Simulation Configuration")); display(sim_config)
    display(Markdown("###  Car & Station Parameters")); display(car_station)
    display(Markdown("###  Movement & Speed Settings")); display(movement)
    display(Markdown("###  Client & Demand Parameters")); display(client_demand)
    display(Markdown("###  Replacement Parameters")); display(replacement)


# =========================
# USAGE EXAMPLE
# =========================
display_config()


# In[19]:

from typing import Tuple, Optional, List
from collections import defaultdict

class Square:
    def __init__(self, position: Tuple[int, int], num_cars: int = 0, recharge: bool = False):
        """
        Represents a single cell (square) in the simulation grid.

        Args:
            position (Tuple[int, int]): Coordinates (i, j) of this square in the grid.
            num_cars (int, optional): Number of cars currently parked in the square. Defaults to 0.
            recharge (bool, optional): True if this square includes a charging station. Defaults to False.
        """
        self.position: Tuple[int, int] = position
        self.num_cars: int = num_cars
        self.recharge: bool = recharge

    def capacity(self, max_park: int = MAX_PARK, max_park_recharge: int = MAX_PARK_RECHARGE) -> int:
        """
        Returns the maximum parking capacity of this square.

        Args:
            max_park (int): Max cars allowed in a normal square.
            max_park_recharge (int): Max cars allowed in a recharge square.

        Returns:
            int: Maximum number of cars that can be parked here.
        """
        return max_park_recharge if self.recharge else max_park

    def can_add(self, n: int = 1, max_park: int = MAX_PARK, max_park_recharge: int = MAX_PARK_RECHARGE) -> bool:
        """
        Checks if n additional cars can be added without exceeding capacity.

        Args:
            n (int): Number of cars to add.
            max_park (int): Max cars allowed in a normal square.
            max_park_recharge (int): Max cars allowed in a recharge square.

        Returns:
            bool: True if there is enough capacity, False otherwise.
        """
        return self.num_cars + n <= self.capacity(max_park, max_park_recharge)

    def add_car(self, n: int = 1):
        """
        Adds n cars to the square.

        Args:
            n (int): Number of cars to add.
        """
        self.num_cars += n

    def remove_car(self, n: int = 1):
        """
        Removes n cars from the square (without allowing negative counts).

        Args:
            n (int): Number of cars to remove.
        """
        self.num_cars = max(0, self.num_cars - n)

    def __repr__(self) -> str:
        """
        Returns a concise string representation of the square, useful for debugging.
        """
        type_label = "Recharge" if self.recharge else "Normal"
        return f"<Square {type_label} pos={self.position}, num_cars={self.num_cars}>"

class Car:
    def __init__(
        self,
        car_id: int,
        position: Tuple[int, int],
        available: bool = True,
        time_left: float = TIME_AUTONOMY,
        to_recharge: bool = False
    ):
        """
        Represents a single car in the car-sharing simulation.

        Args:
            car_id (int): Unique identifier for the car.
            position (Tuple[int, int]): Current position of the car on the grid (row, column).
            available (bool, optional): True if the car is available for pickup. Defaults to True.
            time_left (float, optional): Remaining battery autonomy (in simulation time units). Defaults to TIME_AUTONOMY.
            to_recharge (bool, optional): True if the car must go to a recharge station. Defaults to False.
        """
        self.id: int = car_id
        self.position: Tuple[int, int] = position
        self.available: bool = available
        self.time_left: float = time_left
        self.to_recharge: bool = to_recharge

    def __repr__(self) -> str:
        """
        Returns a concise, human-readable string representation of the car.
        """
        return f"<Car id={self.id}, pos={self.position}, available={self.available}, time_left={self.time_left:.2f}, to_recharge={self.to_recharge}>"

class Client:
    def __init__(self, client_id: int, spawn_time: float, spawn_pos: Tuple[int, int]):
        """
        Represents a client requesting a car in the car-sharing simulation.

        Args:
            client_id (int): Unique client identifier.
            spawn_time (float): Time when the client appears (simulation time units).
            spawn_pos (Tuple[int, int]): Grid position where the client appears (row, column).
        """
        self.id: int = client_id
        self.spawn_time: float = spawn_time
        self.spawn_pos: Tuple[int, int] = spawn_pos

        # --- Dynamic attributes updated during simulation ---
        self.current_pos: Optional[Tuple[int, int]] = spawn_pos
        self.pickup_time: Optional[float] = None         # when the client is picked up
        self.dropoff_time: Optional[float] = None        # when the client is dropped off
        self.travel_time: Optional[float] = None         # duration of the car trip
        self.walk_time: Optional[float] = None           # time spent walking to the car
        self.walk_distance: Optional[float] = None       # distance walked to reach the car
        self.time_in_system: Optional[float] = None      # total time (walking + car)
        self.status: str = "waiting"                     # waiting, assigned, in_transit, completed, rejected, etc.
        self.assigned_car = None

    def assign_car(self, 
                   cars: List, 
                   AVG_time_per_cell_walk: int = AVG_TIME_PER_CELL_WALK):
        """
        Assigns the nearest available car to this client.
        Pickup time is proportional to the Manhattan distance between the client and the car.

        Args:
            cars (List): List of all cars in the simulation.
            time_per_cell_walk (int): Time (in simulation units) to walk one cell.
        """
        available_cars = [car for car in cars if car.available]

        # Reject if no cars are available
        if not available_cars:
            self.status = "rejected_no_car"
            return

        # Find the nearest available car (Manhattan distance)
        min_dist = float('inf')
        closest_car = None
        for car in available_cars:
            dist = abs(car.position[0] - self.spawn_pos[0]) + abs(car.position[1] - self.spawn_pos[1])
            if dist < min_dist:
                min_dist = dist
                closest_car = car

        # Reject if the nearest car exceeds the acceptable distance threshold
        if min_dist > ACCEPT_TRESHOLD:
            self.status = "rejected_too_far"
            return

        # Assign the car to the client
        closest_car.available = False
        self.assigned_car = closest_car
        self.walk_distance = min_dist
        self.status = "assigned"

        # walking time simulation
        walking_time = max(np.random.normal(AVG_time_per_cell_walk, SIGMA_WALK), 0.5)
        self.pickup_time = min_dist * walking_time      

    def choose_destination_from_service(self, 
                                        size: int = SIZE,
                                        speed: float = SPEED_CELLS_PER_TIME, 
                                        beta: float = BETA,
                                        avg_service_time: float = AVG_SERVICE_TIME):
        """
        Randomly selects a service duration and a reachable destination cell 
        based on the car's average speed and the simulated trip time.

        Args:
            size (int): Grid size.
            speed (float): speed by car
            beta (float): Bias factor to favor destinations near the border of the reachable area.
            avg_service_time (float): Mean service duration for the exponential distribution.

        Returns:
            Tuple[float, Tuple[int, int]]: (service_time, destination position)
        """
        # Determine speed
        speed_cells_per_time = speed

        # Sample service time from exponential distribution
        self.service_time = np.random.exponential(scale=avg_service_time)

        # Compute maximum travel distance (in grid cells)
        max_dist = max(0, int(round(speed_cells_per_time * self.service_time)))
        si, sj = self.spawn_pos

        # Generate all reachable cells with bias weighting
        cells = []
        weights = []
        for i in range(size):
            for j in range(size):
                dist = abs(i - si) + abs(j - sj)
                if dist <= max_dist:
                    cells.append((i, j))
                    weights.append((dist + 1) ** beta)

        # Normalize weights and sample a destination
        weights = np.array(weights, dtype=float)
        weights /= weights.sum()
        idx = np.random.choice(len(cells), p=weights)

        # Update attributes
        self.dest_pos = cells[idx]
        self.status = "in_transit"
        return self.service_time, self.dest_pos

class Measure:
    def __init__(self, total_days=TOT_DAYS, slot_hours=2):
        self.total_days = total_days
        self.slot_hours = slot_hours

        # --- cumulative performance metrics --- #
        self.total_walk_time = 0.0
        self.total_service_time = 0.0
        self.total_walk_distance = 0.0
        self.total_time_in_system = 0.0
        self.num_served = 0
        self.num_completed = 0  # optional: number of clients that completed a trip

        # --- time-slot tracking (e.g. 2-hour intervals) --- #
        self.service_time_by_slot = {
            slot: {"total": 0.0, "count": 0}
            for slot in range(int(24 / slot_hours))
        }

        # --- rejected clients --- #
        self.rejections_by_day = {}
        self.rejections_by_slot = {slot: 0 for slot in range(int(24 / slot_hours))}
        self.num_rejected = 0

        # --- unavailable cars tracking (e.g. 2-hours intervals) --- #
        self.unavailable_cars_by_slot = defaultdict(list)

        self.time_points = []
        self.unavailable_cars = []
        self.next_record_time = 0.0
        self.record_interval = RECORD_INTERVAL

        self.daily_avg_service_time = []
        self.daily_avg_walk_time = []
        self.daily_avg_walk_distance = []
        self.daily_time_points = []


    def record_unavailability(self, current_time, cars, next_record_attr='next_record_time'):
        if current_time >= getattr(self, next_record_attr):
            num_unavailable = sum(not c.available for c in cars)
            self.time_points.append(current_time)
            self.unavailable_cars.append(num_unavailable)
            setattr(self, next_record_attr, getattr(self, next_record_attr) + self.record_interval)


    # -------------------- UPDATE METHODS -------------------- #
    def update_rejection(self, status: str, event_time: float):
        """Update rejection counters by day and time slot."""
        if not status.startswith("rejected"):
            return  # skip if the client was not rejected

        self.num_rejected += 1

        day = int(event_time // (24 * 60)) + 1        # each day = 1440 minutes
        hour_of_day = (event_time / 60) % 24
        slot = int(hour_of_day // self.slot_hours)

        # increment counters
        self.rejections_by_day[day] = self.rejections_by_day.get(day, 0) + 1
        self.rejections_by_slot[slot] += 1

    def update_walk_time(self, walk_time: float):
        """Accumulate total walking time."""
        self.total_walk_time += walk_time

    def update_service_time(self, service_time: float, dropoff_time: float):
        """Accumulate total service time and update per-slot statistics."""
        self.total_service_time += service_time
        self.num_served += 1

        # identify 2-hour (or user-defined) slot of the day
        hour_of_day = (dropoff_time / 60) % 24
        slot = int(hour_of_day // self.slot_hours)

        self.service_time_by_slot[slot]["total"] += service_time
        self.service_time_by_slot[slot]["count"] += 1

    def update_walk_distance(self, walk_distance: float):
        """Accumulate total walking distance."""
        self.total_walk_distance += walk_distance

    def update_time_in_system(self, time_in_system: float):
        """Accumulate total time spent in the system (walking + driving)."""
        self.total_time_in_system += time_in_system
        self.num_completed += 1

    def record_unavailable_cars(self, t: float, cars: list):
        hour_of_day = (t / 60) % 24
        slot = int(hour_of_day // self.slot_hours)
        unavailable_count = sum(1 for c in cars if not c.available or getattr(c, "needs_recharge", False))
        self.unavailable_cars_by_slot[slot].append(unavailable_count)

        # per grafici continui
        self.time_points.append(t)
        self.unavailable_cars.append(unavailable_count)

    # -------------------- AVERAGES -------------------- #
    def avg_walk_time(self):
        """Return average walking time per served client."""
        return self.total_walk_time / self.num_served if self.num_served > 0 else 0

    def avg_service_time(self):
        """Return average car usage time per served client."""
        return self.total_service_time / self.num_served if self.num_served > 0 else 0

    def avg_service_time_by_slot(self):
        """Return a dictionary of average service times by time slot."""
        averages = {}
        for slot, data in self.service_time_by_slot.items():
            start_hour = slot * self.slot_hours
            end_hour = start_hour + self.slot_hours
            avg = data["total"] / data["count"] if data["count"] > 0 else 0
            averages[f"{start_hour:02d} - {end_hour:02d}"] = avg
        return averages

    def avg_walk_distance(self):
        """Return average walking distance per served client."""
        return self.total_walk_distance / self.num_served if self.num_served > 0 else 0

    def avg_time_in_system(self):
        """Return average total time (walk + drive) per completed client."""
        return self.total_time_in_system / self.num_completed if self.num_completed > 0 else 0

    def avg_unavailable_cars_by_slot(self):
        """Return a dictionary of average unavailable cars by time slot."""
        results = {}
        for slot, counts in sorted(self.unavailable_cars_by_slot.items()):
            start_hour = slot * self.slot_hours
            end_hour = start_hour + self.slot_hours
            mean_val = np.mean(counts) if counts else 0
            results[f"{start_hour:02d}-{end_hour:02d}"] = mean_val
        return results  
    # -------------------- REJECTIONS -------------------- #

    def get_rejections_by_day(self):
        """Return a dictionary {day: num_rejections} sorted by day."""
        return dict(sorted(self.rejections_by_day.items()))

    def get_rejections_by_slot(self):
        """Return a dictionary {time_slot: num_rejections} sorted by slot."""
        results = {}
        for slot, count in sorted(self.rejections_by_slot.items()):
            start_hour = slot * self.slot_hours
            end_hour = start_hour + self.slot_hours
            results[f"{start_hour:02d}-{end_hour:02d}"] = count
        return results

    def get_rejections_curve(self, total_days):
        """Return the number of rejections per day as a list."""
        days = list(range(total_days))
        values = [self.rejections_by_day.get(d, 0) for d in days]
        return days, values

    #  ------------------------------------------------------------------- #
    def record_daily_stats(self, current_time: float):
        """
        Registra le statistiche giornaliere. 
        current_time in minuti; calcola il giorno come intero.
        """
        day = int(current_time // (24*60))
        self.daily_time_points.append(day)
        self.daily_avg_service_time.append(self.avg_service_time())
        self.daily_avg_walk_time.append(self.avg_walk_time())
        self.daily_avg_walk_distance.append(self.avg_walk_distance())  




    # -------------------- SUMMARY -------------------- #
    def summary(self):
        """Return a complete summary of performance metrics."""
        return {
            "avg_walk_time": self.avg_walk_time(),
            "avg_service_time": self.avg_service_time(),
            "avg_walk_distance": self.avg_walk_distance(),
            "avg_time_in_system": self.avg_time_in_system(),
            "num_served": self.num_served,
            "num_rejected": self.num_rejected
        }


# In[20]:


### ----------- Other functions ------------ ##

def move_one_car(from_square: Square, to_square: Square, 
                 max_park: int = MAX_PARK, max_park_recharge: int = MAX_PARK_RECHARGE):
    """
    Moves one car from 'from_square' to 'to_square'.

    The function:
      - Checks that the origin square is not empty.
      - Checks that the destination square has available capacity.
      - Updates the number of cars in both squares accordingly.

    Parameters
    ----------
    from_square : Square
        The source cell from which the car will be moved.
    to_square : Square
        The destination cell where the car will be placed.
    max_park : int, optional
        Maximum capacity for normal squares (default = MAX_PARK).
    max_park_recharge : int, optional
        Maximum capacity for recharge-enabled squares (default = MAX_PARK_RECHARGE).
    """
    if from_square.num_cars == 0:
        # No cars available to move
        return

    # Only move if the destination has space
    if to_square.num_cars < to_square.capacity(max_park, max_park_recharge):
        from_square.num_cars -= 1
        to_square.num_cars += 1

def time_to_hhmm(t_sim: float):
    """
    Converts a simulation time (in minutes) into a human-readable string format.

    The output includes the simulation day and the time of day in HH:MM format.

    Parameters
    ----------
    t_sim : float
        Simulation time expressed in minutes.

    Returns
    -------
    str
        A formatted string like 'Day 3 14:25', representing the day and time.
    """
    total_minutes = int(t_sim)
    day = total_minutes // (24 * 60) + 1                # Day count starts from 1
    minutes_in_day = total_minutes % (24 * 60)          # Minutes elapsed within the current day
    hours = (minutes_in_day // 60) % 24                 # Extract hour of the day
    minutes = minutes_in_day % 60                       # Extract remaining minutes
    return f"Day {day} {hours:02d}:{minutes:02d}"

def build_gaussian_prob_distribution(size=SIZE, sigma=SIGMA):
    """
    Builds a 2D Gaussian probability distribution matrix.

    The matrix represents spatial probabilities centered in the middle of the grid,
    with values decreasing according to a Gaussian function.

    Parameters
    ----------
    size : int, optional
        The width and height of the grid (default is SIZE).
    sigma : float, optional
        The standard deviation controlling the spread of the Gaussian (default is SIGMA).

    Returns
    -------
    np.ndarray
        A 2D array of probabilities that sum to 1.
    """
    cx = cy = (size - 1) / 2.0                          # Center coordinates of the grid
    x = np.arange(size)
    y = np.arange(size)
    X, Y = np.meshgrid(x, y)                            # Create 2D coordinate grid
    gauss = np.exp(-(((X - cx)**2 + (Y - cy)**2) / (2 * sigma**2)))  # Gaussian function
    probs = gauss / gauss.sum()                         # Normalize to make it a probability distribution
    return probs

def is_valid_station(new_pos, existing_positions, min_distance=MIN_DIST_STATION):
    """
    Checks whether a new station position is valid based on a minimum distance constraint.

    A new position is valid if it is sufficiently far from all existing stations.

    Parameters
    ----------
    new_pos : tuple[int, int]
        Coordinates (x, y) of the candidate station.
    existing_positions : list[tuple[int, int]]
        List of existing station coordinates.
    min_distance : int, optional
        Minimum required distance between any two stations (default is MIN_DIST_STATION).

    Returns
    -------
    bool
        True if the new position is valid (no nearby stations), False otherwise.
    """
    for pos in existing_positions:
        # Check Chebyshev distance (max of x/y differences)
        if max(abs(new_pos[0] - pos[0]), abs(new_pos[1] - pos[1])) < min_distance:
            return False
    return True


# In[21]:


import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

def initialize_grid(size: int):
    """
    Create a 2D grid of Square objects.

    Parameters
    ----------
    size : int
        Grid dimension (size x size).

    Returns
    -------
    list[list[Square]]
        2D list of Square objects.
    """
    return [[Square((i, j)) for j in range(size)] for i in range(size)]

def place_stations(grid, probs, num_stations, min_distance, max_attempts_factor=50):
    """
    Place recharge stations in the grid using a probability distribution,
    ensuring a minimum distance between stations.

    Returns a list of station positions (tuples).
    """
    station_positions = []
    attempts = 0
    max_attempts = num_stations * max_attempts_factor

    while len(station_positions) < num_stations and attempts < max_attempts:
        index = np.random.choice(len(probs.ravel()), p=probs.ravel())
        i, j = divmod(index, len(grid))
        if (i, j) in station_positions:
            attempts += 1
            continue
        if is_valid_station((i, j), station_positions, min_distance):
            grid[i][j].recharge = True
            station_positions.append((i, j))
        attempts += 1

    if len(station_positions) < num_stations:
        print(f"Could not place all stations (constraints too strict).")
    else:
        print(f"Stations placed: {station_positions}")

    return station_positions

def place_cars(grid, probs, num_cars, max_attempts_factor=50):
    """
    Place cars in the grid probabilistically, respecting cell capacity.

    Returns a list of Car objects and updates the grid.
    """
    cars_placed = 0
    attempts = 0
    max_attempts = num_cars * max_attempts_factor

    size = len(grid)
    cars_list = []

    while cars_placed < num_cars and attempts < max_attempts:
        index = np.random.choice(size * size, p=probs.ravel())
        i, j = divmod(index, size)
        sq = grid[i][j]
        cap = MAX_PARK_RECHARGE if sq.recharge else MAX_PARK

        if sq.num_cars < cap:
            sq.add_car(1)
            car_id = len(cars_list)
            cars_list.append(Car(car_id=car_id, position=(i, j)))
            cars_placed += 1
        attempts += 1

    if cars_placed < num_cars:
        print(f"Only {cars_placed}/{num_cars} cars placed (capacity reached).")
    else:
        print(f"All {num_cars} cars placed successfully.")

    return cars_list

def visualize_grid(grid, station_positions, title="Car Distribution"):
    """
    Visualize the grid: number of cars per cell with recharge stations highlighted.
    """
    size = len(grid)
    car_counts = np.array([[sq.num_cars for sq in row] for row in grid])

    fig, ax = plt.subplots(figsize=(7, 7))
    im = ax.imshow(car_counts, origin='lower', interpolation='nearest', cmap="Blues")
    plt.colorbar(im, ax=ax, label="Number of cars")

    # plot stations
    xs = [j for (i, j) in station_positions]
    ys = [i for (i, j) in station_positions]
    ax.scatter(xs, ys, color="red", marker="x", s=100, label="Recharge stations")

    ax.set_xlim(-0.5, size - 0.5)
    ax.set_ylim(-0.5, size - 0.5)
    ax.set_title(title)
    ax.set_xlabel("Column")
    ax.set_ylabel("Row")
    ax.legend()
    plt.tight_layout()
    plt.show()

# --- MAIN SCRIPT --- #

# Initialize grid
grid = initialize_grid(SIZE)

# Compute Gaussian probabilities
probs = build_gaussian_prob_distribution(SIZE, SIGMA)

# Place recharge stations
station_positions = place_stations(grid, probs, STATIONS, MIN_DIST_STATION)

# Place cars
cars = place_cars(grid, probs, CARS)

# Visualize the grid
visualize_grid(grid, station_positions)


# In[22]:


def plot_grid(cars, client, SIZE, event_time, closest_car=None):
    """
    Visualizza la griglia con:
      - Verde: auto disponibili
      - Rosso: auto occupate
      - Giallo: auto selezionata come più vicina (se presente)
      - Blu: cliente rigettato (stellina)

    Griglia pulita, senza numeri sugli assi, con legenda.
    """

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.set_title(f"Client {client.id} rejected at {client.spawn_pos} (t={event_time:.1f})")

    # sfondo scacchiera leggero per dare struttura
    grid_bg = np.indices((SIZE, SIZE)).sum(axis=0) % 2
    ax.imshow(grid_bg, cmap="Greys", alpha=0.15, origin="lower")

    # plot client in blu (stellina)
    ax.scatter(client.spawn_pos[1] + 0.5, client.spawn_pos[0] + 0.5,
               marker='*', s=250, color='blue', label='Client')

    # macchine
    for car in cars:
        if closest_car is not None and car == closest_car:
            color = 'yellow'
        elif car.available:
            color = 'green'
        else:
            color = 'red'
        ax.scatter(car.position[1] + 0.5, car.position[0] + 0.5,
                   s=130, color=color)

    # limiti
    ax.set_xlim(0, SIZE)
    ax.set_ylim(0, SIZE)

    # griglia pulita
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_aspect("equal")
    ax.grid(True, linewidth=0.4, alpha=0.4)

    # legenda bella chiara
    legend_elements = [
        Patch(facecolor='green', edgecolor='black', label='Available car'),
        Patch(facecolor='red', edgecolor='black', label='Busy car'),
        Patch(facecolor='yellow', edgecolor='black', label='Closest available car'),
        Line2D([0], [0], marker='*', color='blue', label='Client', markersize=15, linestyle='None')
    ]
    ax.legend(handles=legend_elements, loc='upper right')

    plt.tight_layout()
    plt.show()



# In[23]:


import heapq

def handle_arrival(event_time: float, FES: list, clients: list, cars: list, SIZE: int, SPEED: float, measure):
    """
    Handles the arrival of a new client:
    - Creates the client at a spawn position
    - Assigns the nearest available car
    - Schedules the PICKUP event
    - If the client is rejected, visualizes the available cars on the grid
    """

    # Determine spawn position based on the probability distribution
    index = np.random.choice(SIZE * SIZE, p=probs.ravel())
    i = index // SIZE
    j = index % SIZE
    spawn_pos = (i, j)

    # Create new client
    client_id = len(clients)
    client = Client(client_id=client_id, spawn_time=event_time, spawn_pos=spawn_pos)
    client.current_pos = spawn_pos
    clients.append(client)

    # Assign the nearest available car
    client.assign_car(cars, AVG_time_per_cell_walk=AVG_TIME_PER_CELL_WALK)

    if client.status.startswith("rejected"):
        # Update rejection statistics
        measure.update_rejection(client.status, event_time)

        # Find the closest available car for visualization
        available_cars = [c for c in cars if c.available]
        closest_car = None
        if available_cars:
            distances = [np.linalg.norm(np.array(c.position) - np.array(client.spawn_pos)) for c in available_cars]
            closest_car = available_cars[int(np.argmin(distances))]

        # Plot the grid showing client and available cars
        # plot_grid(cars, client, SIZE, event_time, closest_car=closest_car)
        return

    # If client successfully assigned a car
    client.assigned_car.available = False

    # Schedule PICKUP event
    global event_counter
    event_counter += 1
    pickup_time = event_time + client.pickup_time
    heapq.heappush(FES, (pickup_time, event_counter, "pickup", {"client": client}))

def handle_pickup(event_time: float,
                  FES: list,
                  payload: dict,
                  measure):
    """
    Handle a PICKUP event for a client.

    - payload must contain {'client': Client}
    - Updates client status to 'in_transit'
    - Ensures car is at client's spawn position
    - Samples service time and chooses destination if not already set
    - Schedules DROP-OFF event
    - Updates walking statistics
    """
    client = payload.get("client")
    if client is None:
        raise ValueError("handle_pickup: payload must contain 'client'")

    if client.assigned_car is None:
        client.status = "rejected"
        print(f"[{event_time:.2f}] PICKUP: Client {client.id} has no assigned car -> rejected")
        return

    car = client.assigned_car
    client.current_pos = car.position
    client.status = "in_transit"
    client.pickup_time = event_time

    #  Update walking statistics 
    client.walk_time = event_time - client.spawn_time
    client.walk_distance = abs(car.position[0] - client.spawn_pos[0]) + abs(car.position[1] - client.spawn_pos[1])
    measure.update_walk_time(client.walk_time)
    measure.update_walk_distance(client.walk_distance)

    # Choose destination and service time if not already set
    if client.travel_time is None or client.dest_pos is None:
        client.choose_destination_from_service(beta=BETA, avg_service_time=AVG_SERVICE_TIME)

    #  Schedule DROP-OFF event 
    global event_counter
    event_counter += 1
    dropoff_time = event_time + client.service_time
    heapq.heappush(FES, (dropoff_time, event_counter, "dropoff", {'client': client}))

def handle_dropoff(event_time: float,
                   payload: dict,
                   grid,
                   measure):
    """
    Handles a DROP-OFF event for a client.

    Steps:
    - Extract the client from the payload
    - Update client and car positions
    - Mark the client as 'completed'
    - Free the car if enough time left, otherwise mark it for recharge
    - Update statistics: time in system, service time
    - Move the car physically in the grid

    Parameters:
    - event_time: current simulation time
    - payload: expected {'client': Client}
    - grid
    - measure: statistics collector
    """

    # Extract client
    client = payload.get("client")
    if client is None:
        raise ValueError("handle_dropoff: payload must contain 'client'")

    car = client.assigned_car
    if car is None:
        print(f"[{event_time:.2f}] DROPOFF: client {client.id} has no assigned car (ignored).")
        return

    # Update client status and position
    client.current_pos = client.dest_pos
    client.dropoff_time = event_time
    client.status = "completed"
    client.travel_time = client.dropoff_time - client.pickup_time
    client.time_in_system = client.dropoff_time - client.spawn_time

    # Update statistics
    measure.update_time_in_system(client.time_in_system)
    measure.update_service_time(client.travel_time, client.dropoff_time)

    # Update car remaining time
    car.time_left -= client.service_time

    # Get grid squares for move
    old_i, old_j = car.position
    dest_i, dest_j = client.dest_pos
    car_cell_from = grid[old_i][old_j]
    car_cell_to = grid[dest_i][dest_j]

    # Check if car needs recharge
    if car.time_left < TIME_TRESHOLD:
        car.available = False
        car.to_recharge = True
    else:
        car.available = True

    # Move the car physically in the grid
    move_one_car(car_cell_from, car_cell_to, max_park=MAX_PARK, max_park_recharge=MAX_PARK_RECHARGE)

    # Update car object position
    car.position = (dest_i, dest_j)

def handle_recharge_replacement_check(current_time: float, FES: list, cars: list, center=center):
    """
    Check for cars that need replacement due to low battery and schedule replacement events.

    - Only performs replacements during low-demand hours.
    - Schedules a future check after REPLACEMENT_INTERVAL minutes.
    - Selects up to MAX_REPLACEMENT_PER_EVENT cars farthest from the center that need recharge.

    Parameters:
    - current_time: current simulation time (minutes)
    - FES: Future Event Schedule (heapq)
    - cars: list of all Car objects
    - center: tuple (i,j) representing the "center" of the grid
    """
    global event_counter

    # Schedule next replacement check
    event_counter += 1
    heapq.heappush(FES, (current_time + REPLACEMENT_INTERVAL, event_counter, "recharge replacement check", {}))


    # Filter cars that require recharge
    low_battery_cars = [car for car in cars if car.to_recharge]

    if not low_battery_cars:
        return

    # Distance function from center
    def distance_from_center(car):
        return abs(car.position[0] - center[0]) + abs(car.position[1] - center[1])

    # Sort cars by distance from center (farther first)
    low_battery_cars.sort(key=distance_from_center, reverse=True)

    # Select up to MAX_REPLACEMENT_PER_EVENT cars
    cars_to_replace = low_battery_cars[:MAX_REPLACEMENT_PER_EVENT]

    # Schedule replacement events
    for car in cars_to_replace:
        event_counter += 1
        heapq.heappush(FES, (current_time, event_counter, "recharge replacement", {"car": car}))

def handle_recharge_replacement(current_time: float,
                                FES: list,
                                payload: dict,
                                grid,
                                stations: list,
                                speed: float = SPEED_CELLS_PER_TIME):
    """
    Handle the replacement/recharge process for a car with low autonomy.

    - Finds the nearest available charging station.
    - Simulates the movement time to reach it.
    - Updates the car's state and position.
    - Schedules the "start to charge" event.

    Parameters:
    - current_time: simulation time in minutes
    - FES: Future Event Schedule (heapq)
    - payload: dictionary containing {'car': Car}
    - grid: 2D grid of Square objects
    - stations: list of (i, j) tuples representing station coordinates
    - speed_day/speed_night: cell movement speed (different for day and night)
    """
    car = payload.get("car")
    if car is None:
        raise ValueError("handle_recharge_replacement: payload must contain 'car'")

    car.available = False  # car is now being replaced/recharged

    # --- Get current cell ---
    car_cell_from = grid[car.position[0]][car.position[1]]

    # --- Find closest station with available space ---
    def closest_available_station(car, stations):
        car_i, car_j = car.position
        min_dist = float('inf')
        closest = None
        for si, sj in stations:
            if grid[si][sj].num_cars < MAX_PARK_RECHARGE:
                dist = abs(car_i - si) + abs(car_j - sj)
                if dist < min_dist:
                    min_dist = dist
                    closest = (si, sj)
        return closest, min_dist

    closest_station, dist = closest_available_station(car, stations)

    if closest_station is None:
        return

    # --- Speed ---
    current_speed = speed

    # --- Simulate travel/replacement time ---
    mean_replacement_time = dist / current_speed
    replacement_time = max(
        np.random.normal(loc=mean_replacement_time, scale=0.2 * mean_replacement_time), 0.1
    )

    # --- Move car to station ---
    car_cell_to = grid[closest_station[0]][closest_station[1]]
    move_one_car(car_cell_from, car_cell_to, max_park=MAX_PARK, max_park_recharge=MAX_PARK_RECHARGE)
    car.position = closest_station

    # --- Update car status ---
    car.time_left = max(0, car.time_left - replacement_time)

    # --- Schedule start-to-charge event ---
    global event_counter
    event_counter += 1
    heapq.heappush(FES, (current_time + replacement_time, event_counter, "start recharge", {"car": car}))

def handle_start_recharge(time, FES, payload):
    """Handles the start of the car recharge process."""
    car = payload['car']

    global event_counter
    event_counter += 1

    # Schedule the end of recharge event
    heapq.heappush(FES, (time + RECHARGE_TIME, event_counter, "end recharge", {"car": car}))

def handle_end_recharge(payload):
    """Handles the end of the recharge process, making the car available again."""
    car = payload['car']

    car.available = True
    car.time_left = TIME_AUTONOMY
    car.to_recharge = False

def handle_periodic_replacement_check(time: float, FES: list, cars: list, 
                                      speed: float=SPEED_CELLS_PER_TIME):
    """
    Handle a PERIODIC REPLACEMENT CHECK event.

    - Every REPLACEMENT_INTERVAL minutes, selects the top N cars farthest from the city center.
    - The event runs only during low-demand hours.
    - Each selected car is marked unavailable and scheduled for relocation.
    """

    # --- Reschedule next periodic check ---
    global event_counter
    event_counter += 1
    heapq.heappush(FES, (time + REPLACEMENT_INTERVAL, event_counter, "periodic replacement check", {}))

    # speed
    current_speed = speed

    # --- Compute Manhattan distances from the city center ---
    distances = []
    for car in cars:
        distance = abs(car.position[0] - center[0]) + abs(car.position[1] - center[1])
        distances.append((car, distance))

    # --- Sort cars by descending distance ---
    distances.sort(key=lambda x: x[1], reverse=True)

    # --- Select top N cars for relocation ---
    cars_to_replace = [car for car, _ in distances[:MAX_REPLACEMENT_POSITION]]

    for car in cars_to_replace:
        car.available = False
        destination = None

        # --- Try up to 100 random cells to find a valid destination ---
        for _ in range(100):
            index = np.random.choice(SIZE * SIZE, p=probs.ravel())
            i, j = divmod(index, SIZE)
            dest_cell = grid[i][j]

            # Determine cell capacity
            cap = MAX_PARK_RECHARGE if dest_cell.recharge else MAX_PARK
            if dest_cell.num_cars < cap:
                destination = (i, j)
                break

        # --- Skip if no valid destination found ---
        if destination is None:
            car.available = True
            continue

        # --- Compute travel time ---
        old_pos = car.position
        road_distance = abs(destination[0] - old_pos[0]) + abs(destination[1] - old_pos[1])
        mean_replacement_time = road_distance / current_speed
        replacement_time = max(0.1, np.random.normal(
            loc=mean_replacement_time,
            scale=0.2 * mean_replacement_time
        ))

        # --- Schedule the PERIODIC REPLACEMENT event ---
        event_counter += 1
        heapq.heappush(FES, (time + replacement_time, event_counter, "periodic replacement",{"car": car, "destination": destination}))

def handle_periodic_replacement(time: float, payload: dict):
    """
    Handle a PERIODIC REPLACEMENT completion event.

    - Moves the car to its new grid cell.
    - Updates its position and marks it as available again.
    """

    # --- Extract payload data ---
    car = payload["car"]
    destination = payload["destination"]
    i, j = destination

    # --- Move car between cells ---
    cell_from = grid[car.position[0]][car.position[1]]
    cell_to = grid[i][j]
    move_one_car(cell_from, cell_to)

    # --- Update car state ---
    car.position = destination
    car.available = True


# In[24]:


# --- Initialization ---
FES: List[Tuple[float, int, str, dict]] = []   # Future Event Set (priority queue)
clients: List[Client] = []                     # List of all clients
sum_total_time: float = 0.0                    # Cumulative total time spent by served clients                            # Travel time scaling factor
event_counter: int = 0                         # Event ID counter
measure = Measure()                            # Object collecting performance metrics
served = 0
measure.record_interval = 24 * 60             # 12 hours in minutes for unavailable cars
measure.next_record_time_cars = 0.0                # start recording at t=0
measure.next_record_time_daily = 0.0

# --- Schedule initial arrivals ---
t = 0.0
for n in range(NUM_CLIENTS):
    mean_ia =  ARRIVAL_MEAN # Compute dynamic mean interarrival time
    ia = 0.0 if n == 0 else float(np.random.exponential(scale=mean_ia))
    t += ia
    event_counter += 1
    heapq.heappush(FES, (t, event_counter, "arrival", {"time": t}))

# --- Schedule replacement checks ---
event_counter += 1
heapq.heappush(FES, (0, event_counter, "recharge replacement check", {}))      # Immediate first recharge check
heapq.heappush(FES, (600, event_counter, "periodic replacement check", {}))    # Start at 10:00 (600 min)

# --- Main Simulation Loop ---
while FES:
    event_time, _, event_type, payload = heapq.heappop(FES)

    # Record of unavailable cars
    measure.record_unavailability(event_time, cars, next_record_attr = 'next_record_time_cars')

    # Stop conditions
    if event_time > SIM_TIME:
        print(f" Simulation reached the time limit ({SIM_TIME} min). Stopping.")
        break

    if served + measure.num_rejected >= NUM_CLIENTS:
        print("All clients processed. Stopping simulation.")
        FES.clear()
        break

    # Dentro il main loop, prima del processing dell’evento
    if event_time >= measure.next_record_time_daily:
        measure.record_daily_stats(measure.next_record_time_daily)
        measure.next_record_time_daily += 24*60  # passa al giorno successivo

    # === Event handling ===
    if event_type == "arrival":
        handle_arrival(event_time, FES, clients, cars, SIZE, probs, measure)

    elif event_type == "pickup":
        handle_pickup(event_time, FES, payload, measure)

    elif event_type == "dropoff":
        client_ref = payload.get("client")
        handle_dropoff(event_time, payload, grid, measure)

        # Update served statistics
        if client_ref is not None and client_ref.status == "completed":
            served += 1
            sum_total_time += (client_ref.dropoff_time - client_ref.spawn_time)
        # Aggiorna metriche giornaliere
        measure.update_walk_time(client_ref.walk_time)
        measure.update_walk_distance(client_ref.walk_distance)

    elif event_type == "recharge replacement check":
        handle_recharge_replacement_check(event_time, FES, cars)

    elif event_type == "recharge replacement":
        handle_recharge_replacement(event_time, FES, payload, grid, station_positions)

    elif event_type == "start recharge":
        car = payload["car"]
        handle_start_recharge(event_time, FES, payload)

    elif event_type == "end recharge":
        car = payload["car"]
        handle_end_recharge(payload)

    elif event_type == "periodic replacement check":
        handle_periodic_replacement_check(event_time, FES, cars, SPEED_CELLS_PER_TIME)

    elif event_type == "periodic replacement":
        handle_periodic_replacement(event_time, payload)

    else:
        print(f"⚠️ Unknown event type: {event_type}")

# Stat
measure.record_daily_stats(SIM_TIME)
summary_dict = measure.summary()
summary_df = pd.DataFrame(list(summary_dict.items()), columns=["Metric", "Value"])
print(summary_df)


# In[25]:


def detect_transient_end_gradient(ts, window, tol_grad, hold):
    """
    Detect the end of the transient phase using the gradient (first derivative) of the time series.

    Parameters:
    - ts: array-like, the time series (e.g. rolling mean).
    - window: size of the smoothing window (number of samples).
    - tol_grad: gradient magnitude threshold for stability.
    - hold: number of consecutive points below the threshold to confirm stabilization.

    Returns:
    - end_idx: index corresponding to the detected end of the transient phase, or None if not found.
    - info: dictionary containing the final gradient and mean statistics.
    """
    ts = np.asarray(ts, dtype=float)
    # --- Smooth the series slightly to reduce noise ---
    smoothed = np.convolve(ts, np.ones(window)/window, mode='same')

    # --- Compute numerical gradient ---
    grad = np.gradient(smoothed)

    # --- Find consecutive regions where the gradient magnitude is low ---
    stable_points = np.abs(grad) < tol_grad
    counter = 0
    for i, stable in enumerate(stable_points):
        if stable:
            counter += 1
            if counter >= hold:
                # Confirm stability (steady-state)
                return i, {
                    "mean_grad": np.mean(np.abs(grad[i-hold:i])),
                    "last_mean": np.mean(ts[i-hold:i])
                }
        else:
            counter = 0

    # --- If never found ---
    return None, {"mean_grad": None, "last_mean": None}



# In[26]:

times = np.array(measure.time_points)          
unavail = np.array(measure.unavailable_cars) 
time_days = times / (60 * 24)

# smoothing (rolling)
window_points = 24   
rolling = pd.Series(unavail).rolling(window=window_points, min_periods=1).mean()

df = pd.DataFrame({
    "time_days": time_days,
    "unavailable": unavail,
    "rolling_mean": rolling
})

end_idx, info = detect_transient_end_gradient(df['rolling_mean'].values,
                                              window=5,
                                              tol_grad=0.1,
                                              hold=1)

plt.figure(figsize=(10,5))
plt.plot(df['time_days'], df['rolling_mean'], color='black', label='5-day rolling mean')
plt.plot(df['time_days'], df['unavailable'], color='orange', alpha=0.4, label='Unavailable cars')

if end_idx is not None:
    end_day = df['time_days'].iloc[end_idx]
    plt.axvline(x=end_day, color='red', linestyle='--', label=f'Transient end ≈ day {end_day:.1f}')
    plt.text(end_day + 0.5, df['rolling_mean'].max()*0.9, f'Stabilization ≈ day {end_day:.1f}', color='red')

plt.xlabel("Time [days]")
plt.ylabel("Unavailable cars")
plt.title("Transient Phase Detection via Gradient")
plt.legend()
plt.grid(alpha=0.3)
plt.show()


# In[27]:


days, values = measure.get_rejections_curve(TOT_DAYS)

# Plot base series
plt.figure(figsize=(10, 5))
plt.plot(days, values, alpha=0.4, label='Daily rejections', color='C1')

# Rolling mean
window = 20
rolling = pd.Series(values).rolling(window=window, min_periods=1).mean()
plt.plot(days, rolling, color='black', linewidth=2, label=f'{window}-day rolling mean')

# Detect transient phase end (using gradient method)
end_idx, info_rej = detect_transient_end_gradient(rolling, window=5, tol_grad=0.1, hold=1)

if end_idx is not None:
    end_day = days[end_idx]
    plt.axvline(x=end_day, color='red', linestyle='--', label=f"Transient end ≈ day {end_day:.1f}")
    plt.text(end_day + 1, max(values) * 0.8, f"Stabilization ≈ day {end_day:.1f}", color='red')

plt.xlabel('Day')
plt.ylabel('Number of rejected requests')
plt.title('Rejected Clients Over Time (Gradient-based Transient Detection)')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()


# In[28]:


window = 3
smoothed_walk_time = pd.Series(measure.daily_avg_walk_time).rolling(window=window, center=True, min_periods=1).mean()
smoothed_walk_distance = pd.Series(measure.daily_avg_walk_distance).rolling(window=window, center=True, min_periods=1).mean()

days = measure.daily_time_points

# detect end transient phase
end_walk_time_idx, info_wt = detect_transient_end_gradient(smoothed_walk_time, window=3, tol_grad=0.1, hold=2)
end_walk_distance_idx, info_wd = detect_transient_end_gradient(smoothed_walk_distance, window=3, tol_grad=0.1, hold=2)


# PLot
def plot_single_metric(days, values, end_idx, label, color):
    plt.figure(figsize=(10, 3))
    plt.plot(days, values, color=color, marker='o', alpha=0.7, label=label)
    if end_idx is not None:
        xline = days[end_idx]
        plt.axvline(x=xline, color='red', linestyle='--', label=f"Transient end ≈ day {xline:.1f}")
        plt.text(xline + 0.5, np.nanmax(values) * 0.9, f"Stabilization ≈ day {xline:.0f}", color='red')
    plt.ylabel(label)
    plt.xlabel("Day")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.show()


plot_single_metric(days, smoothed_walk_time, end_walk_time_idx, "Avg Walk Time [min]", "C1")
plot_single_metric(days, smoothed_walk_distance, end_walk_distance_idx, "Avg Walk Distance [units]", "C2")


