from dataclasses import dataclass
from typing import Optional, List
import statistics
import numpy as np
import heapq
import matplotlib.pyplot as plt
import pandas as pd

@dataclass
class Measure:
    def __init__(self):
        
        # Time when the client arrives to the system
        self.arrivals: int = 0                  # number of arrivals
        self.departures: int = 0                # number of departures
        self.drops: int = 0                     # number of dropped arrivals due to capacity

        # time-average queue size bookkeeping (area under Q(t))
        self._old_time: Optional[float] = None
        self._area_under_q: float = 0.0
        self._last_q_len: int = 0

        # delays collected for departed clients
        self._delays: List[float] = []
    
    def update_time_average(self, now: float, q_len: int):
        """"Update the integral of Q(t).
        Attributes:
        - now: current simu time
        - q_len: current queue length
        """

        if self._old_time is None:
            # first client
            self._old_time = now
            self._last_q_len = q_len
            return

        dt = now - self._old_time
        if dt < 0:
            raise ValueError("time moved backwords in update_timeavg")
        
        # accumulate area under Q(t)
        self._area_under_q += self._last_q_len * dt

        # update state
        self._old_time = now
        self._last_q_len = q_len
    
    def record_arrival(self, now: float):
        """Record a new arrival"""
        self.arrivals += 1
    
    def record_departure(self, now: float, arrival_time: float):
        """Record a departure and store the client's delay:
        Attributes:
        - now: departure time
        - arrival_time: arrival time
        """
        self.departures += 1
        delay = now - arrival_time
        self._delays.append(delay)

    def record_drop(self, now: float):
        """Record a dropped arrival (queue capacity is full)"""
        self.drops += 1

    def last_step(self, end_sim_time: float):
        """To fill the last average integral: 
        
        During the simulation, every time an event happens (arrival or departure),
        the code updates the area under the queue length curve (integral) using the method.
        When simu stops, there still be a remainng time interval that hasn't been accounted
        for yet. The Last_step method fills this gap. 
        """
        if self._old_time is None:
            self._old_time = end_sim_time
            return
        
        dt = end_sim_time - self._old_time
        if dt < 0:
            raise ValueError("simu end time is earlier than _old_time event")
    
        self._area_under_q += self._last_q_len * dt
        self._old_time = end_sim_time

    @property
    def avg_delay(self) -> Optional[float]:
        """Return the sample mean of delays (None if no departures)."""
        if not self._delays:
            return None
        return statistics.mean(self._delays)


    @property
    def std_delay(self) -> Optional[float]:
        """Return the sample standard deviation of delays (None or 0.0 if insufficient data)."""
        if not self._delays:
            return None
        if len(self._delays) == 1:
            return 0.0
        return statistics.stdev(self._delays)
    
    def histogram(self, bins: int = 10):
        """Compute a histogram of client delays.

        Attributes:
        - bins: number of histogram bins.

        Returns a tuple with:
        - bin_boundaries (length = bins + 1)
        - counts: number of delays in each bin (length = bins)
        """

        if not self._delays:
            return([], [])

        counts, edges = np.histogram(self._delays, bins=bins)
        return edges.tolist(), counts.tolist()

    @property
    def avg_queue_size(self) -> Optional[float]:
        """Return the time-average queue size (E[Q]) computed as area / simulated time.


        Note: `finalize(sim_end_time)` should be called before requesting this.
        """
        if self._old_time is None or self._old_time == 0:
            return None
        total_time = self._old_time
        return self._area_under_q / total_time

    @property
    def loss_probability(self) -> Optional[float]:
        """Return the empirical drop (loss) probability: drops / arrivals."""
        if self.arrivals == 0:
            return None
        return self.drops / self.arrivals

    
# ------------------------------- #
# Simulation parameters (case 1)  #
# --------------------------------#
SERVICE_RATE = 1                    # mu       
ARRIVAL_RATE = 1.2 * SERVICE_RATE   # lambda  
SIM_TIME = 10000
MAX_CAPACITY = 1000                 # maximum queue length
np.random.seed(42)                

# ------------------------------- #
# Events funcions --------------- #
# ------------------------------- #
def arrival(time: float, measure: Measure, arrival_times: dict):
    """Handle a client arrival at the given simulation time.
    
    Parameters.
    time: current simulation time.
    FES: Future Event Set.
    que: current queue.
    measure: Measure
    client: the arriving client.
    """
    global client_counter, server_busy
    client_counter += 1
    client_id = client_counter

    # update arrival times
    arrival_times[client_id] = time
    
    if len(que) < MAX_CAPACITY:
        que.append(client_id)             # store the arrival time

        # if server idle, start service immediately
        if not server_busy:
            server_busy = True
            service_time = np.random.exponential(1 / SERVICE_RATE)
            departure_time = time + service_time
            heapq.heappush(FES, (departure_time, "departure", client_id))
    else:
        measure.record_drop(time)


    # Schedule next arrival
    inter_arrival = np.random.exponential(1 / ARRIVAL_RATE)
    next_arrival_time = time + inter_arrival
    heapq.heappush(FES, (next_arrival_time, "arrival", client_id + 1))

def departure(time: float, measure: Measure, arrival_times: dict):
    """Handle a client departure at the given time.
    
    Parameters.
    time: current simu time.
    FES: Future Event Set.
    que: current queue.
    measure: Measure
    """
    global server_busy

    # verify if someone is in the queue
    if not que:
        server_busy = False
        return 
    
    # FIFO structure
    client_id = que.pop(0)

    # serve the next client
    if que:
        next_client_id = que[0]
        service_time = np.random.exponential(1 / SERVICE_RATE)
        next_departure_time = time + service_time
        heapq.heappush(FES, (next_departure_time, "departure", next_client_id))
    else:
        server_busy = False

# ------------------------------- #
# Detect transient phase -------- #
# ------------------------------- #
def detect_transient_end_slope(ts, window, tol_slope, hold, warmup):
    ts = np.asarray(ts, dtype=float)
    n = len(ts)
    for i in range(warmup, n - window * (hold + 1)):
        stable = True
        for h in range(hold):
            start = i + h * window
            end = start + window
            segment = ts[start:end]
            x = np.arange(window)
            a, _ = np.polyfit(x, segment, 1)
            if abs(a) >= tol_slope:
                stable = False
                break
        if stable:
            first_mean = np.mean(ts[i:i + window])
            last_mean = np.mean(ts[i + hold * window : i + (hold + 1) * window])
            if abs(last_mean - first_mean) / (abs(first_mean) + 1e-9) < 0.01:
                return i, {"slope": a, "first_mean": first_mean, "last_mean": last_mean}
    return None, {"slope": None}


# ------------------------------- #
# Simulation state variables ---- #
# ------------------------------- #
FES = []                
que = []   
server_busy = False
current_time = 0.0
client_counter = 0      
arrival_times = {}
measure = Measure()
sample_times = []
sample_q = []


# ---------------- Initialize Queue --------------------- #
que = []
client_counter = 0
arrival_times = {}    

server_busy = False

first_arrival_time = np.random.exponential(1 / ARRIVAL_RATE)
heapq.heappush(FES, (first_arrival_time, "arrival", None))

# --------------------------------- #
# Main simulation loop ------------ #
# --------------------------------- #

while FES:
    current_time, event_type, client_id = heapq.heappop(FES)

    # Stop condition (optional)
    if current_time > SIM_TIME:
        print(f"Simulation ended at time {current_time:.2f}")
        break

    measure.update_time_average(current_time, len(que))

    # Handle the event
    if event_type == "arrival":
        measure.record_arrival(current_time)
        arrival(current_time, measure, arrival_times)
    elif event_type == "departure":
        if client_id in arrival_times:
            measure.record_departure(current_time, arrival_times[client_id])
            del arrival_times[client_id]
        departure(current_time, measure, arrival_times)
    
    # for detecting the transient phase
    sample_times.append(current_time)
    sample_q.append(len(que))

measure.last_step(current_time)

# --------------------------------- #
# Final Statistics ---------------- #
# --------------------------------- #
summary_data = {
    "Clients in queue": [len(que)],
    "Arrivals": [measure.arrivals],
    "Departures": [measure.departures],
    "Dropped": [measure.drops],
    "Avg delay": [f"{measure.avg_delay:.3f}" if measure.avg_delay else "—"],
    "Avg queue size": [f"{measure.avg_queue_size:.3f}" if measure.avg_queue_size else "—"],
    "Loss probability": [f"{measure.loss_probability:.5f}" if measure.loss_probability else "—"]
}

summary_df = pd.DataFrame(summary_data)
print("\n--- Simulation Summary ---")
print(summary_df.to_string(index=False))

# histogram 
edges, counts = measure.histogram(bins=10)

plt.bar(edges[:-1], counts, width=np.diff(edges), align='edge', edgecolor='black')
plt.xlabel("Client delay")
plt.ylabel("Number of clients")
plt.title("Histogram of client delays")
plt.show()

qlens = np.array(sample_q)

# Compute the end of the transient phase
t0_idx, info = detect_transient_end_slope(qlens, window=200, tol_slope=0.02, hold=10, warmup=1000)

# Visualization
plt.figure(figsize=(10, 5))
plt.plot(sample_times, qlens, label="Queue length")
if t0_idx is not None:
    plt.axvline(sample_times[t0_idx], color="red", linestyle="--", label=f"Transient end @ t={sample_times[t0_idx]:.1f}")
plt.xlabel("Time")
plt.ylabel("Queue length")
plt.legend()
plt.title("Detection of Transient End")
plt.show()

# ------------------------------------------------ #
# Final Statistics (without Transient phase) ----- #
# ------------------------------------------------ #
print("\n--- Steady-State Analysis ---")

if t0_idx is None:
    print("No transient end detected — cannot compute steady-state statistics.")
else:
    # Tempo (in minuti) corrispondente alla fine della transiente
    t0_time = sample_times[t0_idx]
    print(f"Transient phase ends at t ≈ {t0_time:.2f} minutes")

    # -----------------------------
    # 1) Filtriamo i ritardi raccolti dopo t0_time
    # -----------------------------
    steady_delays = [d for (arr_t, d) in zip(arrival_times.values(), measure._delays)
                     if arr_t >= t0_time]

    # -----------------------------
    # 2) Calcoliamo avg_delay in regime
    # -----------------------------
    if len(steady_delays) > 0:
        avg_delay_steady = np.mean(steady_delays)
    else:
        avg_delay_steady = None

    # -----------------------------
    # 3) Approssimiamo la queue size media in regime
    # -----------------------------
    # prendiamo solo i campioni dopo t0_idx
    qlens_steady = qlens[t0_idx:]
    sample_times_steady = sample_times[t0_idx:]

    if len(sample_times_steady) > 1:
        duration = sample_times_steady[-1] - sample_times_steady[0]
        avg_queue_size_steady = np.trapz(qlens_steady, sample_times_steady) / duration
    else:
        avg_queue_size_steady = None

    # -----------------------------
    # 4) Probabilità di perdita in regime
    # -----------------------------
    total_arrivals_after = sum(1 for t in arrival_times.values() if t >= t0_time)
    drops_after = sum(1 for _ in range(measure.drops))  # già conteggiati globalmente

    if total_arrivals_after > 0:
        loss_prob_steady = drops_after / total_arrivals_after
    else:
        loss_prob_steady = None

    # -----------------------------
    # OUTPUT FINALE
    # -----------------------------
    print("\n=== Steady-State Performance Estimates ===")
    print(f"Average Delay (W) ≈ {avg_delay_steady:.3f} minutes" if avg_delay_steady is not None else "Average Delay: N/A")
    print(f"Average Queue Size (E[Q]) ≈ {avg_queue_size_steady:.3f}" if avg_queue_size_steady is not None else "Avg Queue Size: N/A")
    print(f"Loss Probability ≈ {loss_prob_steady:.5f}" if loss_prob_steady is not None else "Loss Probability: N/A")

print("\n--- Theoretical vs Simulated Steady-State Comparison (M/M/1) ---")

# Teoretical values (∞ where system is unstable)
theoretical_results = {
    "Average delay W": [np.inf],
    "Average queue length E[Q]": [np.inf],
    "Average number in system L": [np.inf],
    "Steady-state existence": ["No (system diverges)"]
}

df_case2 = pd.DataFrame(theoretical_results)
print(df_case2.to_string(index=False))



