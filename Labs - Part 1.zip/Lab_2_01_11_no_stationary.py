# # Car Sharing

# In[171]:


import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

# =========================
# SIMULATION CONFIGURATION
# =========================

TOT_DAYS = 10
SIM_TIME = TOT_DAYS * 24 * 60
SIZE = 65
SEED = 42
center = (SIZE // 2, SIZE // 2)
np.random.seed(SEED)

# =========================
# CAR & STATION PARAMETERS
# =========================

CARS = 100
STATIONS = 5
MAX_PARK = 15
MAX_PARK_RECHARGE = 10
TIME_AUTONOMY = 50
RECHARGE_TIME = 30
MIN_DIST_STATION = 8
SIGMA = 9
BETA = 1.5

# =========================
# MOVEMENT & SPEED SETTINGS
# =========================

SPEED_CELLS_PER_TIME_DAY = 2.8
SPEED_CELLS_PER_TIME_NIGHT = 4.85
AVG_TIME_PER_CELL_WALK = 1.5
SIGMA_WALK = 0.2


# =========================
# CLIENT & DEMAND PARAMETERS
# =========================

NUM_CLIENTS = 20000
AVG_SERVICE_TIME = 20
ACCEPT_TRESHOLD = 10
TIME_TRESHOLD = 15

# =========================
# REPLACEMENT PARAMETERS
# =========================

REPLACEMENT_INTERVAL = 60.0
REPLACEMENT_INTERVAL_POS = 60.0
MAX_REPLACEMENT_PER_EVENT = 5
MAX_REPLACEMENT_POSITION = 3

# =========================
# DEMAND DYNAMICS
# =========================

LOW_DEMAND_HOURS = list(range(0, 8))  + list(range(20, 24))
HIGH_DEMAND = 5.0
LOW_DEMAND = 30.0

def dynamic_mean_ia(t):
    """
    This function controls the user arrival flow
    depending on the time of day.
    """
    hour = int((t / 60) % 24)
    if hour in LOW_DEMAND_HOURS:
        return LOW_DEMAND   # night → low arrivals
    else:
        return HIGH_DEMAND  # day → high arrivals


# =========================
# DISPLAY FUNCTION
# =========================

def display_config():
    """Display simulation configuration in structured tables."""

    def make_table(data):
        return pd.DataFrame(data, columns=["Parameter", "Description", "Value"])

    # Simulation configuration
    sim_config = make_table([
        ("TOT_DAYS", "Total simulation days", TOT_DAYS),
        ("SIM_TIME", "Total simulation time (minutes)", SIM_TIME),
        ("SIZE", "Grid size (NxN)", SIZE),
        ("center", "Grid center coordinates", center),
        ("SEED", "Random seed for reproducibility", SEED)
    ])

    # Car & stations
    car_station = make_table([
        ("CARS", "Total number of cars", CARS),
        ("STATIONS", "Number of charging stations", STATIONS),
        ("MAX_PARK", "Max normal parking spots per cell", MAX_PARK),
        ("MAX_PARK_RECHARGE", "Max charging parking spots per cell", MAX_PARK_RECHARGE),
        ("TIME_AUTONOMY", "Car autonomy (minutes)", TIME_AUTONOMY),
        ("RECHARGE_TIME", "Recharge time (minutes)", RECHARGE_TIME),
        ("MIN_DIST_STATION", "Minimum distance between stations", MIN_DIST_STATION),
        ("SIGMA", "Standard deviation for distribution", SIGMA),
        ("BETA", "Bias towards outer cells when choosing destination after service", BETA)
    ])

    # Movement
    movement = make_table([
        ("SPEED_CELLS_PER_TIME_DAY", "Speed during daytime (cells/min)", SPEED_CELLS_PER_TIME_DAY),
        ("SPEED_CELLS_PER_TIME_NIGHT", "Speed during night (cells/min)", SPEED_CELLS_PER_TIME_NIGHT),
        ("TIME_PER_CELL_WALK", "Walking time per cell (minutes)", AVG_TIME_PER_CELL_WALK),
    ])

    # Client & demand
    client_demand = make_table([
        ("NUM_CLIENTS", "Total number of clients", NUM_CLIENTS),
        ("AVG_SERVICE_TIME", "Average service time (minutes)", AVG_SERVICE_TIME),
        ("ACCEPT_TRESHOLD", "Maximum acceptable distance (cells)", ACCEPT_TRESHOLD),
        ("TIME_TRESHOLD", "Minimum remaining autonomy (time) for a car before it must go to recharge.", TIME_TRESHOLD)
    ])

    # Replacement
    replacement = make_table([
        ("REPLACEMENT_INTERVAL", "Replacement interval (minutes)", REPLACEMENT_INTERVAL),
        ("REPLACEMENT_INTERVAL_POS", "Position-based replacement interval (minutes)", REPLACEMENT_INTERVAL_POS),
        ("MAX_REPLACEMENT_PER_EVENT", "Max cars replaced per event", MAX_REPLACEMENT_PER_EVENT),
        ("MAX_REPLACEMENT_POSITION", "Max cars replaced by distance", MAX_REPLACEMENT_POSITION),
    ])

    # Demand dynamics
    demand_dynamics = make_table([
        ("LOW_DEMAND_HOURS", "Low-demand hours", "[00:00 - 05:59], [12:00 - 14:59], [22:00 - 23:59]"),
        ("HIGH_DEMAND", "Mean inter-arrival (high demand) [min]", HIGH_DEMAND),
        ("LOW_DEMAND", "Mean inter-arrival (low demand) [min]", LOW_DEMAND),
    ])

    # Display all tables
    from IPython.display import display, Markdown
    display(Markdown("###  Simulation Configuration")); display(sim_config)
    display(Markdown("###  Car & Station Parameters")); display(car_station)
    display(Markdown("###  Movement & Speed Settings")); display(movement)
    display(Markdown("###  Client & Demand Parameters")); display(client_demand)
    display(Markdown("###  Replacement Parameters")); display(replacement)
    display(Markdown("###  Demand Dynamics")); display(demand_dynamics)

# =========================
# USAGE EXAMPLE
# =========================
display_config()


# In[172]:


from typing import Tuple, Optional, List
from collections import defaultdict

class Square:
    def __init__(self, position: Tuple[int, int], num_cars: int = 0, recharge: bool = False):
        """
        Represents a single cell (square) in the simulation grid.

        Args:
            position (Tuple[int, int]): Coordinates (i, j) of this square in the grid.
            num_cars (int, optional): Number of cars currently parked in the square. Defaults to 0.
            recharge (bool, optional): True if this square includes a charging station. Defaults to False.
        """
        self.position: Tuple[int, int] = position
        self.num_cars: int = num_cars
        self.recharge: bool = recharge

    def capacity(self, max_park: int = MAX_PARK, max_park_recharge: int = MAX_PARK_RECHARGE):
        """
        Returns the maximum parking capacity of this square.

        Args:
            max_park (int): Max cars allowed in a normal square.
            max_park_recharge (int): Max cars allowed in a recharge square.

        Returns:
            int: Maximum number of cars that can be parked here.
        """
        return max_park_recharge if self.recharge else max_park

    def can_add(self, n: int = 1, max_park: int = MAX_PARK, max_park_recharge: int = MAX_PARK_RECHARGE):
        """
        Checks if n additional cars can be added without exceeding capacity.

        Args:
            n (int): Number of cars to add.
            max_park (int): Max cars allowed in a normal square.
            max_park_recharge (int): Max cars allowed in a recharge square.

        Returns:
            bool: True if there is enough capacity, False otherwise.
        """
        return self.num_cars + n <= self.capacity(max_park, max_park_recharge)

    def add_car(self, n: int = 1):
        """
        Adds n cars to the square.

        Args:
            n (int): Number of cars to add.
        """
        self.num_cars += n

    def remove_car(self, n: int = 1):
        """
        Removes n cars from the square (without allowing negative counts).

        Args:
            n (int): Number of cars to remove.
        """
        self.num_cars = max(0, self.num_cars - n)

    def __repr__(self) -> str:
        """
        Returns a concise string representation of the square, useful for debugging.
        """
        type_label = "Recharge" if self.recharge else "Normal"
        return f"<Square {type_label} pos={self.position}, num_cars={self.num_cars}>"

class Car:
    def __init__(
        self,
        car_id: int,
        position: Tuple[int, int],
        available: bool = True,
        time_left: float = TIME_AUTONOMY,
        to_recharge: bool = False
    ):
        """
        Represents a single car in the car-sharing simulation.

        Args:
            car_id (int): Unique identifier for the car.
            position (Tuple[int, int]): Current position of the car on the grid (row, column).
            available (bool, optional): True if the car is available for pickup. Defaults to True.
            time_left (float, optional): Remaining battery autonomy (in simulation time units). Defaults to TIME_AUTONOMY.
            to_recharge (bool, optional): True if the car must go to a recharge station. Defaults to False.
        """
        self.id: int = car_id
        self.position: Tuple[int, int] = position
        self.available: bool = available
        self.time_left: float = time_left
        self.to_recharge: bool = to_recharge

    def __repr__(self) -> str:
        """
        Returns a concise, human-readable string representation of the car.
        """
        return f"<Car id={self.id}, pos={self.position}, available={self.available}, time_left={self.time_left:.2f}, to_recharge={self.to_recharge}>"

class Client:
    def __init__(self, client_id: int, spawn_time: float, spawn_pos: Tuple[int, int]):
        """
        Represents a client requesting a car in the car-sharing simulation.

        Args:
            client_id (int): Unique client identifier.
            spawn_time (float): Time when the client appears (simulation time units).
            spawn_pos (Tuple[int, int]): Grid position where the client appears (row, column).
        """
        self.id: int = client_id
        self.spawn_time: float = spawn_time
        self.spawn_pos: Tuple[int, int] = spawn_pos

        # --- Dynamic attributes updated during simulation ---
        self.current_pos: Optional[Tuple[int, int]] = spawn_pos
        self.pickup_time: Optional[float] = None         # when the client is picked up
        self.dropoff_time: Optional[float] = None        # when the client is dropped off
        self.travel_time: Optional[float] = None         # duration of the car trip
        self.walk_time: Optional[float] = None           # time spent walking to the car
        self.walk_distance: Optional[float] = None       # distance walked to reach the car
        self.time_in_system: Optional[float] = None      # total time (walking + car)
        self.status: str = "waiting"                     # waiting, assigned, in_transit, completed, rejected, etc.
        self.assigned_car = None
        self.car_distance = 0.0   # distanza percorsa in auto

    def assign_car(self, 
                   cars: List, 
                   AVG_time_per_cell_walk: int = AVG_TIME_PER_CELL_WALK):
        """
        Assigns the nearest available car to this client.
        Pickup time is proportional to the Manhattan distance between the client and the car.

        Args:
            cars (List): List of all cars in the simulation.
            time_per_cell_walk (int): Time (in simulation units) to walk one cell.
        """
        available_cars = [car for car in cars if car.available]

        # Reject if no cars are available
        if not available_cars:
            self.status = "rejected_no_car"
            return

        # Find the nearest available car (Manhattan distance)
        min_dist = float('inf')
        closest_car = None
        for car in available_cars:
            dist = abs(car.position[0] - self.spawn_pos[0]) + abs(car.position[1] - self.spawn_pos[1])
            if dist < min_dist:
                min_dist = dist
                closest_car = car

        # Reject if the nearest car exceeds the acceptable distance threshold
        if min_dist > ACCEPT_TRESHOLD:
            self.status = "rejected_too_far"
            return

        # Assign the car to the client
        closest_car.available = False
        self.assigned_car = closest_car
        self.walk_distance = min_dist
        self.status = "assigned"

        # walking time simulation
        walking_time_per_cell = max(np.random.normal(AVG_time_per_cell_walk, SIGMA_WALK), 0.5)
        self.pickup_time = min_dist * walking_time_per_cell            

    def choose_destination_from_service(self, 
                                        size: int = SIZE,
                                        speed_day: float = SPEED_CELLS_PER_TIME_DAY, 
                                        speed_night: float = SPEED_CELLS_PER_TIME_NIGHT,
                                        beta: float = BETA,
                                        avg_service_time: float = AVG_SERVICE_TIME):
        """
        Randomly selects a service duration and a reachable destination cell 
        based on the car's average speed and the simulated trip time.

        Args:
            size (int): Grid size.
            speed_day (float): Car speed (cells per time unit) during the day.
            speed_night (float): Car speed (cells per time unit) during the night.
            beta (float): Bias factor to favor destinations near the border of the reachable area.
            avg_service_time (float): Mean service duration for the exponential distribution.

        Returns:
            Tuple[float, Tuple[int, int]]: (service_time, destination position)
        """
        # Determine time of day
        hour_of_day = (self.spawn_time / 60) % 24
        speed_cells_per_time = speed_day if 8 <= hour_of_day < 20 else speed_night

        # Sample service time from exponential distribution
        self.service_time = np.random.exponential(scale=avg_service_time)

        # Compute maximum travel distance (in grid cells)
        max_dist = max(0, int(round(speed_cells_per_time * self.service_time)))
        si, sj = self.spawn_pos

        # Generate all reachable cells with bias weighting
        cells = []
        weights = []
        for i in range(size):
            for j in range(size):
                dist = abs(i - si) + abs(j - sj)
                if dist <= max_dist:
                    cells.append((i, j))
                    weights.append((dist + 1) ** beta)

        # Normalize weights and sample a destination
        weights = np.array(weights, dtype=float)
        weights /= weights.sum()
        idx = np.random.choice(len(cells), p=weights)

        # Update attributes
        self.dest_pos = cells[idx]
        self.status = "in_transit"

        si, sj = self.spawn_pos
        di, dj = self.dest_pos
        self.car_distance = abs(di - si) + abs(dj - sj)

        return self.service_time, self.dest_pos

class Measure:
    def __init__(self, total_days=TOT_DAYS, slot_hours=2):
        self.total_days = total_days
        self.slot_hours = slot_hours

        # --- cumulative performance metrics --- #
        self.total_walk_time = 0.0
        self.total_service_time = 0.0
        self.total_walk_distance = 0.0
        self.total_time_in_system = 0.0
        self.num_served = 0
        self.num_completed = 0  # optional: number of clients that completed a trip

        self.day_clients = 0
        self.night_clients = 0

        # --- time-slot tracking (e.g. 2-hour intervals) --- #
        self.service_time_by_slot = {
            slot: {"total": 0.0, "count": 0}
            for slot in range(int(24 / slot_hours))
        }

        # --- rejected clients --- #
        self.num_rejected = 0
        self.rejections_by_day = {}
        self.rejections_by_slot = {slot: 0 for slot in range(int(24 / slot_hours))}

        # --- unavailable cars tracking (e.g. 2-hours intervals) --- #
        self.unavailable_cars_by_slot = defaultdict(list)


        # --- daily tracking for unavailable cars (time series + day/night averages) --- #
        self.time_points = []             # times at which unavailability was recorded
        self.unavailable_cars = []        # number of unavailable cars at those times
        self.daily_means_day = []         # mean unavailable cars during daytime per day
        self.daily_means_night = []       # mean unavailable cars during nighttime per day

        self.walk_times = []        # (time, walk_time)
        self.service_times = []     # (time, service_time)
        self.walk_distances = []    # (time, walk_distance)
        self.rejection_times = []   # tempi in cui avvengono rifiuti
        self.car_distance_day = []   # lista delle distanze percorse di giorno
        self.car_distance_night = [] # lista delle distanze percorse di notte



    # -------------------- UPDATE METHODS -------------------- #

    def update_rejection(self, status: str, event_time: float):
        """Update rejection counters by day and time slot."""
        if not status.startswith("rejected"):
            return  # skip if the client was not rejected

        self.num_rejected += 1

        self.rejection_times.append(event_time)

        day = int(event_time // (24 * 60)) + 1       
        hour_of_day = (event_time / 60) % 24
        slot = int(hour_of_day // self.slot_hours)

        # increment counters
        self.rejections_by_day[day] = self.rejections_by_day.get(day, 0) + 1
        self.rejections_by_slot[slot] += 1

    def update_walk_time(self, walk_time: float, event_time: float):
        """Accumulate total walking time."""
        self.total_walk_time += walk_time
        self.walk_times.append((event_time, walk_time))

    def update_service_time(self, service_time: float, dropoff_time: float):
        """Accumulate total service time and update per-slot statistics."""
        self.total_service_time += service_time
        self.num_served += 1
        self.service_times.append((dropoff_time, service_time))

        # identify 2-hour (or user-defined) slot of the day
        hour_of_day = (dropoff_time / 60) % 24
        slot = int(hour_of_day // self.slot_hours)

        self.service_time_by_slot[slot]["total"] += service_time
        self.service_time_by_slot[slot]["count"] += 1

    def update_walk_distance(self, walk_distance: float, event_time: float):
        """Accumulate total walking distance."""
        self.total_walk_distance += walk_distance
        self.walk_distances.append((event_time, walk_distance))

    def plot_walk_distance_rolling(self, window_hours=4):
        if not self.walk_distances:
            print("No walking distance data available.")
            return

        # --- Convert to DataFrame ---
        df = pd.DataFrame(self.walk_distances, columns=["time_min", "walk_distance"])
        df = df.sort_values("time_min")

        # Convert minutes to datetime-like index (per rolling time window)
        df["time"] = pd.to_timedelta(df["time_min"], unit="m")
        df.set_index("time", inplace=True)

        # --- Rolling mean every 4 hours ---
        window = f"{window_hours}H"  # '4H' = 4 ore
        rolling_mean = df["walk_distance"].rolling(window=window).mean()

        # --- Downsample ogni 4 ore per ridurre la densità di punti ---
        resampled = rolling_mean.resample(window).mean()

        # --- Plot ---
        plt.figure(figsize=(10, 4))
        plt.plot(resampled.index.total_seconds() / 3600, resampled.values,
                color="green", label=f"4-hour rolling mean")
        plt.title("Average Walking Distance (Rolling 4h Mean)")
        plt.xlabel("Simulation time (hours)")
        plt.ylabel("Walk distance")
        plt.grid(True, linestyle="--", alpha=0.6)
        plt.legend()
        plt.show()


    def update_time_in_system(self, time_in_system: float):
        """Accumulate total time spent in the system (walking + driving)."""
        self.total_time_in_system += time_in_system
        self.num_completed += 1

    def update_car_distance(self, distance: float, dropoff_time: float):
        """Accumulate distance traveled by car, separando giorno/notte."""
        hour_of_day = (dropoff_time / 60) % 24
        if 8 <= hour_of_day < 20:
            self.car_distance_day.append((dropoff_time, distance))
        else:
            self.car_distance_night.append((dropoff_time, distance))

    def record_unavailable_cars(self, t: float, cars: list):
        """
        Record the number of unavailable cars (either busy or recharging)
        at a given simulation time t.
        """
        hour_of_day = (t / 60) % 24
        slot = int(hour_of_day // self.slot_hours)
        unavailable_count = sum(1 for c in cars if not c.available or getattr(c, "needs_recharge", False))
        self.unavailable_cars_by_slot[slot].append(unavailable_count)
        self.time_points.append(t)
        self.unavailable_cars.append(unavailable_count)

    def avg_car_distance_day(self):
        """Media della distanza percorsa di giorno."""
        if not self.car_distance_day:
            return 0.0
        distances = [d for _, d in self.car_distance_day]
        return np.mean(distances)

    def avg_car_distance_night(self):
        """Media della distanza percorsa di notte."""
        if not self.car_distance_night:
            return 0.0
        distances = [d for _, d in self.car_distance_night]
        return np.mean(distances)

    def car_distance_CI(self, confidence=0.95):
        """Intervallo di confidenza 95% per distanza giorno/notte."""
        def ci(data):
            if len(data) < 2:
                return (0, 0)
            distances = [d for _, d in data]
            mean = np.mean(distances)
            sem = np.std(distances, ddof=1) / np.sqrt(len(distances))
            h = 1.96 * sem  # 95% CI
            return (mean - h, mean + h)
        return ci(self.car_distance_day), ci(self.car_distance_night)


    # -------------------- AVERAGES -------------------- #
    def avg_walk_time(self):
        """Return average walking time per served client."""
        return self.total_walk_time / self.num_served if self.num_served > 0 else 0

    def avg_service_time(self):
        """Return average car usage time per served client."""
        return self.total_service_time / self.num_served if self.num_served > 0 else 0

    def avg_service_time_by_slot(self):
        """Return a dictionary of average service times by time slot."""
        averages = {}
        for slot, data in self.service_time_by_slot.items():
            start_hour = slot * self.slot_hours
            end_hour = start_hour + self.slot_hours
            avg = data["total"] / data["count"] if data["count"] > 0 else 0
            averages[f"{start_hour:02d} - {end_hour:02d}"] = avg
        return averages

    def avg_walk_distance(self):
        """Return average walking distance per served client."""
        return self.total_walk_distance / self.num_served if self.num_served > 0 else 0

    def avg_time_in_system(self):
        """Return average total time (walk + drive) per completed client."""
        return self.total_time_in_system / self.num_completed if self.num_completed > 0 else 0

    def avg_unavailable_cars_by_slot(self):
        """Return a dictionary of average unavailable cars by time slot."""
        results = {}
        for slot, counts in sorted(self.unavailable_cars_by_slot.items()):
            start_hour = slot * self.slot_hours
            end_hour = start_hour + self.slot_hours
            mean_val = np.mean(counts) if counts else 0
            results[f"{start_hour:02d}-{end_hour:02d}"] = mean_val
        return results  
    # -------------------- REJECTIONS -------------------- #
    def get_rejections_by_day(self):
        """Return a dictionary {day: num_rejections} sorted by day."""
        return dict(sorted(self.rejections_by_day.items()))

    def get_rejections_by_slot(self):
        """Return a dictionary {time_slot: num_rejections} sorted by slot."""
        results = {}
        for slot, count in sorted(self.rejections_by_slot.items()):
            start_hour = slot * self.slot_hours
            end_hour = start_hour + self.slot_hours
            results[f"{start_hour:02d}-{end_hour:02d}"] = count
        return results

    # -------------------- SUMMARY -------------------- #
    def summary(self):
        """Return a complete summary of performance metrics (rounded and cleaned)."""

        summary = {
            "avg_walk_time": round(self.avg_walk_time(), 2),
            "avg_service_time": round(self.avg_service_time(), 2),
            "avg_walk_distance": round(self.avg_walk_distance(), 2),
            "avg_time_in_system": round(self.avg_time_in_system(), 2),
            "rejections_by_slot": {k: round(float(v), 2) for k,v in self.get_rejections_by_slot().items()},
            "avg_unavailable_cars_by_slot": self.avg_unavailable_cars_by_slot(),
            "num_served": self.num_served,
            "num_rejected": self.num_rejected,
        }

        # Applica la pulizia a tutto il dizionario
        return summary

    def print_summary_table(measure):
        """
        Prints a summary table of the main performance metrics collected
        during the simulation using the Measure class.
        Includes day/night distinction for walking, service, and system times,
        as well as for distances.
        """

        # --- Helper to compute averages by time of day ---
        def avg_day_night(data):
            """Compute mean values separately for day and night."""
            if not data:
                return (0, 0)
            day_values = [v for t, v in data if 8 <= (t / 60) % 24 < 20]
            night_values = [v for t, v in data if (t / 60) % 24 < 8 or (t / 60) % 24 >= 20]
            return (np.mean(day_values) if day_values else 0,
                    np.mean(night_values) if night_values else 0)

        # --- Compute day/night averages for all metrics ---
        walk_time_day, walk_time_night = avg_day_night(measure.walk_times)
        walk_dist_day, walk_dist_night = avg_day_night(measure.walk_distances)
        service_time_day, service_time_night = avg_day_night(measure.service_times)
        car_dist_day = measure.avg_car_distance_day()
        car_dist_night = measure.avg_car_distance_night()

        # --- Main summary data ---
        data = {
            "Average walking time (day, min)": round(walk_time_day, 2),
            "Average walking time (night, min)": round(walk_time_night, 2),
            "Average walking distance (day, cells)": round(walk_dist_day, 2),
            "Average walking distance (night, cells)": round(walk_dist_night, 2),
            "Average car distance (day, cells)": round(car_dist_day, 2),
            "Average car distance (night, cells)": round(car_dist_night, 2),
            "Total served clients": measure.num_served,
            "Total rejected clients": measure.num_rejected,
        }

        # --- Create DataFrame ---
        df_main = pd.DataFrame(list(data.items()), columns=["Metric", "Value"])

        print(" OVERALL PERFORMANCE SUMMARY")
        print(df_main.to_string(index=False))

        # --- Optional per-slot statistics ---
        unavailable = measure.avg_unavailable_cars_by_slot()
        rejections = measure.get_rejections_by_slot()

        print("Average Unavailable Cars by Time Slot ")
        df_unavail = pd.DataFrame(list(unavailable.items()), columns=["Time Slot", "Avg Unavailable Cars"])
        print(df_unavail.to_string(index=False))

        print("Rejections by Time Slot")
        df_reject = pd.DataFrame(list(rejections.items()), columns=["Time Slot", "Num Rejections"])
        print(df_reject.to_string(index=False))



    # ---------------------------------
    def compute_confidence_intervals(self, transient_time: float = 0.0):
        """
        Compute 95% confidence intervals for key performance metrics (walking time,
        service time, and walking distance), excluding data collected during the transient phase.

        Parameters:
            transient_time (float): Simulation time (in minutes) marking the end of the transient phase.
                                    Only observations with timestamp >= transient_time are considered.

        Returns:
            dict: A dictionary containing mean values and confidence intervals for
                day and night periods, for each metric.
                Format: { "metric_day": (mean, lower_CI, upper_CI), ... }
        """
        results = {}

        # Define metrics to analyze
        metrics = {
            "walk_time": self.walk_times,
            "service_time": self.service_times,
            "walk_distance": self.walk_distances,
            "car_distance": self.car_distance_day + self.car_distance_night
        }

        for name, data in metrics.items():
            # Filter out data before the transient phase
            filtered_data = [(t, v) for t, v in data if t >= transient_time]
            if not filtered_data:
                continue

            # Separate day and night observations
            day_values = [v for t, v in filtered_data if 8 <= (t / 60) % 24 < 20]
            night_values = [v for t, v in filtered_data if (t / 60) % 24 < 8 or (t / 60) % 24 >= 20]

            def conf_interval(values):
                """Compute mean and 95% CI using Student's t-distribution."""
                if len(values) < 2:
                    return (np.mean(values) if values else 0, 0, 0)
                mean = np.mean(values)
                sem = stats.sem(values)
                ci = stats.t.interval(0.95, len(values) - 1, loc=mean, scale=sem)
                return (mean, ci[0], ci[1])

            # Store results
            results[f"{name}_day"] = conf_interval(day_values)
            results[f"{name}_night"] = conf_interval(night_values)

        return results

    def compute_confidence_intervals_overall(self, transient_time: float = 0.0):
        """
        Compute 95% confidence intervals for key performance metrics (walking time,
        service time, walking distance, and car distance), excluding data collected
        during the transient phase.

        Parameters:
            transient_time (float): Simulation time (in minutes) marking the end of
                                    the transient phase. Only observations with 
                                    timestamp >= transient_time are considered.

        Returns:
            dict: A dictionary containing mean values and 95% CI for each metric.
                Format: { "metric": (mean, lower_CI, upper_CI), ... }
        """

        results = {}

        # Metrics to analyze (same structure used in your original function)
        metrics = {
            "walk_time": self.walk_times,
            "service_time": self.service_times,
            "walk_distance": self.walk_distances,
            "car_distance": self.car_distance_day + self.car_distance_night
        }

        for name, data in metrics.items():
            # Keep only samples after the transient phase
            filtered_values = [v for (t, v) in data if t >= transient_time]

            # If insufficient samples, skip or return trivial CI
            if len(filtered_values) < 2:
                if filtered_values:
                    mean_val = np.mean(filtered_values)
                    results[name] = (mean_val, mean_val, mean_val)
                continue

            # Mean and 95% CI using Student's t-distribution
            mean = np.mean(filtered_values)
            sem = stats.sem(filtered_values)
            ci_low, ci_high = stats.t.interval(0.95, len(filtered_values)-1, loc=mean, scale=sem)

            results[name] = (mean, ci_low, ci_high)

        return results


# In[173]:

### ----------- Other functions ------------ ##

def move_one_car(from_square: Square, to_square: Square, 
                 max_park: int = MAX_PARK, max_park_recharge: int = MAX_PARK_RECHARGE):
    """
    Moves one car from 'from_square' to 'to_square'.

    The function:
      - Checks that the origin square is not empty.
      - Checks that the destination square has available capacity.
      - Updates the number of cars in both squares accordingly.

    Parameters
    ----------
    from_square : Square
        The source cell from which the car will be moved.
    to_square : Square
        The destination cell where the car will be placed.
    max_park : int, optional
        Maximum capacity for normal squares (default = MAX_PARK).
    max_park_recharge : int, optional
        Maximum capacity for recharge-enabled squares (default = MAX_PARK_RECHARGE).
    """
    if from_square.num_cars == 0:
        # No cars available to move
        return

    # Only move if the destination has space
    if to_square.num_cars < to_square.capacity(max_park, max_park_recharge):
        from_square.num_cars -= 1
        to_square.num_cars += 1

def time_to_hhmm(t_sim: float):
    """
    Converts a simulation time (in minutes) into a human-readable string format.

    The output includes the simulation day and the time of day in HH:MM format.

    Parameters
    ----------
    t_sim : float
        Simulation time expressed in minutes.

    Returns
    -------
    str
        A formatted string like 'Day 3 14:25', representing the day and time.
    """
    total_minutes = int(t_sim)
    day = total_minutes // (24 * 60) + 1                # Day count starts from 1
    minutes_in_day = total_minutes % (24 * 60)          # Minutes elapsed within the current day
    hours = (minutes_in_day // 60) % 24                 # Extract hour of the day
    minutes = minutes_in_day % 60                       # Extract remaining minutes
    return f"Day {day} {hours:02d}:{minutes:02d}"

def build_gaussian_prob_distribution(size=SIZE, sigma=SIGMA):
    """
    Builds a 2D Gaussian probability distribution matrix.

    The matrix represents spatial probabilities centered in the middle of the grid,
    with values decreasing according to a Gaussian function.

    Parameters
    ----------
    size : int, optional
        The width and height of the grid (default is SIZE).
    sigma : float, optional
        The standard deviation controlling the spread of the Gaussian (default is SIGMA).

    Returns
    -------
    np.ndarray
        A 2D array of probabilities that sum to 1.
    """
    cx = cy = (size - 1) / 2.0                          # Center coordinates of the grid
    x = np.arange(size)
    y = np.arange(size)
    X, Y = np.meshgrid(x, y)                            # Create 2D coordinate grid
    gauss = np.exp(-(((X - cx)**2 + (Y - cy)**2) / (2 * sigma**2)))  # Gaussian function
    probs = gauss / gauss.sum()                         # Normalize to make it a probability distribution
    return probs

def is_valid_station(new_pos, existing_positions, min_distance=MIN_DIST_STATION):
    """
    Checks whether a new station position is valid based on a minimum distance constraint.

    A new position is valid if it is sufficiently far from all existing stations.

    Parameters
    ----------
    new_pos : tuple[int, int]
        Coordinates (x, y) of the candidate station.
    existing_positions : list[tuple[int, int]]
        List of existing station coordinates.
    min_distance : int, optional
        Minimum required distance between any two stations (default is MIN_DIST_STATION).

    Returns
    -------
    bool
        True if the new position is valid (no nearby stations), False otherwise.
    """
    for pos in existing_positions:
        # Check Chebyshev distance (max of x/y differences)
        if max(abs(new_pos[0] - pos[0]), abs(new_pos[1] - pos[1])) < min_distance:
            return False
    return True


# In[174]:


import matplotlib.pyplot as plt

def initialize_grid(size: int):
    """
    Create a 2D grid of Square objects.

    Parameters
    ----------
    size : int
        Grid dimension (size x size).

    Returns
    -------
    list[list[Square]]
        2D list of Square objects.
    """
    return [[Square((i, j)) for j in range(size)] for i in range(size)]

def place_stations(grid, probs, num_stations, min_distance, max_attempts_factor=50):
    """
    Place recharge stations in the grid using a probability distribution,
    ensuring a minimum distance between stations.

    Returns a list of station positions (tuples).
    """
    station_positions = []
    attempts = 0
    max_attempts = num_stations * max_attempts_factor

    while len(station_positions) < num_stations and attempts < max_attempts:
        index = np.random.choice(len(probs.ravel()), p=probs.ravel())
        i, j = divmod(index, len(grid))
        if (i, j) in station_positions:
            attempts += 1
            continue
        if is_valid_station((i, j), station_positions, min_distance):
            grid[i][j].recharge = True
            station_positions.append((i, j))
        attempts += 1

    if len(station_positions) < num_stations:
        print(f"Could not place all stations (constraints too strict).")
    else:
        print(f"Stations placed: {station_positions}")

    return station_positions

def place_cars(grid, probs, num_cars, max_attempts_factor=50):
    """
    Place cars in the grid probabilistically, respecting cell capacity.

    Returns a list of Car objects and updates the grid.
    """
    cars_placed = 0
    attempts = 0
    max_attempts = num_cars * max_attempts_factor

    size = len(grid)
    cars_list = []

    while cars_placed < num_cars and attempts < max_attempts:
        index = np.random.choice(size * size, p=probs.ravel())
        i, j = divmod(index, size)
        sq = grid[i][j]
        cap = MAX_PARK_RECHARGE if sq.recharge else MAX_PARK

        if sq.num_cars < cap:
            sq.add_car(1)
            car_id = len(cars_list)
            cars_list.append(Car(car_id=car_id, position=(i, j)))
            cars_placed += 1
        attempts += 1

    if cars_placed < num_cars:
        print(f"Only {cars_placed}/{num_cars} cars placed (capacity reached).")
    else:
        print(f"All {num_cars} cars placed successfully.")

    return cars_list

def visualize_grid(grid, station_positions, title="Car Distribution"):
    """
    Visualize the grid using a **discrete** colormap and a SHORT colorbar.
    Max expected cars per cell = 3.
    """
    size = len(grid)
    car_counts = np.array([[sq.num_cars for sq in row] for row in grid])

    max_val = 3  # we cap at 3 since that's your logical max
    cmap = plt.cm.get_cmap("Blues", max_val + 1)

    fig, ax = plt.subplots(figsize=(7, 7))
    im = ax.imshow(car_counts, origin='lower', interpolation='nearest',
                   cmap=cmap, vmin=0, vmax=max_val)

    # Short + nice discrete colorbar
    cbar = plt.colorbar(im, ax=ax, label="Number of cars",
                        shrink=0.6, aspect=10, pad=0.02)
    ticks = np.arange(0, max_val + 1)
    cbar.set_ticks(ticks)
    cbar.set_ticklabels([str(t) for t in ticks])

    # Stations
    xs = [j for (i, j) in station_positions]
    ys = [i for (i, j) in station_positions]
    ax.scatter(xs, ys, color="red", marker="x", s=120, label="Recharge stations")

    ax.set_xlim(-0.5, size - 0.5)
    ax.set_ylim(-0.5, size - 0.5)
    ax.set_title(title)
    ax.set_xlabel("Column")
    ax.set_ylabel("Row")
    ax.legend()
    plt.tight_layout()
    plt.show()

# --- MAIN SCRIPT --- #

# Initialize grid
grid = initialize_grid(SIZE)

# Compute Gaussian probabilities
probs = build_gaussian_prob_distribution(SIZE, SIGMA)

# Place recharge stations
station_positions = place_stations(grid, probs, STATIONS, MIN_DIST_STATION)

# Place cars
cars = place_cars(grid, probs, CARS)

# Visualize the grid
visualize_grid(grid, station_positions)


# In[175]:


import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

def plot_grid(cars, client, SIZE, event_time, closest_car=None):
    """
    Visualizza la griglia con:
      - Verde: auto disponibili
      - Rosso: auto occupate
      - Giallo: auto selezionata come più vicina (se presente)
      - Blu: cliente rigettato (stellina)

    Griglia pulita, senza numeri sugli assi, con legenda.
    """

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.set_title(f"Client {client.id} rejected at {client.spawn_pos} (t={event_time:.1f})")

    # sfondo scacchiera leggero per dare struttura
    grid_bg = np.indices((SIZE, SIZE)).sum(axis=0) % 2
    ax.imshow(grid_bg, cmap="Greys", alpha=0.15, origin="lower")

    # plot client in blu (stellina)
    ax.scatter(client.spawn_pos[1] + 0.5, client.spawn_pos[0] + 0.5,
               marker='*', s=250, color='blue', label='Client')

    # macchine
    for car in cars:
        if closest_car is not None and car == closest_car:
            color = 'yellow'
        elif car.available:
            color = 'green'
        else:
            color = 'red'
        ax.scatter(car.position[1] + 0.5, car.position[0] + 0.5,
                   s=130, color=color)

    # limiti
    ax.set_xlim(0, SIZE)
    ax.set_ylim(0, SIZE)

    # griglia pulita
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_aspect("equal")
    ax.grid(True, linewidth=0.4, alpha=0.4)

    # legenda bella chiara
    legend_elements = [
        Patch(facecolor='green', edgecolor='black', label='Available car'),
        Patch(facecolor='red', edgecolor='black', label='Busy car'),
        Patch(facecolor='yellow', edgecolor='black', label='Closest available car'),
        Line2D([0], [0], marker='*', color='blue', label='Client', markersize=15, linestyle='None')
    ]
    ax.legend(handles=legend_elements, loc='upper right')

    plt.tight_layout()
    plt.show()



# In[176]:


import heapq

def handle_arrival(event_time: float, FES: list, clients: list, cars: list, SIZE: int, SPEED: float, measure):
    """
    Handles the arrival of a new client:
    - Creates the client at a spawn position
    - Assigns the nearest available car
    - Schedules the PICKUP event
    - If the client is rejected, visualizes the available cars on the grid
    """

    # Determine spawn position based on the probability distribution
    index = np.random.choice(SIZE * SIZE, p=probs.ravel())
    i = index // SIZE
    j = index % SIZE
    spawn_pos = (i, j)

    # Create new client
    client_id = len(clients)
    client = Client(client_id=client_id, spawn_time=event_time, spawn_pos=spawn_pos)
    client.current_pos = spawn_pos
    clients.append(client)

    # Assign the nearest available car
    client.assign_car(cars, AVG_time_per_cell_walk=AVG_TIME_PER_CELL_WALK)

    if client.status.startswith("rejected"):
        # Update rejection statistics
        measure.update_rejection(client.status, event_time)

        # Find the closest available car for visualization
        available_cars = [c for c in cars if c.available]
        closest_car = None
        if available_cars:
            distances = [np.linalg.norm(np.array(c.position) - np.array(client.spawn_pos)) for c in available_cars]
            closest_car = available_cars[int(np.argmin(distances))]

        # Plot the grid showing client and available cars
        #plot_grid(cars, client, SIZE, event_time, closest_car=closest_car)
        return

    # If client successfully assigned a car
    client.assigned_car.available = False

    # Schedule PICKUP event
    global event_counter
    event_counter += 1
    pickup_time = event_time + client.pickup_time
    heapq.heappush(FES, (pickup_time, event_counter, "pickup", {"client": client}))

def handle_pickup(event_time: float,
                  FES: list,
                  payload: dict,
                  measure):
    """
    Handle a PICKUP event for a client.

    - payload must contain {'client': Client}
    - Updates client status to 'in_transit'
    - Ensures car is at client's spawn position
    - Samples service time and chooses destination if not already set
    - Schedules DROP-OFF event
    - Updates walking statistics
    """
    client = payload.get("client")
    if client is None:
        raise ValueError("handle_pickup: payload must contain 'client'")

    if client.assigned_car is None:
        client.status = "rejected"
        print(f"[{event_time:.2f}] PICKUP: Client {client.id} has no assigned car -> rejected")
        return

    car = client.assigned_car
    client.current_pos = car.position
    client.status = "in_transit"
    client.pickup_time = event_time

    # Update walking statistics
    client.walk_time = event_time - client.spawn_time
    client.walk_distance = abs(car.position[0] - client.spawn_pos[0]) + abs(car.position[1] - client.spawn_pos[1])
    measure.update_walk_time(client.walk_time, event_time)
    measure.update_walk_distance(client.walk_distance, event_time)

    # Choose destination and service time if not already set 
    if client.travel_time is None or client.dest_pos is None:
        client.choose_destination_from_service(beta=BETA, avg_service_time=AVG_SERVICE_TIME)

    # Schedule DROP-OFF event 
    global event_counter
    event_counter += 1
    dropoff_time = event_time + client.service_time
    heapq.heappush(FES, (dropoff_time, event_counter, "dropoff", {'client': client}))

def handle_dropoff(event_time: float,
                   payload: dict,
                   grid,
                   measure):
    """
    Handles a DROP-OFF event for a client.

    Steps:
    - Extract the client from the payload
    - Update client and car positions
    - Mark the client as 'completed'
    - Free the car if enough time left, otherwise mark it for recharge
    - Update statistics: time in system, service time
    - Move the car physically in the grid

    Parameters:
    - event_time: current simulation time
    - payload: expected {'client': Client}
    - grid
    - measure: statistics collector
    """

    # Extract client
    client = payload.get("client")
    if client is None:
        raise ValueError("handle_dropoff: payload must contain 'client'")

    car = client.assigned_car
    if car is None:
        return

    # Update client status and position
    client.current_pos = client.dest_pos
    client.dropoff_time = event_time
    client.status = "completed"
    client.travel_time = client.dropoff_time - client.pickup_time
    client.time_in_system = client.dropoff_time - client.spawn_time

    # Update statistics
    measure.update_time_in_system(client.time_in_system)
    measure.update_service_time(client.travel_time, client.dropoff_time)

    # Update car remaining time
    car.time_left -= client.service_time

    # Get grid squares for move
    old_i, old_j = car.position
    dest_i, dest_j = client.dest_pos
    car_cell_from = grid[old_i][old_j]
    car_cell_to = grid[dest_i][dest_j]

    # Check if car needs recharge
    if car.time_left < TIME_TRESHOLD:
        car.available = False
        car.to_recharge = True
    else:
        car.available = True

    # Move the car physically in the grid
    move_one_car(car_cell_from, car_cell_to, max_park=MAX_PARK, max_park_recharge=MAX_PARK_RECHARGE)

    # Update car object position
    car.position = (dest_i, dest_j)

def handle_recharge_replacement_check(current_time: float, FES: list, cars: list, center=center):
    """
    Check for cars that need replacement due to low battery and schedule replacement events.

    - Only performs replacements during low-demand hours.
    - Schedules a future check after REPLACEMENT_INTERVAL minutes.
    - Selects up to MAX_REPLACEMENT_PER_EVENT cars farthest from the center that need recharge.

    Parameters:
    - current_time: current simulation time (minutes)
    - FES: Future Event Schedule (heapq)
    - cars: list of all Car objects
    - center: tuple (i,j) representing the "center" of the grid
    """
    global event_counter

    # Schedule next replacement check
    event_counter += 1
    heapq.heappush(FES, (current_time + REPLACEMENT_INTERVAL, event_counter, "recharge replacement check", {}))

    # Only proceed if current hour is in low-demand period
    current_hour = int((current_time / 60) % 24)
    if current_hour not in LOW_DEMAND_HOURS:
       return

    # Filter cars that require recharge
    low_battery_cars = [car for car in cars if car.to_recharge]

    if not low_battery_cars:
        return

    # Distance function from center
    def distance_from_center(car):
        return abs(car.position[0] - center[0]) + abs(car.position[1] - center[1])

    # Sort cars by distance from center (farther first)
    low_battery_cars.sort(key=distance_from_center, reverse=True)

    # Select up to MAX_REPLACEMENT_PER_EVENT cars
    cars_to_replace = low_battery_cars[:MAX_REPLACEMENT_PER_EVENT]

    # Schedule replacement events
    for car in cars_to_replace:
        event_counter += 1
        heapq.heappush(FES, (current_time, event_counter, "recharge replacement", {"car": car}))

def handle_recharge_replacement(current_time: float,
                                FES: list,
                                payload: dict,
                                grid,
                                stations: list,
                                speed_day: float = SPEED_CELLS_PER_TIME_DAY,
                                speed_night: float = SPEED_CELLS_PER_TIME_NIGHT):
    """
    Handle the replacement/recharge process for a car with low autonomy.

    - Finds the nearest available charging station.
    - Simulates the movement time to reach it.
    - Updates the car's state and position.
    - Schedules the "start to charge" event.

    Parameters:
    - current_time: simulation time in minutes
    - FES: Future Event Schedule (heapq)
    - payload: dictionary containing {'car': Car}
    - grid: 2D grid of Square objects
    - stations: list of (i, j) tuples representing station coordinates
    - speed_day/speed_night: cell movement speed (different for day and night)
    """
    car = payload.get("car")
    if car is None:
        raise ValueError("handle_recharge_replacement: payload must contain 'car'")

    car.available = False  # car is now being replaced/recharged

    # --- Get current cell ---
    car_cell_from = grid[car.position[0]][car.position[1]]

    # --- Find closest station with available space ---
    def closest_available_station(car, stations):
        car_i, car_j = car.position
        min_dist = float('inf')
        closest = None
        for si, sj in stations:
            if grid[si][sj].num_cars < MAX_PARK_RECHARGE:
                dist = abs(car_i - si) + abs(car_j - sj)
                if dist < min_dist:
                    min_dist = dist
                    closest = (si, sj)
        return closest, min_dist

    closest_station, dist = closest_available_station(car, stations)

    if closest_station is None:
        return

    # --- Determine travel speed based on hour of day ---
    hour_of_day = (current_time / 60) % 24
    current_speed = speed_day if 8 <= hour_of_day < 20 else speed_night

    # --- Simulate travel/replacement time ---
    mean_replacement_time = dist / current_speed
    replacement_time = max(
        np.random.normal(loc=mean_replacement_time, scale=0.2 * mean_replacement_time), 0.1
    )

    # --- Move car to station ---
    car_cell_to = grid[closest_station[0]][closest_station[1]]
    move_one_car(car_cell_from, car_cell_to, max_park=MAX_PARK, max_park_recharge=MAX_PARK_RECHARGE)
    car.position = closest_station

    # --- Update car status ---
    car.time_left = max(0, car.time_left - replacement_time)

    # --- Schedule start-to-charge event ---
    global event_counter
    event_counter += 1
    heapq.heappush(FES, (current_time + replacement_time, event_counter, "start recharge", {"car": car}))

def handle_start_recharge(time, FES, payload):
    """Handles the start of the car recharge process."""
    car = payload['car']

    global event_counter
    event_counter += 1

    # Schedule the end of recharge event
    heapq.heappush(FES, (time + RECHARGE_TIME, event_counter, "end recharge", {"car": car}))

def handle_end_recharge(payload):
    """Handles the end of the recharge process, making the car available again."""
    car = payload['car']

    car.available = True
    car.time_left = TIME_AUTONOMY
    car.to_recharge = False

def handle_periodic_replacement_check(time: float, FES: list, cars: list, 
                                      speed_day: float=SPEED_CELLS_PER_TIME_DAY, 
                                      speed_night: float=SPEED_CELLS_PER_TIME_NIGHT):
    """
    Handle a PERIODIC REPLACEMENT CHECK event.

    - Every REPLACEMENT_INTERVAL minutes, selects the top N cars farthest from the city center.
    - The event runs only during low-demand hours.
    - Each selected car is marked unavailable and scheduled for relocation.
    """

    # --- Reschedule next periodic check ---
    global event_counter
    event_counter += 1
    heapq.heappush(FES, (time + REPLACEMENT_INTERVAL, event_counter, "periodic replacement check", {}))

    # --- Skip if not in low-demand hours ---
    current_hour = int((time / 60) % 24)
    if current_hour not in LOW_DEMAND_HOURS:
        return

    # --- Determine movement speed based on time of day ---
    if 8 <= current_hour < 20:
        current_speed = speed_day
    else:
        current_speed = speed_night

    # --- Compute Manhattan distances from the city center ---
    distances = []
    for car in cars:
        distance = abs(car.position[0] - center[0]) + abs(car.position[1] - center[1])
        distances.append((car, distance))

    # --- Sort cars by descending distance ---
    distances.sort(key=lambda x: x[1], reverse=True)

    # --- Select top N cars for relocation ---
    cars_to_replace = [car for car, _ in distances[:MAX_REPLACEMENT_POSITION]]

    for car in cars_to_replace:
        car.available = False
        destination = None

        # --- Try up to 100 random cells to find a valid destination ---
        for _ in range(100):
            index = np.random.choice(SIZE * SIZE, p=probs.ravel())
            i, j = divmod(index, SIZE)
            dest_cell = grid[i][j]

            # Determine cell capacity
            cap = MAX_PARK_RECHARGE if dest_cell.recharge else MAX_PARK
            if dest_cell.num_cars < cap:
                destination = (i, j)
                break

        # --- Skip if no valid destination found ---
        if destination is None:
            car.available = True
            continue

        # --- Compute travel time ---
        old_pos = car.position
        road_distance = abs(destination[0] - old_pos[0]) + abs(destination[1] - old_pos[1])
        mean_replacement_time = road_distance / current_speed
        replacement_time = max(0.1, np.random.normal(
            loc=mean_replacement_time,
            scale=0.2 * mean_replacement_time
        ))

        # --- Schedule the PERIODIC REPLACEMENT event ---
        event_counter += 1
        heapq.heappush(FES, (
            time + replacement_time,
            event_counter,
            "periodic replacement",
            {"car": car, "destination": destination}
        ))

def handle_periodic_replacement(time: float, payload: dict):
    """
    Handle a PERIODIC REPLACEMENT completion event.

    - Moves the car to its new grid cell.
    - Updates its position and marks it as available again.
    """

    # --- Extract payload data ---
    car = payload["car"]
    destination = payload["destination"]
    i, j = destination

    # --- Move car between cells ---
    cell_from = grid[car.position[0]][car.position[1]]
    cell_to = grid[i][j]
    move_one_car(cell_from, cell_to)

    # --- Update car state ---
    car.position = destination
    car.available = True



# In[177]:


# --- Initialization ---
FES: List[Tuple[float, int, str, dict]] = []   # Future Event Set (priority queue)
clients: List[Client] = []                     # List of all clients
served: int = 0                                # Number of successfully served clients
rejected: int = 0                              # Number of rejected clients
sum_total_time: float = 0.0                    # Cumulative total time spent by served clients                            # Travel time scaling factor
event_counter: int = 0                         # Event ID counter
measure = Measure()                            # Object collecting performance metrics
current_day = 0

# --- Schedule initial arrivals ---
t = 0.0
for n in range(NUM_CLIENTS):
    mean_ia = dynamic_mean_ia(t)  # Compute dynamic mean interarrival time
    ia = 0.0 if n == 0 else float(np.random.exponential(scale=mean_ia))
    t += ia
    event_counter += 1
    heapq.heappush(FES, (t, event_counter, "arrival", {"time": t}))

# --- Schedule replacement checks ---
event_counter += 1
heapq.heappush(FES, (0, event_counter, "recharge replacement check", {}))      # Immediate first recharge check
heapq.heappush(FES, (600, event_counter, "periodic replacement check", {}))    # Start at 10:00 (600 min)

# --- Main Simulation Loop ---
while FES:
    event_time, _, event_type, payload = heapq.heappop(FES)

    # Stop conditions
    if event_time > SIM_TIME:
        print(f" Simulation reached the time limit ({SIM_TIME} min). Stopping.")
        break

    if served + measure.num_rejected >= NUM_CLIENTS:
        print(f"[{event_time:.2f}]  All {NUM_CLIENTS} clients processed. Stopping simulation.")
        FES.clear()
        break

    if event_time // (24 * 60) > current_day:
        current_day += 1

        mean_day = np.mean([
            x for t, x in zip(measure.time_points, measure.unavailable_cars)
            if (t % (24 * 60)) in range(8 * 60, 20 * 60)
        ])
        mean_night = np.mean([
            x for t, x in zip(measure.time_points, measure.unavailable_cars)
            if (t % (24 * 60)) not in range(8 * 60, 20 * 60)
        ])

        measure.daily_means_day.append(mean_day)
        measure.daily_means_night.append(mean_night)

    # Record of unavailable cars
    measure.record_unavailable_cars(event_time, cars)

    # === Event handling ===
    if event_type == "arrival":
        handle_arrival(event_time, FES, clients, cars, SIZE, probs, measure)

    elif event_type == "pickup":
        handle_pickup(event_time, FES, payload, measure)

    elif event_type == "dropoff":
        client_ref = payload.get("client")
        handle_dropoff(event_time, payload, grid, measure)

        # Update served statistics
        if client_ref is not None and client_ref.status == "completed":
            sum_total_time += (client_ref.dropoff_time - client_ref.spawn_time)
            measure.update_car_distance(client_ref.car_distance, client_ref.dropoff_time)

    elif event_type == "recharge replacement check":
        handle_recharge_replacement_check(event_time, FES, cars)

    elif event_type == "recharge replacement":
        handle_recharge_replacement(event_time, FES, payload, grid, station_positions)

    elif event_type == "start recharge":
        car = payload["car"]
        handle_start_recharge(event_time, FES, payload)

    elif event_type == "end recharge":
        car = payload["car"]
        handle_end_recharge(payload)

    elif event_type == "periodic replacement check":
        handle_periodic_replacement_check(event_time, FES, cars, speed_day=SPEED_CELLS_PER_TIME_DAY, speed_night=SPEED_CELLS_PER_TIME_NIGHT)

    elif event_type == "periodic replacement":
        handle_periodic_replacement(event_time, payload)

    else:
        print(f"Unknown event type: {event_type}")





# In[178]:


measure.print_summary_table()


# In[179]:


def detect_transient_end_gradient(ts, window, tol_grad, hold):
    """
    Detect the end of the transient phase using the gradient (first derivative) of the time series.

    Parameters:
    - ts: array-like, the time series (e.g. rolling mean).
    - window: size of the smoothing window (number of samples).
    - tol_grad: gradient magnitude threshold for stability.
    - hold: number of consecutive points below the threshold to confirm stabilization.

    Returns:
    - end_idx: index corresponding to the detected end of the transient phase, or None if not found.
    - info: dictionary containing the final gradient and mean statistics.
    """
    ts = np.asarray(ts, dtype=float)
    # --- Smooth the series slightly to reduce noise ---
    smoothed = np.convolve(ts, np.ones(window)/window, mode='same')

    # --- Compute numerical gradient ---
    grad = np.gradient(smoothed)

    # --- Find consecutive regions where the gradient magnitude is low ---
    stable_points = np.abs(grad) < tol_grad
    counter = 0
    for i, stable in enumerate(stable_points):
        if stable:
            counter += 1
            if counter >= hold:
                # Confirm stability (steady-state)
                return i, {
                    "mean_grad": np.mean(np.abs(grad[i-hold:i])),
                    "last_mean": np.mean(ts[i-hold:i])
                }
        else:
            counter = 0

    # --- If never found ---
    return None, {"mean_grad": None, "last_mean": None}



# In[181]:


def plot_measure_with_transient(measure_data, label, window_hours=12,
                                grad_window=8, tol_grad=0.1, hold=2,
                                show_raw=False, raw_every=24):
    """
    Plot della rolling mean con rilevazione del termine della fase transiente
    (metodo del gradiente). Per default non mostra i dati grezzi.
    - show_raw: se True, mostra i dati grezzi (downsample ogni 'raw_every' punti).
    - raw_every: passo di campionamento per i dati grezzi quando show_raw=True.
    """
    if not measure_data:
        print(f"No data available for {label}.")
        return

    # --- DataFrame e indice temporale ---
    df = pd.DataFrame(measure_data, columns=["time_min", "value"]).sort_values("time_min")
    df["time"] = pd.to_timedelta(df["time_min"], unit="m")
    df.set_index("time", inplace=True)

    # --- Rolling mean (usa 'h' minuscola) ---
    window = f"{window_hours}h"
    rolling_mean = df["value"].rolling(window=window).mean().dropna()

    # --- Converti in giorni ---
    time_days = rolling_mean.index.total_seconds() / (3600 * 24)
    values = rolling_mean.values

    # --- Rilevazione transiente (gradiente) ---
    idx, info = detect_transient_end_gradient(
        ts=values,
        window=grad_window,
        tol_grad=tol_grad,
        hold=hold
    )
    transient_end_day = time_days[idx] if idx is not None and idx < len(time_days) else None

    # --- Plot ---
    plt.figure(figsize=(10, 4))

    # (opzionale) dati grezzi downsampled
    if show_raw:
        raw_idx = np.arange(0, len(df), raw_every)
        plt.plot(df.index[raw_idx].total_seconds()/(3600*24),
                 df["value"].values[raw_idx],
                 color="orange", alpha=0.25, linewidth=1, label="Raw (downsampled)")

    # Rolling mean pulita
    plt.plot(time_days, values, color="steelblue", linewidth=2,
             label=f"{window_hours}-hour rolling mean")

    # Linea di fine transiente
    if transient_end_day is not None:
        plt.axvline(x=transient_end_day, color="red", linestyle="--",
                    label=f"Transient end ≈ day {transient_end_day:.1f}")
        plt.text(transient_end_day + 0.2,
                 np.nanmax(values) * 0.9,
                 f"Stabilization ≈ day {transient_end_day:.0f}",
                 color="red")
        plt.title(f"{label} (Transient ends ≈ day {transient_end_day:.1f})")
    else:
        plt.title(f"{label} (No transient end detected)")

    plt.xlabel("Simulation time (days)")
    plt.ylabel(label)
    plt.grid(True, linestyle="--", alpha=0.6)
    plt.legend()
    plt.tight_layout()
    plt.show()

    if transient_end_day is not None and info.get("mean_grad") is not None:
        print(f"→ {label} stabilizes around day {transient_end_day:.2f} "
              f"(mean grad: {info['mean_grad']:.4f})")


# In[ ]:


plot_measure_with_transient(
    measure.walk_distances,
    "Average Walking Distance",
    window_hours=4,
    grad_window=12,
    tol_grad=0.01,
    hold=6,
    show_raw=True   # <- niente linee gialle
)

plot_measure_with_transient(
    measure.walk_times,
    "Average Walking Time",
    window_hours=4,
    grad_window=12,
    tol_grad=0.01,
    hold=6,
    show_raw=True
)


# In[ ]:


slot_hours = 4
slots_per_day = int(24 / slot_hours)
total_slots = TOT_DAYS * slots_per_day

rejections_per_slot = np.zeros(total_slots)

for t in measure.rejection_times:
    day = int(t // (24 * 60))
    hour = (t / 60) % 24
    slot = int(hour // slot_hours)

    index = day * slots_per_day + slot
    if 0 <= index < total_slots:
        rejections_per_slot[index] += 1

# Convert slot index → time in days for plotting
time_axis_days = np.arange(total_slots) * (slot_hours / 24)

# Smooth
window = 5
smoothed = pd.Series(rejections_per_slot).rolling(window=window, min_periods=1).mean()

# Detect transient end
end_idx, info_rej = detect_transient_end_gradient(
    ts=smoothed.values,
    window=12,       # smoothing for gradient (slot-based)
    tol_grad=0.01,   # small tolerance because values vary poco in media
    hold=1           # require multiple stable slots
)


plt.figure(figsize=(10, 4))
plt.plot(time_axis_days, rejections_per_slot, alpha=0.35, color="orange",
         label="Rejected per 4-hour slot (raw)")
plt.plot(time_axis_days, smoothed, color="black", linewidth=2,
         label=f"{window}-slot rolling mean")

if end_idx is not None:
    end_day = time_axis_days[end_idx]
    plt.axvline(x=end_day, color='red', linestyle='--',
                label=f'Transient end ≈ day {end_day:.1f}')
    plt.text(end_day + 0.2, max(smoothed)*0.85,
             f"Stabilization ≈ day {end_day:.1f}", color='red')

plt.xlabel("Simulation Time (days)")
plt.ylabel("Rejected Clients (per 4h slot)")
plt.title("Transient Detection on Rejected Clients (4-hour Resolution)")
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()



# In[ ]:

# Time points (minutes) from the simulation
times = np.array(measure.time_points)
unavail = np.array(measure.unavailable_cars)
times_days = times / (60 * 24)


# Aggregate data every 4 hours
slot_minutes = 4 * 60   # 4 hours in minutes

slot_index = (times // slot_minutes).astype(int)
num_slots = slot_index.max() + 1

unavail_per_slot = np.zeros(num_slots)
for s in range(num_slots):
    mask = (slot_index == s)
    if mask.any():
        unavail_per_slot[s] = np.mean(unavail[mask])
    else:
        unavail_per_slot[s] = np.nan  

slot_times_days = (np.arange(num_slots) * slot_minutes) / (60 * 24)

# Rolling mean (smoothing)
window_slots = 4   # ≈ 24 hours smoothing
rolling = pd.Series(unavail_per_slot).rolling(window=window_slots, min_periods=1).mean().values

# Detect end of transient phase
end_idx, info = detect_transient_end_gradient(
    ts=rolling,
    window=6,      # gradient internal smoothing
    tol_grad=0.1,  # sensitivity threshold
    hold=1         # stability confirmation
)

end_day = slot_times_days[end_idx] if end_idx is not None else None


# Final plot
plt.figure(figsize=(10,5))

# Raw 4-hour resampled series
plt.plot(slot_times_days, unavail_per_slot, color="orange", alpha=0.4,
         label="Unavailable cars (4h avg, raw)")

# Smoothed series
plt.plot(slot_times_days, rolling, color="black", linewidth=2,
         label=f"{window_slots}-slot rolling mean")

# Transient end marker
if end_day is not None:
    plt.axvline(x=end_day, color="red", linestyle="--",
                label=f"Transient end ≈ day {end_day:.1f}")
    plt.text(end_day + 0.2,
             np.nanmax(rolling) * 0.9,
             f"Stabilization ≈ day {end_day:.1f}",
             color="red")

plt.xlabel("Simulation Time (days)")
plt.ylabel("Unavailable Cars")
plt.title("Transient Detection on Unavailable Cars (4-hour Resolution)")
plt.grid(True, alpha=0.3)
plt.legend()
plt.show()

if end_day is not None:
    print(f"→ Unavailable cars stabilize around day {end_day:.2f} (mean grad = {info['mean_grad']:.4f})")


# In[ ]:

# --- Define transient phase ---
TRANSIENT_TIME = 3 * 24 * 60  # exclude first 3 simulated days

# Compute confidence intervals excluding transient phase
ci_results = measure.compute_confidence_intervals(transient_time=TRANSIENT_TIME)

print("\n===  Confidence Intervals for Key Metrics (after transient phase) ===")
for k, (mean, low, high) in ci_results.items():
    print(f"{k}: mean = {mean:.2f},  95% CI = ({low:.2f}, {high:.2f})")

ci_overall = measure.compute_confidence_intervals_overall(transient_time = TRANSIENT_TIME)  
clean_ci = {k: (float(round(m, 2)), float(round(l, 2)), float(round(u,2))) for k, (m, l, u) in ci_overall.items()}
print(clean_ci)

