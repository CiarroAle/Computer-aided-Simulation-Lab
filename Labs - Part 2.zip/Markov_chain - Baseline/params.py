# file params.py
from dataclasses import dataclass

@dataclass
class SpeciesParameters:
    """
    Parameters specific to a single species (carnivore or herbivore).
    All rates are per-individual or per-pair per unit time."""
    birth_rate: float                       # base reproduction rate
    death_rate: float                       # natural death rate
    conflict_rate: float                    # rate of intraspecific conflicts
    gestation_rate: float                   # rate ar which gestation advances / leads to birth

@dataclass
class InteractionParameters:
    """
    Parameters governing interactions between species (C-H)
    """
    predation_rate: float                        # base rate of predation encounters
    herbivore_comp_threshold: float              # H threshold above which herbivore competition kicks in
    carnivore_comp_ratio_threshold: float # H/C ratio below which carnivore competition kicks in

    # modifiers during competition 
    herbivore_death_multiplier: float
    herbivore_birth_multiplier: float
    carnivore_death_multiplier: float
    carnivore_birth_multiplier: float

@dataclass
class ModelParameters:
    """
    Global container for all model parameters.
    """
    carnivore: SpeciesParameters
    herbivore: SpeciesParameters
    interaction: InteractionParameters

    # Global sim parameters
    t_max: float                    # default maximum simulation time
    max_events: int            # upperbound for loops
