import numpy as np

class Measures:
    def __init__(self):
        self.stats = {}  # service_name: {"wait_time_sum", "service_time_sum", "n_served", "max_queue_len"}

        # Passenger counts and rejections
        self.total_passengers = 0
        self.rejected_total = 0
        self.rejected_checkin = 0
        self.rejected_security = 0
        self.rejected_gate = 0
        self.rejected_other = 0

        # Total time in system (per passenger)
        self.time_in_system = {
            "LANDSIDE": [],
            "AIRSIDE": []
        }

        # Daily version 
        self.daily_time_in_system = {
            "LANDSIDE": {},
            "AIRSIDE": {}
        }

        # External distributions (arrival times, flight departures)
        self.arrival_times = []
        self.flight_departures = []

        # Daily aggregated queue-level stats
        # daily_stats[service][day] = {"wait_sum", "service_sum", "served"}
        self.daily_stats = {}


        # Hourly waiting times 
        # waiting_time_by_hour[service][hour] = [values]

        self.waiting_time_by_hour = {}

    # ============================================================
    # BASIC REGISTRATIONS
    # ============================================================

    def register_arrival_time(self, t):
        self.arrival_times.append(t)

    def register_flight_departure(self, t):
        self.flight_departures.append(t)

    def register_new_passenger(self):
        self.total_passengers += 1

    # ------------------------------------------------------------

    def register_rejected(self, where):
        """Register a passenger rejected at a given stage."""
        self.rejected_total += 1

        if where == "checkin":
            self.rejected_checkin += 1
        elif where == "security":
            self.rejected_security += 1
        elif where == "gate":
            self.rejected_gate += 1
        else:
            self.rejected_other += 1

    # ============================================================
    # SERVICE ENSURING STRUCTURE
    # ============================================================

    def ensure_service(self, name):
        """Create an entry for a service if it does not exist."""
        if name not in self.stats:
            self.stats[name] = {
                "wait_time_sum": 0.0,
                "service_time_sum": 0.0,
                "n_served": 0,
                "max_queue_len": 0
            }

    def ensure_daily_service(self, name, day):
        """Ensure daily container exists."""
        if name not in self.daily_stats:
            self.daily_stats[name] = {}
        if day not in self.daily_stats[name]:
            self.daily_stats[name][day] = {
                "wait_sum": 0.0,
                "service_sum": 0.0,
                "served": 0
            }

    # ============================================================
    # QUEUE LENGTH TRACKING
    # ============================================================

    def record_queue_len(self, name, qlen):
        self.ensure_service(name)
        self.stats[name]["max_queue_len"] = max(
            self.stats[name]["max_queue_len"], qlen
        )

    # ============================================================
    # WAITING TIME RECORDING
    # ============================================================

    def record_waiting_time(self, name, wait, day):
        self.ensure_service(name)
        self.stats[name]["wait_time_sum"] += wait

        self.ensure_daily_service(name, day)
        self.daily_stats[name][day]["wait_sum"] += wait

    def record_waiting_time_hourly(self, name, hour, wait):
        if name not in self.waiting_time_by_hour:
            self.waiting_time_by_hour[name] = {h: [] for h in range(24)}
        self.waiting_time_by_hour[name][hour].append(wait)

    # ============================================================
    # SERVICE TIME RECORDING
    # ============================================================

    def record_service_time(self, name, st, day):
        self.ensure_service(name)
        self.stats[name]["service_time_sum"] += st
        self.stats[name]["n_served"] += 1

        self.ensure_daily_service(name, day)
        self.daily_stats[name][day]["service_sum"] += st
        self.daily_stats[name][day]["served"] += 1

    # ============================================================
    # TIME IN SYSTEM TRACKING
    # ============================================================

    def record_time_in_system(self, phase, value):
        if phase in self.time_in_system:
            self.time_in_system[phase].append(value)

    def record_daily_time_in_system(self, phase, value, day):
        """Store time-in-system for daily CI computation."""
        if phase not in self.daily_time_in_system:
            return

        if day not in self.daily_time_in_system[phase]:
            self.daily_time_in_system[phase][day] = []

        self.daily_time_in_system[phase][day].append(value)

    # ============================================================
    # SUMMARY GENERATION
    # ============================================================

    def summary(self):
        result = {}

        for name, stats in self.stats.items():
            avg_wait = stats["wait_time_sum"] / stats["n_served"] if stats["n_served"] > 0 else 0
            avg_service = stats["service_time_sum"] / stats["n_served"] if stats["n_served"] > 0 else 0

            result[name] = {
                "avg_wait": avg_wait,
                "avg_service": avg_service,
                "served": stats["n_served"],
                "max_queue": stats["max_queue_len"],
            }

            # ----------------------------
            # DAILY CONFIDENCE INTERVALS
            # ----------------------------
            wait_means = []
            service_means = []

            if name in self.daily_stats:
                for day, dstat in self.daily_stats[name].items():
                    served = dstat["served"]
                    if served > 0:
                        wait_means.append(dstat["wait_sum"] / served)
                        service_means.append(dstat["service_sum"] / served)

            # -------- WAIT CI --------
            if len(wait_means) >= 2:
                mean_wait = float(np.mean(wait_means))
                std_wait  = float(np.std(wait_means, ddof=1))
                se_wait   = std_wait / np.sqrt(len(wait_means))

                # t-value with df = n-1
                df = len(wait_means) - 1
                t_val = 1.96 if df <= 1 else float(abs(np.percentile(
                    np.random.standard_t(df, size=1000000), 97.5
                )))

                ci_low = mean_wait - t_val * se_wait
                ci_high = mean_wait + t_val * se_wait

                result[name]["avg_wait_ci_low"] = ci_low
                result[name]["avg_wait_ci_high"] = ci_high

            # -------- SERVICE CI --------
            if len(service_means) >= 2:
                mean_serv = float(np.mean(service_means))
                std_serv  = float(np.std(service_means, ddof=1))
                se_serv   = std_serv / np.sqrt(len(service_means))

                df = len(service_means) - 1
                t_val = 1.96 if df <= 1 else float(abs(np.percentile(
                    np.random.standard_t(df, size=1000000), 97.5
                )))

                ci_low_s = mean_serv - t_val * se_serv
                ci_high_s = mean_serv + t_val * se_serv

                result[name]["avg_service_ci_low"] = ci_low_s
                result[name]["avg_service_ci_high"] = ci_high_s

        # ---------------------------------------
        # TIME IN SYSTEM CI
        # ---------------------------------------
        for phase in ["LANDSIDE", "AIRSIDE"]:
            times = self.time_in_system[phase]
            if len(times) >= 2:
                mean_ = float(np.mean(times))
                std_  = float(np.std(times, ddof=1))
                se_   = std_ / np.sqrt(len(times))

                df = len(times) - 1
                t_val = 1.96 if df <= 1 else float(abs(np.percentile(
                    np.random.standard_t(df, size=1000000), 97.5
                )))

                ci_low = mean_ - t_val * se_
                ci_high = mean_ + t_val * se_

                result["TIME_IN_SYSTEM_" + phase] = {
                    "avg": mean_,
                    "min": float(np.min(times)),
                    "max": float(np.max(times)),
                    "std": std_,
                    "ci_low": ci_low,
                    "ci_high": ci_high
                }
            else:
                result["TIME_IN_SYSTEM_" + phase] = {
                    "avg": float(np.mean(times)) if times else 0,
                    "min": float(np.min(times)) if times else 0,
                    "max": float(np.max(times)) if times else 0,
                    "std": float(np.std(times)) if times else 0
                }

        # ---------------------------------------
        # REJECTIONS
        # ---------------------------------------
        result["REJECTIONS"] = {
            "total_passengers": self.total_passengers,
            "rejected_total": self.rejected_total,
            "pct_rejected_total": (self.rejected_total / self.total_passengers * 100) if self.total_passengers > 0 else 0,
            "rejected_checkin": self.rejected_checkin,
            "pct_rejected_checkin": (self.rejected_checkin / self.total_passengers * 100) if self.total_passengers > 0 else 0,
            "rejected_security": self.rejected_security,
            "pct_rejected_security": (self.rejected_security / self.total_passengers * 100) if self.total_passengers > 0 else 0,
            "rejected_gate": self.rejected_gate,
            "pct_rejected_gate": (self.rejected_gate / self.total_passengers * 100) if self.total_passengers > 0 else 0,
            "rejected_other": self.rejected_other,
            "pct_rejected_other": (self.rejected_other / self.total_passengers * 100) if self.total_passengers > 0 else 0,
        }

        return result
