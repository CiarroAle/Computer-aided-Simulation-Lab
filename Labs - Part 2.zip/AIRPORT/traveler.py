from typing import Optional, Dict
import config as c

class Traveler:
    def __init__(self, person_id, flight_id, landside_needs, airside_needs):
        self.person_id: str = person_id
        self.flight_id: str = flight_id
        self.flight_ref = None
        self.rejected = False
        self.phase = "LANDSIDE"

        self.arrival_time_airport = None
        self.start_security_time = None
        self.end_security_time = None
        self.end_boarding_time = None

        self.gate_queue_enter_time = None
        self.gate_service_start_time = None

        self.landside_needs: Dict[str, int] = landside_needs if landside_needs else {
            "check_in": 0,
            "toilet": 0,
            "bar": 0,
            "shop": 0
        }

        self.airside_needs: Dict[str, int] = airside_needs if airside_needs else {
            "toilet": 0,
            "bar": 0,
            "shop": 0
        }


        
        