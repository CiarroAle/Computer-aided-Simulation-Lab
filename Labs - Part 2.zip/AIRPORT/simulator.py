import heapq
import random
from typing import List

import config as c

from traveler import Traveler
from companion import AccompanyingPerson
from flight import Flight
from group import Group
from event import Event

from generator import (
    generate_daily_flights,
    generate_passengers_for_flight,
    generate_companions,
    print_flights,
    minutes_to_hhmm,
    time_to_departure
)

from multiserver_queue import LandsideQueue, SecurityQueue, AirsideQueue
from measures import Measures
import matplotlib.pyplot as plt


class Simulator:
    """
    Main discrete-event simulation engine.
    Manages:
    - Future Event Set (FES)
    - Time evolution
    - Airport processes (check-in, security, toilet/bar/shop services)
    - Passenger lifecycle
    """

    def __init__(self, total_days: int):
        self.total_days = total_days
        self.current_time = 0.0

        # Future Event Set (min-heap priority queue)
        self.FES: List[Event] = []

        # Global statistics 
        self.measures = Measures()

        self.landside_toilet = LandsideQueue(
            simulator=self,
            k=c.LANDSIDE_N_TOILETS,
            mean_service=c.AVG_TOILET_TIME,
            name="LANDSIDE_TOILET"
        )

        self.landside_bar = LandsideQueue(
            simulator=self,
            k=c.LANDSIDE_N_BARS,
            mean_service=c.AVG_BAR_TIME,
            name="LANDSIDE_BAR"
        )

        self.security_queue = SecurityQueue(
            simulator=self,
            k=c.SECURITY_N_SERVERS,
            mean_service=c.AVG_SECURITY_TIME
        )

        self.airside_toilet = AirsideQueue(
            simulator=self,
            k=c.AIRSIDE_N_TOILETS,
            mean_service=c.AVG_TOILET_TIME,
            name="AIRSIDE_TOILET"
        )

        self.airside_bar = AirsideQueue(
            simulator=self,
            k=c.AIRSIDE_N_BARS,
            mean_service=c.AVG_BAR_TIME,
            name="AIRSIDE_BAR"
        )



    # EVENT SCHEDULING

    def schedule_event(self, event: Event):
        """Push an event into the FES (min-heap)."""
        heapq.heappush(self.FES, event)



    # INITIALIZATION

    def schedule_first_daily_generation(self):
        """Generate first-day flights at time 0."""
        self.schedule_event(Event(
            time=0,
            event_type="GENERATE_FLIGHTS",
            data={"day": 0}
        ))


    # =====================================================================
    # EVENT HANDLERS
    # =====================================================================


    # FLIGHT GENERATION
    def handle_generate_flights(self, event: Event):
        """Generate flights and passengers for a specific day."""
        day = event.data["day"]

        flights = generate_daily_flights(day)
        all_pax = []

        for f in flights:
            # store departure time for later visualizations/stats
            self.measures.register_flight_departure(f.absolute_departure_time)

            pax_list = generate_passengers_for_flight(f, simulator=self)
            all_pax.extend(pax_list)


        # schedule next day's generation
        next_day = day + 1
        if next_day < self.total_days:
            next_time = next_day * c.DAY_LENGTH
            self.schedule_event(Event(
                time=next_time,
                event_type="GENERATE_FLIGHTS",
                data={"day": next_day}
            ))


    # ---------------------------------------------------------------------
    # PASSENGER ARRIVAL AT AIRPORT
    # ---------------------------------------------------------------------
    def handle_arrival(self, event: Event):
        """Handle passenger arrival: create group and begin landside decisions."""
        traveler: Traveler = event.data["traveler"]
        now = event.time

        traveler.arrival_time_airport = now

        # Generate companions and form group
        companions = generate_companions(traveler)
        group = Group(traveler, companions)

        # Trigger next action
        self.schedule_event(Event(
            time=now,
            event_type="DECIDE_NEXT_ACTION_LANDSIDE",
            data={"group": group}
        ))


    # ---------------------------------------------------------------------
    # DECISION LOGIC — LANDSIDE
    # ---------------------------------------------------------------------
    def handle_decide_next_action_landside(self, event: Event):
        """
        Determine what a passenger group should do next while still landside.
        Priority:
        1. Check-in
        2. Toilet
        3. Bar
        4. Shop
        5. Security (if no more needs OR time pressure)
        """
        group: Group = event.data["group"]
        traveler = group.traveler
        now = event.time

        # Time to departure
        ttd = time_to_departure(traveler, now)

        # --- SECURITY DEADLINE CHECK ---
        if ttd < c.SECURITY_DEADLINE:

            # eliminate optional needs
            traveler.landside_needs["toilet"] = 0
            traveler.landside_needs["bar"] = 0
            traveler.landside_needs["shop"] = 0

            # check-in has absolute priority
            if traveler.landside_needs.get("check_in", 0) == 1:
                self.schedule_event(Event(now, "GO_TO_CHECKIN", {"group": group}))
                return

            self.schedule_event(Event(now, "GO_TO_SECURITY", {"group": group}))
            return

        # --- PRIORITY 1: Check-in ---
        if traveler.landside_needs["check_in"] == 1:
            self.schedule_event(Event(now, "GO_TO_CHECKIN", data={"group": group}))
            return

        # Convenience function for checking group-level needs
        def member_need(member, key):
            return member.landside_needs.get(key, 0)

        # --- PRIORITY 2: Toilet ---
        if any(member_need(m, "toilet") == 1 for m in group.all_members()):
            self.schedule_event(Event(now, "GO_LANDSIDE_TOILET", data={"group": group}))
            return

        # --- PRIORITY 3: Bar ---
        if any(member_need(m, "bar") == 1 for m in group.all_members()):
            self.schedule_event(Event(now, "GO_LANDSIDE_BAR", data={"group": group}))
            return

        # --- PRIORITY 4: Shop ---
        if any(member_need(m, "shop") == 1 for m in group.all_members()):
            self.schedule_event(Event(now, "GO_LANDSIDE_SHOP", data={"group": group}))
            return

        # --- NO MORE LANDSIDE NEEDS → SECURITY ---
        self.schedule_event(Event(now, "GO_TO_SECURITY", data={"group": group}))


    # DECISION LOGIC — AIRSIDE (single traveler)
    def handle_decide_next_action_airside(self, event: Event):
        """
        Determine what the traveler should do next in the airside area.
        Priority:
        1. Toilet
        2. Bar
        3. Shop
        4. Gate
        """
        traveler: Traveler = event.data["traveler"]
        now = event.time

        # 1. Toilet
        if traveler.airside_needs.get("toilet", 0) == 1:
            self.schedule_event(Event(now, "GO_AIRSIDE_TOILET", {"traveler": traveler}))
            return

        # 2. Bar
        if traveler.airside_needs.get("bar", 0) == 1:
            self.schedule_event(Event(now, "GO_AIRSIDE_BAR", {"traveler": traveler}))
            return

        # 3. Shop
        if traveler.airside_needs.get("shop", 0) == 1:
            self.schedule_event(Event(now, "GO_AIRSIDE_SHOP", {"traveler": traveler}))
            return

        # 4. Go to gate
        self.schedule_event(Event(now, "GO_TO_GATE", {"traveler": traveler}))



    # CHECK-IN PROCESS
    def handle_go_to_checkin(self, event: Event):
        """
        Passenger moves to the check-in area.
        Three cases:
        1) Arrives before opening: wait until opening
        2) Arrives after closing: rejected
        3) Check-in open: enter queue
        """
        group: Group = event.data["group"]
        traveler: Traveler = group.traveler
        flight: Flight = traveler.flight_ref
        now = event.time

        # --- Case 1: Before opening ---
        if now < flight.checkin_open_time:
            self.schedule_event(Event(
                flight.checkin_open_time,
                "GO_TO_CHECKIN",
                data={"group": group}
            ))
            return

        # --- Case 2: After closing → rejection ---
        if now > flight.checkin_close_time:
            traveler.rejected = True
            self.measures.register_rejected("checkin")
            return

        # --- Case 3: Queue admission ---
        was_empty = (len(flight.checkin_queue) == 0)
        flight.checkin_queue.append(group)

        # Immediate service if server free
        if was_empty and flight.checkin_busy_until <= now:
            self.schedule_event(Event(now, "START_CHECKIN", data={"flight": flight}))

        group.checkin_queue_enter_time = now
        self.measures.record_queue_len("CHECKIN", len(flight.checkin_queue))


    def handle_start_checkin(self, event: Event):
        """Start the check-in service for the next group in queue."""
        flight: Flight = event.data["flight"]
        now = event.time
        day = int(now // c.DAY_LENGTH)

        if not flight.checkin_queue:
            return

        # Serve next group
        group: Group = flight.checkin_queue.pop(0)
        traveler = group.traveler

        # Service time (exponential)
        service_time = random.expovariate(1 / c.AVG_CHECKIN_TIME)
        end_time = now + service_time

        waiting = now - group.checkin_queue_enter_time
        self.measures.record_waiting_time("CHECKIN", waiting, day)

        group.checkin_service_start_time = now
        flight.checkin_busy_until = end_time

        self.schedule_event(Event(
            end_time,
            "END_CHECKIN",
            data={"group": group, "flight": flight}
        ))


    def handle_end_checkin(self, event: Event):
        """Complete check-in and return to landside decision logic."""
        group: Group = event.data["group"]
        flight: Flight = event.data["flight"]
        traveler: Traveler = group.traveler
        now = event.time
        day = int(now // c.DAY_LENGTH)

        traveler.landside_needs["check_in"] = 0

        # Continue passenger journey
        self.schedule_event(Event(
            now,
            "DECIDE_NEXT_ACTION_LANDSIDE",
            data={"group": group}
        ))

        # Serve next if queue not empty
        if flight.checkin_queue:
            self.schedule_event(Event(now, "START_CHECKIN", data={"flight": flight}))

        service_time = now - group.checkin_service_start_time
        self.measures.record_service_time("CHECKIN", service_time, day)


    # LANDSIDE SERVICES (TOILET, BAR, SHOP)
    def handle_go_landside_toilet(self, event: Event):
        group = event.data["group"]
        now = event.time

        members = [m for m in group.all_members() if m.landside_needs["toilet"] == 1]

        self.landside_toilet.add_group_jobs(group, members)


    def handle_go_landside_bar(self, event: Event):
        group = event.data["group"]
        now = event.time

        members = [m for m in group.all_members() if m.landside_needs.get("bar", 0) == 1]

        self.landside_bar.add_group_jobs(group, members)


    def handle_go_landside_shop(self, event: Event):
        """
        Landside shop is a delay-based service (not a queue).
        Group stays for an exponentially-distributed time, then continues.
        """
        group = event.data["group"]
        now = event.time
        day = int(now // c.DAY_LENGTH)

        duration = random.expovariate(1 / c.AVG_SHOP_TIME)
        end_time = now + duration

        self.measures.record_service_time("LANDSIDE_SHOP", duration, day)

        self.schedule_event(Event(end_time, "END_LANDSIDE_SHOP", data={"group": group}))


    def handle_end_landside_shop(self, event: Event):
        group = event.data["group"]
        now = event.time

        for m in group.all_members():
            m.landside_needs["shop"] = 0

        self.schedule_event(Event(
            now,
            "DECIDE_NEXT_ACTION_LANDSIDE",
            data={"group": group}
        ))

    # SECURITY PROCESS
    def handle_go_to_security(self, event: Event):
        """
        Group reaches security.
        Companions leave the system; only the main traveler continues.
        """
        group: Group = event.data["group"]
        traveler: Traveler = group.traveler
        now = event.time
        flight: Flight = traveler.flight_ref

        # Gate deadline check
        deadline = flight.absolute_departure_time - c.GATE_CLOSE_BEFORE_DEP
        if now > deadline:
            traveler.rejected = True
            self.measures.register_rejected("security")
            return

        traveler.phase = "SECURITY"

        # Only traveler enters security queue
        self.security_queue.add_group_jobs(group=None, members=[traveler])

    # AIRSIDE SERVICES
    def handle_go_airside_toilet(self, event: Event):
        traveler = event.data["traveler"]
        now = event.time

        if traveler.airside_needs.get("toilet", 0) == 0:
            return

        self.airside_toilet.add_group_jobs(None, [traveler])


    def handle_go_airside_bar(self, event: Event):
        traveler = event.data["traveler"]
        now = event.time

        if traveler.airside_needs.get("bar", 0) == 0:
            return

        self.airside_bar.add_group_jobs(None, [traveler])


    def handle_go_airside_shop(self, event: Event):
        """
        Airside shop behaves like landside shop: delay without queue.
        """
        traveler = event.data["traveler"]
        now = event.time
        day = int(now // c.DAY_LENGTH)

        duration = random.expovariate(1 / c.AVG_SHOP_TIME)
        end_time = now + duration

        self.measures.record_service_time("AIRSIDE_SHOP", duration, day)

        self.schedule_event(Event(end_time, "END_AIRSIDE_SHOP", data={"traveler": traveler}))


    def handle_end_airside_shop(self, event: Event):
        traveler = event.data["traveler"]
        now = event.time

        traveler.airside_needs["shop"] = 0

        self.schedule_event(Event(
            now,
            "DECIDE_NEXT_ACTION_AIRSIDE",
            data={"traveler": traveler}
        ))

    # GATE / BOARDING PROCESS
    def handle_go_to_gate(self, event: Event):
        """Traveler proceeds to boarding gate."""
        traveler: Traveler = event.data["traveler"]
        now = event.time
        flight: Flight = traveler.flight_ref

        # Before opening → wait
        if now < flight.gate_open_time:
            self.schedule_event(Event(flight.gate_open_time, "GO_TO_GATE", data={"traveler": traveler}))
            return

        # After closing → missed flight
        if now > flight.gate_close_time:
            traveler.rejected = True
            self.measures.register_rejected("gate")
            return

        # Enter gate queue
        was_empty = (len(flight.gate_queue) == 0)
        traveler.gate_queue_enter_time = now
        flight.gate_queue.append(traveler)

        self.measures.record_queue_len("BOARDING", len(flight.gate_queue))

        # If server free, start immediately
        if was_empty and flight.gate_busy_until <= now:
            self.schedule_event(Event(now, "START_BOARDING", data={"flight": flight}))


    def handle_start_boarding(self, event: Event):
        """Start boarding for next passenger."""
        flight = event.data["flight"]
        now = event.time
        day = int(now // c.DAY_LENGTH)

        if not flight.gate_queue:
            return

        traveler = flight.gate_queue.pop(0)

        waiting = now - traveler.gate_queue_enter_time
        self.measures.record_waiting_time("BOARDING", waiting, day)

        # exponential boarding time
        service_time = random.expovariate(1 / c.AVG_BOARDING_TIME)
        end_time = now + service_time

        self.measures.record_service_time("BOARDING", service_time, day)
        flight.gate_busy_until = end_time

        self.schedule_event(Event(
            end_time,
            "END_BOARDING",
            data={"traveler": traveler, "flight": flight}
        ))


    def handle_end_boarding(self, event: Event):
        """Complete boarding and compute Time in System (landside/airside)."""
        traveler = event.data["traveler"]
        flight = event.data["flight"]
        now = event.time
        day = int(now // c.DAY_LENGTH)

        traveler.end_boarding_time = now

        # Time spent in landside phase
        T_landside = traveler.start_security_time - traveler.arrival_time_airport

        # Time spent in airside phase
        T_airside = traveler.end_boarding_time - traveler.end_security_time

        # Global measures
        self.measures.record_time_in_system("LANDSIDE", T_landside)
        self.measures.record_time_in_system("AIRSIDE", T_airside)

        # Daily (needed for confidence intervals)
        self.measures.record_daily_time_in_system("LANDSIDE", T_landside, day)
        self.measures.record_daily_time_in_system("AIRSIDE", T_airside, day)

        traveler.phase = "ONBOARD"

        # Serve next traveler in queue
        if flight.gate_queue:
            self.schedule_event(Event(now, "START_BOARDING", data={"flight": flight}))



# ======================================================================
# MAIN SIMULATION LOOP
# ======================================================================

    def run(self):
        """Main DES loop. Extract events from the FES and dispatch them."""

        print("=== STARTING AIRPORT SIMULATION ===")
        self.schedule_first_daily_generation()

        # EVENT DISPATCH TABLE
        dispatch = {
            # Flight generation / arrivals
            "GENERATE_FLIGHTS": self.handle_generate_flights,
            "ARRIVAL_AT_AIRPORT": self.handle_arrival,

            # Landside flow
            "DECIDE_NEXT_ACTION_LANDSIDE": self.handle_decide_next_action_landside,
            "GO_TO_CHECKIN": self.handle_go_to_checkin,
            "START_CHECKIN": self.handle_start_checkin,
            "END_CHECKIN": self.handle_end_checkin,

            "GO_LANDSIDE_TOILET": self.handle_go_landside_toilet,
            "START_LANDSIDE_TOILET": self.landside_toilet.start_service,
            "END_LANDSIDE_TOILET": self.landside_toilet.end_service,

            "GO_LANDSIDE_BAR": self.handle_go_landside_bar,
            "START_LANDSIDE_BAR": self.landside_bar.start_service,
            "END_LANDSIDE_BAR": self.landside_bar.end_service,

            "GO_LANDSIDE_SHOP": self.handle_go_landside_shop,
            "END_LANDSIDE_SHOP": self.handle_end_landside_shop,

            # Security
            "GO_TO_SECURITY": self.handle_go_to_security,
            "START_SECURITY": self.security_queue.start_service,
            "END_SECURITY": self.security_queue.end_service,

            # Airside flow
            "DECIDE_NEXT_ACTION_AIRSIDE": self.handle_decide_next_action_airside,
            "GO_AIRSIDE_TOILET": self.handle_go_airside_toilet,
            "START_AIRSIDE_TOILET": self.airside_toilet.start_service,
            "END_AIRSIDE_TOILET": self.airside_toilet.end_service,

            "GO_AIRSIDE_BAR": self.handle_go_airside_bar,
            "START_AIRSIDE_BAR": self.airside_bar.start_service,
            "END_AIRSIDE_BAR": self.airside_bar.end_service,

            "GO_AIRSIDE_SHOP": self.handle_go_airside_shop,
            "END_AIRSIDE_SHOP": self.handle_end_airside_shop,

            # Boarding
            "GO_TO_GATE": self.handle_go_to_gate,
            "START_BOARDING": self.handle_start_boarding,
            "END_BOARDING": self.handle_end_boarding
        }

        # ==========================================================
        # MAIN LOOP
        # ==========================================================
        while self.FES:
            event: Event = heapq.heappop(self.FES)
            self.current_time = event.time

            # stopping condition
            if self.current_time >= self.total_days * c.DAY_LENGTH:
                print("=== SIMULATION ENDED ===")
                break

            handler = dispatch.get(event.event_type)
            if handler:
                handler(event)
            else:
                print(f"[WARNING] Unknown event type: {event.event_type}")

        # FINAL MEASURES
        self._print_final_measures()


    # ======================================================================
    # FINAL REPORT + PLOTS
    # ======================================================================

    def _print_final_measures(self):
        """Prints all summary metrics + confidence intervals + plots."""

        summary = self.measures.summary()

        print("\n==========================")
        print("=== FINAL MEASURES ===")
        print("==========================")

        # ------------------------------
        # SERVICE METRICS
        # ------------------------------
        for name, stats in summary.items():
            if name.startswith("TIME_IN_SYSTEM_"):
                continue  # printed later

            print(f"\n--- {name} ---")

            if name != "REJECTIONS":
                print(f"Average waiting time:  {stats['avg_wait']:.2f}")
                print(f"Average service time:  {stats['avg_service']:.2f}")
                print(f"Served:               {stats['served']}")
                print(f"Max queue length:     {stats['max_queue']}")
            else:
                print(f"Total passengers:     {stats['total_passengers']}")
                print(f"Total rejected:       {stats['rejected_total']} ({stats['pct_rejected_total']:.2f}%)")
                print(f"Rejected at check-in: {stats['rejected_checkin']} ({stats['pct_rejected_checkin']:.2f}%)")
                print(f"Rejected at security: {stats['rejected_security']} ({stats['pct_rejected_security']:.2f}%)")
                print(f"Rejected at gate:     {stats['rejected_gate']} ({stats['pct_rejected_gate']:.2f}%)")
                print(f"Rejected other:       {stats['rejected_other']} ({stats['pct_rejected_other']:.2f}%)")

        # ------------------------------
        # TIME IN SYSTEM
        # ------------------------------
        print("\n=== TIME IN SYSTEM ===")

        for phase in ["LANDSIDE", "AIRSIDE"]:
            key = f"TIME_IN_SYSTEM_{phase}"
            if key not in summary:
                continue
            s = summary[key]
            print(f"\n{phase}:")
            print(f"  Average: {s['avg']:.2f} min")
            print(f"  Min:     {s['min']:.2f}")
            print(f"  Max:     {s['max']:.2f}")
            print(f"  Std:     {s['std']:.2f}")

            if "ci_low" in s:
                print(f"  CI95%:  [{s['ci_low']:.2f}, {s['ci_high']:.2f}]")

        # ------------------------------
        # SERVER UTILIZATION
        # ------------------------------
        print("\n=== SERVER UTILIZATION ===")
        queues = {
            "LANDSIDE_TOILET": self.landside_toilet,
            "LANDSIDE_BAR": self.landside_bar,
            "AIRSIDE_TOILET": self.airside_toilet,
            "AIRSIDE_BAR": self.airside_bar,
        }

        for name, q in queues.items():
            util = q.compute_utilization()
            perc = [round(u * 100, 2) for u in util]
            print(f"{name}: {perc}%")

        # ------------------------------
        # CONFIDENCE INTERVALS
        # ------------------------------
        print("\n=== CONFIDENCE INTERVALS (95%) ===")
        for name, stats in summary.items():
            if "avg_wait_ci_low" in stats:
                print(f"\n{name}:")
                print(f"  Mean waiting time: {stats['avg_wait']:.2f}")
                print(f"  CI95% wait:        [{stats['avg_wait_ci_low']:.2f}, {stats['avg_wait_ci_high']:.2f}]")
            if "avg_service_ci_low" in stats:
                print(f"  Mean service time: {stats['avg_service']:.2f}")
                print(f"  CI95% service:     [{stats['avg_service_ci_low']:.2f}, {stats['avg_service_ci_high']:.2f}]")

        # ==========================================================
        # PLOTS
        # ==========================================================
        self._plot_arrival_distribution()
        self._plot_departure_distribution()
        self._plot_waiting_times_by_hour()



    # ======================================================================
    # PLOT FUNCTIONS
    # ======================================================================

    def _plot_arrival_distribution(self):
        arr_hours = [(t % c.DAY_LENGTH) / 60 for t in self.measures.arrival_times]

        plt.figure(figsize=(10,5))
        plt.hist(arr_hours, bins=24, edgecolor="black")
        plt.xlabel("Hour of day")
        plt.ylabel("Arrivals")
        plt.title("Passenger Arrival Distribution")
        plt.xticks(range(25))
        plt.grid(alpha=0.3)
        plt.tight_layout()
        plt.show()


    def _plot_departure_distribution(self):
        dep_hours = [(t % c.DAY_LENGTH) / 60 for t in self.measures.flight_departures]

        plt.figure(figsize=(10,5))
        plt.hist(dep_hours, bins=24, edgecolor="black", color="orange")
        plt.xlabel("Hour of day")
        plt.ylabel("Departing flights")
        plt.title("Flight Departure Distribution")
        plt.xticks(range(25))
        plt.grid(alpha=0.3)
        plt.tight_layout()
        plt.show()


    def _plot_waiting_times_by_hour(self):
        services = [
            "LANDSIDE_TOILET", "LANDSIDE_BAR", "SECURITY",
            "AIRSIDE_TOILET", "AIRSIDE_BAR", "GATE"
        ]

        for name in services:
            hourly = self.measures.waiting_time_by_hour.get(name)
            if not hourly:
                continue

            avg = [
                (sum(vals)/len(vals)) if vals else 0
                for h, vals in hourly.items()
            ]

            plt.figure(figsize=(10,5))
            plt.plot(range(24), avg, marker="o")
            plt.xlabel("Hour of day")
            plt.ylabel("Mean waiting time (min)")
            plt.title(f"Hourly Waiting Time — {name}")
            plt.xticks(range(24))
            plt.grid(alpha=0.3)
            plt.tight_layout()
            plt.show()





