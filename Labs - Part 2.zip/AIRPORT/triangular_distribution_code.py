import numpy as np
import matplotlib.pyplot as plt

# Parameters
min_val = 70
mode_val = 90
max_val = 100

# Generate x values
x = np.linspace(min_val, max_val, 500)

# Triangular PDF
pdf = np.zeros_like(x)
left = (mode_val - min_val)
right = (max_val - mode_val)

# Increasing part
inc = (x >= min_val) & (x <= mode_val)
pdf[inc] = (x[inc] - min_val) / (left * (max_val - min_val))

# Decreasing part
dec = (x > mode_val) & (x <= max_val)
pdf[dec] = (max_val - x[dec]) / (right * (max_val - min_val))

# Plot
plt.figure(figsize=(7,4))
plt.plot(x, pdf)
plt.xlabel("Passenger Load")
plt.ylabel("Density")
plt.grid(True)
plt.show()
