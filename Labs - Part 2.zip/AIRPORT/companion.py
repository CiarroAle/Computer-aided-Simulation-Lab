class AccompanyingPerson:
    def __init__(self, person_id: int, group_id: str, landside_needs: dict):
        self.person_id = person_id
        self.group_id = group_id

        self.landside_needs = landside_needs or {
            "toilet": 0,
            "bar": 0,
            "shop": 0
        }