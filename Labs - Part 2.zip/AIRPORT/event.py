class Event:
    def __init__(self, time, event_type, data=None, event_id=0):
        self.time = time
        self.event_type = event_type
        self.data = data or {}
        self.event_id = event_id


    def __lt__(self, other):
        if self.time == other.time:
            return self.event_id < other.event_id
        return self.time < other.time