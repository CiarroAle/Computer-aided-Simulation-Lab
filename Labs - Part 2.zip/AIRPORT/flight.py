class Flight:
    def __init__(self, flight_id: str, departure_time: int):
        self.flight_id = flight_id
        self.departure_time = departure_time
        self.absolute_departure_time = None
        self.n_passengers = 0
        self.passengers = []

        # check-in parameters (associated with the flight)
        self.checkin_open_time = None
        self.checkin_close_time = None
        self.checkin_queue = []
        self.checkin_busy_until = 0        

        # gate parameters 
        self.gate_open_time = None
        self.gate_close_time = None
        self.gate_queue = []
        self.gate_busy_until = 0 

    def add_passenger(self, traveler):
        self.passengers.append(traveler)