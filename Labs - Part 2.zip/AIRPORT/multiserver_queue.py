import random
from event import Event
from generator import minutes_to_hhmm, time_to_departure
import config as c


# ===============================================================
# LANDSIDE M/M/k QUEUE (toilets and bars)
# ===============================================================

class LandsideQueue:
    def __init__(self, simulator, k, mean_service, name: str):
        """
        Generic M/M/k queue used for landside services.
        Each traveler in a group generates one job.
        """
        self.sim = simulator
        self.k = k
        self.mean_service = mean_service
        self.name = name

        self.queue = []                           
        self.busy_until = [0] * k                 # server availability times
        self.server_busy_time = [0.0] * k         # total busy time per server
        self.server_last_update = [0.0] * k       # last start of busy for each server
        self.pending_jobs = {}             

    # -----------------------------------------------------------

    def add_group_jobs(self, group, members):
        """
        Add all group members to the queue.
        """
        gid = id(group)
        self.pending_jobs[gid] = len(members)
        now = self.sim.current_time

        for m in members:
            self.queue.append({
                "group": group,
                "member": m,
                "gid": gid,
                "enter_time": now
            })

        # Start service if servers are free
        for s in range(self.k):
            if self.busy_until[s] <= now and self.queue:
                self.sim.schedule_event(Event(
                    now,
                    f"START_{self.name}",
                    data={"server": s, "queue": self}
                ))

        # Record queue length
        self.sim.measures.record_queue_len(self.name, len(self.queue))

    # -----------------------------------------------------------

    def start_service(self, event: Event):
        """
        Start servicing one job.
        """
        server = event.data["server"]
        now = self.sim.current_time
        hour = int((now % c.DAY_LENGTH) // 60)
        day = int(now // c.DAY_LENGTH)

        if not self.queue:
            return

        job = self.queue.pop(0)
        group, member = job["group"], job["member"]
        gid = job["gid"]

        # Draw service duration
        duration = random.expovariate(1 / self.mean_service)
        end_time = now + duration

        # Server status update
        self.server_last_update[server] = now
        self.busy_until[server] = end_time

        # Compute waiting time
        waiting = now - job["enter_time"]
        self.sim.measures.record_waiting_time(self.name, waiting, day)
        self.sim.measures.record_waiting_time_hourly(self.name, hour, waiting)

        # Schedule service completion
        self.sim.schedule_event(Event(
            end_time,
            f"END_{self.name}",
            data={
                "server": server,
                "group": group,
                "member": member,
                "gid": gid,
                "queue": self,
                "duration": duration
            }
        ))

    # -----------------------------------------------------------

    def end_service(self, event: Event):
        """
        End of service for one member of a group.
        """
        queue = event.data["queue"]
        group = event.data["group"]
        member = event.data["member"]
        server = event.data["server"]
        gid = event.data["gid"]
        duration = event.data["duration"]

        now = self.sim.current_time
        day = int(now // c.DAY_LENGTH)


        # Mark need as satisfied
        if hasattr(member, "landside_needs"):
            key = self.name.split("_")[1].lower() 
            member.landside_needs[key] = 0

        # Update server status
        queue.busy_until[server] = now
        busy_duration = now - self.server_last_update[server]
        self.server_busy_time[server] += busy_duration

        # Record service time
        self.sim.measures.record_service_time(self.name, duration, day)

        # Start next service if possible
        if queue.queue:
            self.sim.schedule_event(Event(
                now,
                f"START_{self.name}",
                data={"server": server, "queue": queue}
            ))

        # Update group pending jobs
        queue.pending_jobs[gid] -= 1
        if queue.pending_jobs[gid] > 0:
            return

        # All jobs completed: remove group from pending
        del queue.pending_jobs[gid]

        # Continue landside process
        self.sim.schedule_event(Event(
            now,
            "DECIDE_NEXT_ACTION_LANDSIDE",
            data={"group": group}
        ))

    # -----------------------------------------------------------

    def compute_utilization(self):
        """
        Compute server utilization as busy_time / simulation_time.
        """
        sim_time = self.sim.current_time
        return [busy / sim_time for busy in self.server_busy_time]


# ===============================================================
# SECURITY QUEUE 
# ===============================================================

class SecurityQueue:
    def __init__(self, simulator, k, mean_service):
        self.sim = simulator
        self.k = k
        self.mean_service = mean_service
        self.name = "SECURITY"

        self.queue = []
        self.busy_until = [0] * k
        self.pending_jobs = {}

    # -----------------------------------------------------------

    def add_group_jobs(self, group, members):
        """
        Add all group members to security queue.
        """
        traveler = members[0]
        gid = id(traveler)
        now = self.sim.current_time

        self.pending_jobs[gid] = len(members)

        for m in members:
            self.queue.append({"member": m, "gid": gid, "enter_time": now})

        for s in range(self.k):
            if self.busy_until[s] <= now and self.queue:
                self.sim.schedule_event(Event(
                    now,
                    "START_SECURITY",
                    data={"server": s, "queue": self}
                ))

        self.sim.measures.record_queue_len(self.name, len(self.queue))

    # -----------------------------------------------------------

    def start_service(self, event: Event):
        """
        Start security screening for one traveler.
        """
        server = event.data["server"]
        now = self.sim.current_time
        hour = int((now % c.DAY_LENGTH) // 60)
        day = int(now // c.DAY_LENGTH)

        if not self.queue:
            return

        job = self.queue.pop(0)
        member = job["member"]
        gid = job["gid"]

        # Service duration
        duration = random.expovariate(1 / self.mean_service)
        end_time = now + duration
        self.busy_until[server] = end_time

        # First time entering security
        if member.start_security_time is None:
            member.start_security_time = now

        # Waiting time
        waiting = now - job["enter_time"]
        self.sim.measures.record_waiting_time(self.name, waiting, day)
        self.sim.measures.record_waiting_time_hourly(self.name, hour, waiting)

        # Schedule completion
        self.sim.schedule_event(Event(
            end_time,
            "END_SECURITY",
            data={
                "server": server,
                "member": member,
                "gid": gid,
                "queue": self,
                "duration": duration
            }
        ))

    # -----------------------------------------------------------

    def end_service(self, event: Event):
        """
        Completion of screening for one passenger.
        """
        queue = event.data["queue"]
        member = event.data["member"]
        server = event.data["server"]
        gid = event.data["gid"]
        duration = event.data["duration"]

        now = self.sim.current_time
        day = int(now // c.DAY_LENGTH)

        # Mark time
        member.end_security_time = now
        queue.busy_until[server] = now

        # Start next job
        if queue.queue:
            self.sim.schedule_event(Event(
                now,
                "START_SECURITY",
                data={"server": server, "queue": queue}
            ))

        # Group jobs update
        queue.pending_jobs[gid] -= 1
        if queue.pending_jobs[gid] > 0:
            return

        # All group jobs finished
        del queue.pending_jobs[gid]

        traveler = member

        # Check gate deadline
        if time_to_departure(traveler, now) < c.GATE_CLOSE_BEFORE_DEP:
            traveler.rejected = True
            return

        # Move to airside
        traveler.phase = "AIRSIDE"

        # Record service time
        self.sim.measures.record_service_time(self.name, duration, day)

        # Next decision
        self.sim.schedule_event(Event(
            now,
            "DECIDE_NEXT_ACTION_AIRSIDE",
            data={"traveler": traveler}
        ))


# ===============================================================
# AIRSIDE M/M/k QUEUE (toilet and bar)
# ===============================================================

class AirsideQueue:
    """
    Generic M/M/k queue for airside services (toilet and bar).
    """

    def __init__(self, simulator, k, mean_service, name: str):
        self.sim = simulator
        self.k = k
        self.mean_service = mean_service
        self.name = name

        self.queue = []
        self.busy_until = [0] * k
        self.server_busy_time = [0.0] * k
        self.server_last_update = [0.0] * k
        self.pending_jobs = {}

    # -----------------------------------------------------------

    def add_group_jobs(self, group, members):
        """
        Airside uses only single-traveler jobs.
        """
        traveler = members[0]
        gid = id(traveler)
        now = self.sim.current_time

        self.pending_jobs[gid] = 1
        self.queue.append({"group": None, "member": traveler, "gid": gid, "enter_time": now})

        for s in range(self.k):
            if self.busy_until[s] <= now and self.queue:
                self.sim.schedule_event(Event(
                    now,
                    f"START_{self.name}",
                    data={"server": s, "queue": self}
                ))

        self.sim.measures.record_queue_len(self.name, len(self.queue))

    # -----------------------------------------------------------

    def start_service(self, event: Event):
        server = event.data["server"]
        now = self.sim.current_time
        hour = int((now % c.DAY_LENGTH) // 60)
        day = int(now // c.DAY_LENGTH)

        if not self.queue:
            return

        job = self.queue.pop(0)
        member = job["member"]
        gid = job["gid"]

        # Service duration
        duration = random.expovariate(1 / self.mean_service)
        end_time = now + duration

        self.busy_until[server] = end_time
        self.server_last_update[server] = now

        # Waiting time
        waiting = now - job["enter_time"]
        self.sim.measures.record_waiting_time(self.name, waiting, day)
        self.sim.measures.record_waiting_time_hourly(self.name, hour, waiting)

        self.sim.schedule_event(Event(
            end_time,
            f"END_{self.name}",
            data={
                "server": server,
                "member": member,
                "gid": gid,
                "queue": self,
                "duration": duration
            }
        ))

    # -----------------------------------------------------------

    def end_service(self, event: Event):
        queue = event.data["queue"]
        member = event.data["member"]
        server = event.data["server"]
        gid = event.data["gid"]
        duration = event.data["duration"]

        now = self.sim.current_time
        day = int(now // c.DAY_LENGTH)

        # Mark need as done
        if hasattr(member, "airside_needs"):
            key = self.name.split("_")[1].lower()
            member.airside_needs[key] = 0

        # Server busy update
        busy_duration = now - self.server_last_update[server]
        self.server_busy_time[server] += busy_duration

        queue.busy_until[server] = now

        # Start next job
        if queue.queue:
            self.sim.schedule_event(Event(
                now,
                f"START_{self.name}",
                data={"server": server, "queue": queue}
            ))

        # Remove pending job
        queue.pending_jobs[gid] -= 1
        if queue.pending_jobs[gid] > 0:
            return
        del queue.pending_jobs[gid]

        # Record service time
        self.sim.measures.record_service_time(self.name, duration, day)

        # Go back to airside decision
        traveler = member

        self.sim.schedule_event(Event(
            now,
            "DECIDE_NEXT_ACTION_AIRSIDE",
            data={"traveler": traveler}
        ))

    # -----------------------------------------------------------

    def compute_utilization(self):
        sim_time = self.sim.current_time
        return [busy / sim_time for busy in self.server_busy_time]

