from simulator import Simulator
import config as c
import random

random.seed(42)

if __name__ == "__main__":
    sim = Simulator(total_days=c.TOT_DAYS)
    sim.run()


