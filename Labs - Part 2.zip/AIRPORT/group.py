class Group:
    def __init__(self, traveler, companions):
        self.traveler = traveler
        self.companions = companions        # list[AccompanyingPerson]
        self.phase = "LANDSIDE"
        self.current_activity = "IDLE"

        self.checkin_queue_enter_time = None
        self.checkin_service_start_time = None

        self.group_id = traveler.person_id 

    
    def all_members(self):
        return [self.traveler] + self.companions
    
    def size(self):
        return 1 + len(self.companions)
    