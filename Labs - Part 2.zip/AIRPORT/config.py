# -------------------------------------------------------------------------
# SIMULATION SETTINGS
# -------------------------------------------------------------------------

TOT_DAYS = 15                 # Number of simulated days
DAY_LENGTH = 1440             # Minutes in one day (24 * 60)
MAX_COMPANIONS = 2            # Max number of companions per traveler


# -------------------------------------------------------------------------
# PASSENGER NEEDS PROBABILITIES
# -------------------------------------------------------------------------

P_CHECKIN = 0.3
P_TOILET_LANDSIDE = 0.5
P_BAR = 0.3
P_SHOP = 0.2

# Airside toilet probability 
P_TOILET_AIRSIDE_IF_USED_LANDSIDE = 0.05
P_TOILET_AIRSIDE_IF_NOT_USED_LANDSIDE = 0.7


# -------------------------------------------------------------------------
# FLIGHT GENERATION
# -------------------------------------------------------------------------

# Number of daily flights varies realistically
MIN_DAILY_FLIGHTS = 15
MAX_DAILY_FLIGHTS = 20

#  Departure distribution (Eurocontrol-based)
FLIGHT_DISTRIBUTION = [
    (5*60,  8*60,  0.28),   # 05:00–08:00   – Morning peak
    (8*60,  11*60, 0.20),   # 08:00–11:00
    (11*60, 14*60, 0.14),   # 11:00–14:00
    (14*60, 17*60, 0.10),   # 14:00–17:00
    (17*60, 20*60, 0.22),   # 17:00–20:00   – Evening peak
    (20*60, 23*60, 0.06),   # 20:00–23:00   
]

# -------------------------------------------------------------------------
# FLIGHT CAPACITY AND ARRIVAL WINDOWS
# -------------------------------------------------------------------------

FLIGHT_CAPACITY = {
    "min": 70,
    "max": 100,
    "mode": 90
}

# Passenger arrivals relative to departure time (in minutes)
START_ARRIVALS = 240          # Earliest arrival: dep - 240 min (4h)
END_ARRIVALS = 80             # Latest arrival:   dep - 80 min


# -------------------------------------------------------------------------
# CHECK-IN PARAMETERS
# -------------------------------------------------------------------------

OPEN_CHECKIN_BEFORE_DEP_MIN = 200    # Check-in opens 200 min before dep
CLOSE_CHECKIN_BEFORE_DEP_MIN = 90    # Check-in closes 90 min before dep
AVG_CHECKIN_TIME = 5                 # Exponential service time mean (min)


# -------------------------------------------------------------------------
# LANDSIDE SERVICES
# -------------------------------------------------------------------------

# Toilets
LANDSIDE_N_TOILETS = 9
AVG_TOILET_TIME = 3                

# Bars
LANDSIDE_N_BARS = 3
AVG_BAR_TIME = 2

# Shops
AVG_SHOP_TIME = 5


# -------------------------------------------------------------------------
# SECURITY CHECK
# -------------------------------------------------------------------------

SECURITY_N_SERVERS = 5
AVG_SECURITY_TIME = 2               

# Soft deadline: passenger must go to security if time_to_dep < this
SECURITY_DEADLINE = 90

# -------------------------------------------------------------------------
# AIRSIDE SERVICES
# -------------------------------------------------------------------------

AIRSIDE_N_TOILETS = 4
AIRSIDE_N_BARS = 2

# -------------------------------------------------------------------------
# BOARDING / GATE OPERATIONS
# -------------------------------------------------------------------------

GATE_OPEN_BEFORE_DEP = 50            # Gate opens 50 min before departure
GATE_CLOSE_BEFORE_DEP = 10           # Gate closes 10 min before departure
AVG_BOARDING_TIME = 1                # Time per passenger (exponential)





