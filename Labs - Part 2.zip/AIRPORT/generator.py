import random
import string
import config as c

from flight import Flight
from traveler import Traveler
from companion import AccompanyingPerson
from event import Event
import measures

# --------------------------------
# Needs generation
# --------------------------------

def sample_needs_landside():
    return {
        "check_in": 1 if random.random() < c.P_CHECKIN else 0,
        "toilet": 1 if random.random() < c.P_TOILET_LANDSIDE else 0,
        "bar": 1 if random.random() < c.P_BAR else 0,
        "shop": 1 if random.random() < c.P_SHOP else 0
    }

def sample_needs_airside(landside_needs):
    already_used_toilet = landside_needs['toilet'] == 1

    if already_used_toilet:
        p_toilet = c.P_TOILET_AIRSIDE_IF_USED_LANDSIDE
    else:
        p_toilet = c.P_TOILET_AIRSIDE_IF_NOT_USED_LANDSIDE

    return {
        "toilet": 1 if random.random() < p_toilet else 0,
        "bar": 1 if random.random() < c.P_BAR else 0,
        "shop": 1 if random.random() < c.P_SHOP else 0
    }

# ---------------------------------
# ID generation
# ---------------------------------

def generate_flight_id():
    letters = ''.join(random.choices(string.ascii_uppercase, k=2))
    numbers = f"{random.randint(0, 9999):04d}"
    return letters + numbers

def passenger_id(flight_id, index):
    letters = flight_id[:2]
    return f"{letters}{index:03d}"

# ---------------------------------
# Daily flights generation
# ---------------------------------

def create_flight(dep_time, day_index):
    flight_id = generate_flight_id()
    f = Flight(flight_id, dep_time)

    f.absolute_departure_time = dep_time + day_index * c.DAY_LENGTH

    # Check-in times
    f.checkin_open_time  = f.absolute_departure_time - c.OPEN_CHECKIN_BEFORE_DEP_MIN
    f.checkin_close_time = f.absolute_departure_time - c.CLOSE_CHECKIN_BEFORE_DEP_MIN
    f.checkin_queue = []
    f.checkin_busy_until = 0

    # Gate times
    f.gate_open_time  = f.absolute_departure_time - c.GATE_OPEN_BEFORE_DEP
    f.gate_close_time = f.absolute_departure_time - c.GATE_CLOSE_BEFORE_DEP
    f.gate_queue = []
    f.gate_busy_until = 0

    return f

def generate_daily_flights(day_index):
    flights = []

    n_flights = random.randint(c.MIN_DAILY_FLIGHTS, c.MAX_DAILY_FLIGHTS)

    total_p = sum(p for _, _, p in c.FLIGHT_DISTRIBUTION)
    weights = [p / total_p for _, _, p in c.FLIGHT_DISTRIBUTION]

    for _ in range(n_flights):
        idx = random.choices(range(len(c.FLIGHT_DISTRIBUTION)), weights=weights)[0]
        start_t, end_t, _ = c.FLIGHT_DISTRIBUTION[idx]

        dep_time = random.randint(start_t, end_t)

        flights.append(create_flight(dep_time, day_index))

    flights.sort(key=lambda f: f.departure_time)

    return flights


# ----------------------------------
# Arrival time generation
# ----------------------------------

def generate_arrival_time(flight_dep_time):
    lower = flight_dep_time - c.START_ARRIVALS
    upper = flight_dep_time - c.END_ARRIVALS
    return random.uniform(lower, upper) 

# -----------------------------------
# Passenger generation
# -----------------------------------

def generate_passengers_for_flight(flight, simulator=None):
    """
    Generate a number of passengers for each flight
    """
    travelers = []

    # generate number of passengers
    n_pax = int(random.triangular(c.FLIGHT_CAPACITY['min'], c.FLIGHT_CAPACITY['max'], c.FLIGHT_CAPACITY['mode']))
    flight.n_passengers = n_pax

    # generate each passenger
    for i in range(1, n_pax + 1):  
        # build passenger id
        pax_id = passenger_id(flight.flight_id, i) 

        landside_needs = sample_needs_landside()
        airside_needs = sample_needs_airside(landside_needs)

        # create traveler
        t = Traveler(
            person_id = pax_id,
            flight_id = flight.flight_id,
            landside_needs = landside_needs,
            airside_needs = airside_needs
        )

        t.flight_ref = flight

        travelers.append(t)
        flight.add_passenger(t)
        simulator.measures.register_new_passenger()

        if simulator is not None:
            arrival_time = generate_arrival_time(flight.absolute_departure_time)
            simulator.schedule_event(
                Event(arrival_time, "ARRIVAL_AT_AIRPORT", data={"traveler": t})
            )
            simulator.measures.register_arrival_time(arrival_time)

    return travelers

def generate_companions(traveler):
    """
    Generate a random number of companions for each traveler.
    """
    n_comp = random.randint(0, c.MAX_COMPANIONS)
    companions = []

    for idx in range(1, n_comp + 1):
        comp_id = f"{traveler.person_id}-C{idx}"

        landside_needs = {
            "toilet": 1 if random.random() < c.P_TOILET_LANDSIDE else 0,
            "bar": 1 if random.random() < c.P_BAR else 0,
            "shop": 1 if random.random() < c.P_SHOP else 0
        }

        a = AccompanyingPerson(
            person_id = comp_id,
            group_id = traveler.person_id,
            landside_needs = landside_needs
        )

        companions.append(a)

    return companions
# -------------------------------------------
# DEBUG
# -------------------------------------------

def minutes_to_hhmm(minutes):
    day = int(minutes // 1440)  
    mins_in_day = int(minutes % 1440)
    
    hh = mins_in_day // 60
    mm = mins_in_day % 60
    
    return f"Day {day} — {hh:02d}:{mm:02d}"

def print_flights(flights):
    for f in flights:
        dep_hhmm = minutes_to_hhmm(f.departure_time)

# Time to departure
def time_to_departure(traveler: Traveler,now: float):
    flight: Flight = traveler.flight_ref
    return flight.absolute_departure_time - now

###
def compute_all_utilizations(sim):
    result = {}

    result["LANDSIDE_TOILET"] = sim.landside_toilet.compute_utilization()
    result["LANDSIDE_BAR"]    = sim.landside_bar.compute_utilization()
    result["LANDSIDE_SHOP"]   = sim.landside_shop.compute_utilization()

    result["AIRSIDE_TOILET"]  = sim.airside_toilet.compute_utilization()
    result["AIRSIDE_BAR"]     = sim.airside_bar.compute_utilization()
    result["AIRSIDE_SHOP"]    = sim.airside_shop.compute_utilization()

    return result