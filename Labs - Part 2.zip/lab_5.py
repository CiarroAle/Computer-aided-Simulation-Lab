import random
import math
import matplotlib.pyplot as plt
from scipy.stats import rv_continuous
import numpy as np

def sample_hyper_exp(p_list: list, lambda_list: list):
    """
    Generate a Hyper-Exponential random variable using the composition method.
    
    Input:
    - p_list: probabilities of selecting each exp component.
    - lambda_list: rate parameters (lambda_i) for each exp component.
    
    Output:
    - float: sample from the hyper-expponential distribution.
    """

    # Basic checks
    if len(p_list) != len(lambda_list):
        raise ValueError("p_list and lambda_list must have the same length.")
    
    if abs(sum(p_list) - 1.0) > 1e-8:
        raise ValueError("Probabilities p_list must sum to 1.")
    
    # Step 1: choose mixture component using Uniform(0, 1)
    u1 = random.random()
    cumulative = 0.0

    for i, p in enumerate(p_list):
        cumulative += p
        if u1 <= cumulative:
            chosen_index = i
            break

    lam = lambda_list[chosen_index]

    # Step 2: generate exponential sample using inverse transform
    u2 = random.random()
    x = -math.log(1 - u2) / lam

    return x

def sample_erlang(k: int, lam: float):
    """
    Generate an Erlang-k random variable using the convolution method.
    
    Input:
    - k: shape parameter (number of eponential phases).
    - lam: rate parameter for each exp component.
    
    Output:
    - float: sample from the Erlang(k, lam) distribution.
    """

    # Basic checks
    if k <= 0 or not isinstance(k, int):
        raise ValueError("k must be a positive integer.")
    
    if lam <= 0:
        raise ValueError("lambda must be positive.")
    
    x = 0.0

    # Sum k exponential random variable
    for _ in range(k):
        u = random.random()
        e = -math.log(1 - u) / lam          # exponential sample
        x += e
    
    return x

# Generate samples
samples_hyper = np.array([sample_hyper_exp(p_list=[0.5,0.5], lambda_list=[0.5,3.0])
                          for _ in range(20000)])

# Histogram + PDF
x_vals = np.linspace(0, np.percentile(samples_hyper, 99), 300)


# =====================================================
# ERLANG: THEORETICAL VS EMPIRICAL
# =====================================================

# Erlang parameters
k = 3
lam = 1.5
samples_erlang = np.array([sample_erlang(k, lam) for _ in range(20000)])

# Theoretical PDF
from scipy.stats import erlang
pdf_erlang = erlang.pdf(x_vals, k, scale=1/lam)

plt.figure(figsize=(7,4))
plt.hist(samples_erlang, bins=80, density=True, alpha=0.5, label="Empirical")
plt.plot(x_vals, pdf_erlang, 'r', linewidth=2, label="Theoretical PDF")
plt.title(f"Erlang(k={k}, λ={lam}) Distribution")
plt.xlabel("x")
plt.ylabel("Density")
plt.legend()
plt.grid(True)
plt.show()



def sample_pareto(x_m: float, alpha: float):
    """
    Generate a Pareto random variable using the inverse trasform method.
    
    Input:
    - x_m: scale parameter (minimum value).
    - alpha: shape parameter.
     
    Output:
    - float: sample from the Pareto(x_m, alpha) distribution.
    """

    # Basic checks
    if x_m <= 0:
        raise ValueError("x_m must be positive.")
    
    if alpha <= 0:
        raise ValueError("alpha must be positive.")
    
    u = random.random()

    # Inverse CDF
    x = x_m * (1 - u)**(-1.0 / alpha)

    return x

# =======================================================
# PARETO: THEORETICAL VS EMPIRICAL
# =======================================================

# Pareto parameters
x_m = 1.0
alpha = 10.0
samples_pareto = np.array([sample_pareto(x_m, alpha) for _ in range(20000)])

# Theoretical PDF
from scipy.stats import pareto
pdf_pareto = pareto.pdf(x_vals, alpha, scale=x_m)

plt.figure(figsize=(7,4))
plt.hist(samples_pareto, bins=80, density=True, alpha=0.5, label="Empirical")
plt.plot(x_vals, pdf_pareto, 'r', linewidth=2, label="Theoretical PDF")
plt.title(f"Pareto(x_m={x_m}, α={alpha}) Distribution")
plt.xlabel("x")
plt.ylabel("Density")
plt.legend()
plt.grid(True)
plt.show()


# ---------------------- #
# -------- TEST -------- #
# ---------------------- #

def test_hyper_exponential(p_list, lambda_list, n_samples=20000):
    """
    Test the hyper-exponential generator by comparing the empirical distribution 
    with the theretical PDF and theoretical mean.
    
    Input:
    - p_list: mixture probabilities. 
    - lambda_list: rate parameters for each exponential component.
    - n_samples: number of samples to generate.
    """

    # Step 1: generate samples
    samples = np.array([sample_hyper_exp(p_list, lambda_list)
                        for _ in range(n_samples)])
    
    # Step 2: empirical statistics
    empirical_mean = samples.mean()
    empirical_var = samples.var()

    # Step 3: theoretical statistics
    theo_mean = sum(p_list[i] * (1.0 / lambda_list[i])
                    for i in range(len(p_list)))
    
    ex2 = 2.0 * sum(
        p_list[i] * (1.0 / (lambda_list[i] ** 2)) for i in range(len(p_list))
    )
    theo_var = ex2 - theo_mean ** 2


    print("Hyper-Exponential Test")
    print(f"Empirical mean: {empirical_mean:.4f}")
    print(f"Theoretical mean: {theo_mean:.4f}")
    print(f"Empirical variance:  {empirical_var:.4f}")
    print(f"Theoretical variance:{theo_var:.4f}")  

    # CDF theoretical
    def F_theoretical(x):
        return 1.0 - sum(p_list[i] * math.exp(-lambda_list[i] * x)
                         for i in range(len(p_list))
                         )
    
    probs = [0.5, 0.9, 0.99]
    print("Check quantiles (empirical quantile vs theoretical CDF at that point):")
    for q in probs:
        x_q = np.quantile(samples, q)
        F_xq = F_theoretical(float(x_q))
        print(f"  q={q:4.2f}: empirical quantile x_q={x_q:.4f},  F_theoretical(x_q)={F_xq:.4f}")
    
    # Step 4: plot histogram + theoretical PDF
    x_max  =np.percentile(samples, 99.5)
    x_values = np.linspace(0, np.percentile(samples, 99.5), 100)

    # theoretical PDF
    pdf_vals = np.zeros_like(x_values)
    for p, lam in zip(p_list, lambda_list):
        pdf_vals += p * lam * np.exp(-lam * x_values)    

    plt.figure(figsize=(7, 4))
    plt.hist(samples, bins=100, density=True, alpha=0.5, label="Empirical histogram")
    plt.plot(x_values, pdf_vals, linewidth=2, label="Theoretical PDF")
    plt.title("Hyper-Exponential: Empirical vs Theoretical PDF")
    plt.xlabel("x")
    plt.ylabel("Density")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    # CDF empirica + CDF teorica (plot)
    samples_sorted = np.sort(samples)
    ecdf_vals = np.arange(1, n_samples + 1) / n_samples
    F_vals_theoretical = np.array([F_theoretical(x) for x in samples_sorted])

    plt.figure(figsize=(7, 4))
    plt.plot(samples_sorted, ecdf_vals, label="Empirical CDF")
    plt.plot(samples_sorted, F_vals_theoretical, linestyle="--", label="Theoretical CDF")
    plt.title("Hyper-Exponential: Empirical vs Theoretical CDF")
    plt.xlabel("x")
    plt.ylabel("CDF")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    return samples

p = [0.2, 0.3, 0.5]
lambdas = [1.0, 3.0, 5.0]

samples = test_hyper_exponential(p, lambdas)

def test_independence(generator, n_samples=50000):
    """
    Test the independence of samples generated from a given RNG.
    
    Input:
    - generator: function with no arguments that returns a random sample.
    - n_samples: number of samples to generate.
    
    Output:
    - numpy array: the generated sample sequence.
    """

    # Generate the sequence of random samples
    samples = np.array([generator() for _ in range(n_samples)])

    # Compute empirical mean and variance
    mean = samples.mean()
    var = samples.var()

    # Compute autocorrelation at different lags
    def autocorr_lag(lag):
        """Compute autocorrelation at a given lag."""
        cov = np.mean((samples[: -lag] - mean) * (samples[lag:] - mean))
        return cov / var
    
    lags = [1, 2, 5, 10, 20]

    
    print("Independence Test (Autocorrelation) ")
    for lag in lags:
        if lag < n_samples:
            ac = autocorr_lag(lag)
            print(f"Autocorrelation (lag={lag}): {ac:.6f}")
    
    # Scatter plot of X[n] vs X[n+1] 
    plt.figure(figsize=(6, 6))
    plt.scatter(samples[:-1], samples[1:], s=2, alpha=0.3)
    plt.title("Scatter plot: X[n] vs X[n+1]")
    plt.xlabel("X[n]")
    plt.ylabel("X[n+1]")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    return samples

gen = lambda: sample_hyper_exp(p, lambdas)
samples = test_independence(gen)

# ===================================================== #
# 
# ===================================================== #

def simulate_queue(arrival_generator, service_generator, n_customers=20000):
    """
    Simulate a single server queue, FIFO.
    Inputs: 
    - arrival_generator: function (without arguments) that generates an inter-arrival time
    - service_generator: function (without arguments) that generates an inter-arrival time
    - n_customers: number of clients to simulate.
    """
    
    t = 0.0                             # current time
    server_free_at = 0.0                # time when the server gets free

    wait_times = []
    system_times = []
    service_times = []
    inter_arrivals = []

    for _ in range(n_customers):
        # Generate inter-arrival and update arrival time
        ia = arrival_generator()
        t += ia
        inter_arrivals.append(ia)

        # Generate service time
        s = service_generator()
        service_times.append(s)

        # Compute starting service and waiting time
        start_service = max(t, server_free_at)
        wait = start_service - t
        wait_times.append(wait)

        # Time in system (waiting + service)
        system_times.append(wait + s)

        # Update server state
        server_free_at = start_service + s

    mean_ia = np.mean(inter_arrivals)
    mean_s = np.mean(service_times)

    # lam = 1/mean_interarrival, mu = 1/mean_service
    lam = 1.0 / mean_ia
    mu = 1.0 / mean_s
    rho = lam / mu

    return {
        "mean_wait": np.mean(wait_times),
        "mean_system": np.mean(system_times),
        "mean_service": mean_s,
        "mean_interarrival": mean_ia,
        "rho": rho,
        "wait_times": np.array(wait_times),
        "system_times": np.array(system_times),
        "inter_arrivals": np.array(inter_arrivals),
    }

# ===================================================
# PARAMETERS
# ===================================================

# case mean_service < mean_interarrival
target_mean_interarrival = 1.0          
mean_service = 0.8  

# Exponential service
def service_exp():
    return np.random.exponential(mean_service)

# Exponential arrival
def arrival_exp():
    return np.random.exponential(target_mean_interarrival)

# ==============================================================
# HYPER - EXPONENTIAL ARRIVALS (same mean, higher variance)
# ==============================================================

p_arr = [0.5, 0.5]
lambda_arr = [0.5,3.0]

# Compute the theoretical mean of the hyper - exponential
theo_mean_base = sum(p_arr[i] * (1.0 / lambda_arr[i]) for i in range(len(p_arr)))

# Scale factor
scale_factor = target_mean_interarrival / theo_mean_base

def arrival_hyper():
    return sample_hyper_exp(p_arr, lambda_arr) * scale_factor


results = {
    "Arrivals Exp (M/M/1)": simulate_queue(arrival_exp, service_exp),
    "Arrivals HyperExp": simulate_queue(arrival_hyper, service_exp),
}

# =======================================================
#  EXPERIMENTS: M/M/1 vs Hyper(M)/M/1
# =======================================================

for name, res in results.items():
    print(f"\n=== {name} ===")
    print(f"Mean inter-arrival time: {res['mean_interarrival']:.4f}")
    print(f"Mean service time:       {res['mean_service']:.4f}")
    print(f"Utilization rho:         {res['rho']:.4f}")
    print(f"Mean waiting time Wq:    {res['mean_wait']:.4f}")
    print(f"Mean system time W:      {res['mean_system']:.4f}")


# ===========================================================
# MEAN WAITING TIME (Exp vs HyperExp)
# ===========================================================

plt.figure(figsize=(7, 4))
labels = list(results.keys())
wq_values = [results[k]["mean_wait"] for k in labels]

plt.bar(labels, wq_values)
plt.ylabel("Mean waiting time Wq")
plt.title("Impatto della distribuzione degli ARRIVI (stessa media)")
plt.grid(True, axis="y")
plt.tight_layout()
plt.show()


# ===========================================================
# CDF INTER-ARRIVAL TIME (Exp vs HyperExp)
# ===========================================================

plt.figure(figsize=(7, 4))
for name, res in results.items():
    ia = np.sort(res["inter_arrivals"])
    ecdf = np.arange(1, len(ia) + 1) / len(ia)
    plt.plot(ia, ecdf, label=name)

plt.xlabel("Inter-arrival time")
plt.ylabel("CDF")
plt.title("Distribuzione degli inter-arrival: Exp vs HyperExp")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()