# file utility.py
import matplotlib.pyplot as plt
import numpy as np

def plot_total_populations(times, states,
                           smooth_window=8,
                           grad_threshold=0.003,
                           hold=20):
    """
    Plot total populations over time and detect steady-state start.
    A vertical dashed red line is drawn at the estimated steady-state time.
    """

    herb = np.array([s.herbivores.total() for s in states])
    carn = np.array([s.carnivores.total() for s in states])

    # Detect steady-state using herbivores by default
    idx = detect_steady_state(
        herb,
        smooth_window=smooth_window,
        grad_threshold=grad_threshold,
        hold=hold
    )

    # Plot
    plt.figure(figsize=(12,5))
    plt.plot(times, herb, label="Herbivores")
    plt.plot(times, carn, label="Carnivores")

    # Vertical dashed line if steady state is detected
    if idx is not None:
        ts_start = times[idx]
        plt.axvline(ts_start, color="red", ls="--", lw=2,
                    label=f"Steady-state start (t ≈ {ts_start:.1f})")

    plt.title("Population Dynamics: Total Populations")
    plt.xlabel("Time")
    plt.ylabel("Population size")
    plt.legend()
    plt.grid(True)
    plt.show()

def plot_herbivore_structure(times, states):
    """
    Plot herbivore demographic structure (males, females, pregnant stages).
    """
    Hm = [s.herbivores.males for s in states]
    Hf = [s.herbivores.non_pregnant_females for s in states]
    H1 = [s.herbivores.pregnant_stage1 for s in states]
    H2 = [s.herbivores.pregnant_stage2 for s in states]


    plt.figure(figsize=(8, 4))
    plt.plot(times, Hm, label="H males")
    plt.plot(times, Hf, label="H non-preg females")
    plt.plot(times, H1, label="H pregnant stage 1")
    plt.plot(times, H2, label="H pregnant stage 2")
    plt.xlabel("Time")
    plt.ylabel("Population count")
    plt.title("Herbivore Demographic Structure")
    plt.legend()
    plt.grid(True)
    plt.show()

def plot_carnivore_structure(times, states):
    """
    Plot carnivore demographic structure (males, females, pregnant stages).
    """
    Cm = [s.carnivores.males for s in states]
    Cf = [s.carnivores.non_pregnant_females for s in states]
    C1 = [s.carnivores.pregnant_stage1 for s in states]
    C2 = [s.carnivores.pregnant_stage2 for s in states]


    plt.figure(figsize=(8, 4))
    plt.plot(times, Cm, label="C males")
    plt.plot(times, Cf, label="C non-preg females")
    plt.plot(times, C1, label="C pregnant stage 1")
    plt.plot(times, C2, label="C pregnant stage 2")
    plt.xlabel("Time")
    plt.ylabel("Population count")
    plt.title("Carnivore Demographic Structure")
    plt.legend()
    plt.grid(True)
    plt.show()

def detect_steady_state(ts, 
                        smooth_window=10, 
                        grad_threshold=0.01, 
                        hold=10):
    """
    Detect steady state by identifying when the smoothed time series 
    stops changing significantly.

    Parameters:
    - ts: list or array, time series (e.g., population over time)
    - smooth_window: window for moving average smoothing
    - grad_threshold: threshold on gradient magnitude for 'stability'
    - hold: consecutive points needed to declare steady-state

    Returns:
    - index where steady-state begins, or None if not found
    """

    ts = np.asarray(ts, dtype=float)

    # --- Smooth the series to reduce noise ---
    kernel = np.ones(smooth_window) / smooth_window
    smooth = np.convolve(ts, kernel, mode="same")

    # --- Compute gradient of smoothed curve ---
    grad = np.abs(np.gradient(smooth))

    # --- Detect region of sustained low gradients ---
    count = 0
    for i in range(len(ts)):
        if grad[i] < grad_threshold:
            count += 1
            if count >= hold:
                return i - hold + 1  # starting index of steady region
        else:
            count = 0

    return None




def summary_statistics(times, states):
    """
    Print simple statistical summary of herbivore and carnivore populations.
    """
    import numpy as np


    H = np.array([s.herbivores.total() for s in states])
    C = np.array([s.carnivores.total() for s in states])


    print("=== SUMMARY STATISTICS ===")
    print(f"Simulation time: {times[-1]:.3f}\n")


    print("Herbivores:")
    print(f" Mean: {H.mean():.2f}")
    print(f" Min: {H.min()}")
    print(f" Max: {H.max()}\n")


    print("Carnivores:")
    print(f" Mean: {C.mean():.2f}")
    print(f" Min: {C.min()}")
    print(f" Max: {C.max()}\n")



