# file main.py
from params import SpeciesParameters, InteractionParameters, ModelParameters
from state import SpeciesPopulation, EcosystemState
from simulator import GillespieSimulator
from analysis import (
    run_multiple_simulations,
    summarize_results
)
import matplotlib.pyplot as plt
import numpy as np


from events_basic import (
    HerbivoreNaturalDeath, 
    CarnivoreNaturalDeath, 
    Predation, 
    HerbivoreGestationStage1, 
    HerbivoreGestationStage2, 
    HerbivoreConflict, 
    HerbivoreReproduction, 
    CarnivoreConflict, 
    CarnivoreGestationStage1, 
    CarnivoreGestationStage2, 
    CarnivoreReproduction
)

from utility import (
    plot_total_populations,
    plot_herbivore_structure,
    plot_carnivore_structure,
    summary_statistics
)

events = [
    HerbivoreNaturalDeath(),
    CarnivoreNaturalDeath(),
    Predation(),
    HerbivoreReproduction(),
    HerbivoreConflict(),
    HerbivoreGestationStage1(),
    HerbivoreGestationStage2(),
    CarnivoreConflict(),
    CarnivoreReproduction(),
    CarnivoreGestationStage1(),
    CarnivoreGestationStage2()
]

def build_default_parameters() -> ModelParameters:
    carn_params = SpeciesParameters(
        birth_rate=0.02,
        death_rate=0.04,
        conflict_rate=0.01,    
        gestation_rate=2,
        max_lifespan_rate=0.0
    )
    herb_params = SpeciesParameters(
        birth_rate=0.008,
        death_rate=0.02,
        conflict_rate=0.005,
        gestation_rate=2,
        max_lifespan_rate=0.0
    )
    inter_params = InteractionParameters(
        predation_rate = 0.0021,                        # baseline 0.0004
        herbivore_comp_threshold=400,
        carnivore_comp_ratio_threshold=3.0,
        herbivore_death_multiplier=1.2,
        herbivore_birth_multiplier=0.5,             
        carnivore_death_multiplier=1.2,
        carnivore_birth_multiplier=0.5       
    )

    return ModelParameters(
        carnivore=carn_params,
        herbivore=herb_params,
        interaction=inter_params,
        t_max = 50,
        max_events=5000
    )

def build_initial_state() -> EcosystemState:
    carnivores = SpeciesPopulation(
        males=15, 
        non_pregnant_females=25, 
        pregnant_stage1=0, 
        pregnant_stage2=0
        )
    herbivores = SpeciesPopulation(
        males=80,            
        non_pregnant_females=120, 
        pregnant_stage1=0, 
        pregnant_stage2=0
        )
    state = EcosystemState(carnivores=carnivores, 
                           herbivores=herbivores, 
                           time=0.0)
    return state


def main():
    params = build_default_parameters()
    state = build_initial_state()

    sim = GillespieSimulator(state=state, params=params, events=events)
    times, states = sim.run()

    # =================================================
    # FINAL STATE SUMMARY
    # =================================================

    print("\n" + "="*50)
    print("                FINAL STATE")
    print("="*50)

    final = states[-1]

    print(f"Simulation end time: {times[-1]:.3f}\n")

    # Herbivores
    Hf  = final.herbivores.non_pregnant_females
    H1  = final.herbivores.pregnant_stage1
    H2  = final.herbivores.pregnant_stage2
    Hm  = final.herbivores.males
    HtotF = Hf + H1 + H2

    print("HERBIVORES")
    print(f"  Total population       : {final.herbivores.total()}")
    print(f"    Males                : {Hm}")
    print(f"    Non-pregnant females : {Hf}")
    print(f"    Pregnant stage 1     : {H1}")
    print(f"    Pregnant stage 2     : {H2}")

    if HtotF > 0:
        print("  Female composition (%):")
        print(f"    Non-pregnant : {Hf / HtotF * 100:6.2f}%")
        print(f"    Stage 1      : {H1 / HtotF * 100:6.2f}%")
        print(f"    Stage 2      : {H2 / HtotF * 100:6.2f}%")
    else:
        print("  No females present.")

    # Carnivores
    Cf  = final.carnivores.non_pregnant_females
    C1  = final.carnivores.pregnant_stage1
    C2  = final.carnivores.pregnant_stage2
    Cm  = final.carnivores.males
    CtotF = Cf + C1 + C2

    print("\nCARNIVORES")
    print(f"  Total population       : {final.carnivores.total()}")
    print(f"    Males                : {Cm}")
    print(f"    Non-pregnant females : {Cf}")
    print(f"    Pregnant stage 1     : {C1}")
    print(f"    Pregnant stage 2     : {C2}")

    if CtotF > 0:
        print("  Female composition (%):")
        print(f"    Non-pregnant : {Cf / CtotF * 100:6.2f}%")
        print(f"    Stage 1      : {C1 / CtotF * 100:6.2f}%")
        print(f"    Stage 2      : {C2 / CtotF * 100:6.2f}%")
    else:
        print("  No females present.")

    # ============================================ #
    # PLOT FUNCTIONS
    # ============================================ #
    
    # estrai la serie degli erbivori
    plot_total_populations(times, states)
    plot_herbivore_structure(times, states)
    plot_carnivore_structure(times, states)
    summary_statistics(times, states)

    # =========================================================
    # MULTIPLE SIMULATION ANALYSIS (Monte Carlo)
    # =========================================================
    print("\nRunning Monte Carlo analysis...\n")

    results = run_multiple_simulations(
        n_rep=50,                     # number of replications
        params=params,
        events=events,
        initial_state_builder=build_initial_state,
        thinning=10                  # reduces autocorrelation
    )

    summarize_results(results)



if __name__ == "__main__":
    main()

