# file simulator.py
import math
from dataclasses import dataclass
import random
from typing import List
from state import EcosystemState, SpeciesPopulation
from params import ModelParameters
from events import Event


@dataclass
class GillespieSimulator:
    """
    Simulator fo a continuous-time Markov process using Gillespie Method.
    """

    state: EcosystemState
    params: ModelParameters
    events: List[Event]
    seed: int = 1

    def __post_init__(self):
        self.rng = random.Random(self.seed)          # initialize RNG

    def step(self, event_counts=None) -> bool:
        """
        Perform one Gillespie event.
        Return False if no event can occur (absorbing state) 
        or if time/max events exceeded.
        """

        # 1. Compute propensities
        propensities = []
        total_rate = 0.0

        for event in self.events:
            a = event.get_propensity(self.state, self.params)
            propensities.append(a)
            total_rate += a

        if total_rate == 0.0:                           # absorbing state
            return False            
        
        # 2. Waiting time samples (exponential)
        u1 = self.rng.random()
        tau = -math.log(u1) / total_rate
        self.state.time += tau

        if self.state.time > self.params.t_max:         # time limit exceeded
            return False
        
        # 3. Choose the event
        u2 = self.rng.random() * total_rate
        cumulative = 0.0

        chosen_event = None
        for event, a in zip(self.events, propensities):
            cumulative += a
            if cumulative >= u2:
                chosen_event = event
                break

        if chosen_event is None:                        # check
            return False
        
        # 4. Apply state transition
        chosen_event.apply(self.state, self.params, self.rng)

        # 5. Update event counter if provided
        if event_counts is not None:
            name = chosen_event.name()
            event_counts[name] = event_counts.get(name, 0) + 1

        return True
    
    def run(self, return_counts: bool = False):
        """
        Run the simulation until:
        - no more events can occur
        - or time exceeds params.t_max
        - or max number of events reached.
        
        Returns (times, states, counts).
        """
        times = [self.state.time]
        states = [self.copy_state()]

        event_counts = {} if return_counts else None

        for _ in range(self.params.max_events):
            can_continue = self.step(event_counts=event_counts)
            if not can_continue:
                break

            times.append(self.state.time)
            states.append(self.copy_state())

        if return_counts:
            return times, states, event_counts
        else:
            return times, states
    
    def copy_state(self):
        """
        Ritorna una copia indipendente dell'EcosystemState.
        Evita che i risultati vengano modificati dagli eventi successivi.
        """

        return EcosystemState(
            carnivores = SpeciesPopulation(
                males=self.state.carnivores.males,
                non_pregnant_females=self.state.carnivores.non_pregnant_females,
                pregnant_stage1=self.state.carnivores.pregnant_stage1,
                pregnant_stage2 = self.state.carnivores.pregnant_stage2
            ),
            herbivores = SpeciesPopulation(
                males=self.state.herbivores.males,
                non_pregnant_females=self.state.herbivores.non_pregnant_females,
                pregnant_stage1=self.state.herbivores.pregnant_stage1,
                pregnant_stage2=self.state.herbivores.pregnant_stage2
            ),
            time=self.state.time,
            herbivore_competition=self.state.herbivore_competition,
            carnivore_competition=self.state.carnivore_competition,
        )
