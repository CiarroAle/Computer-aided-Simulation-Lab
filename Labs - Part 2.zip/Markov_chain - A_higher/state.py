# file state.py
from dataclasses import dataclass

@dataclass
class SpeciesPopulation:
    """
    Aggregated state for a species: counts of individuals by role.
    """
    males: int
    non_pregnant_females: int
    pregnant_stage1: int
    pregnant_stage2: int 

    def total(self) -> int:
        """Total individuals for this species."""
        return self.males + self.non_pregnant_females + self.pregnant_stage1 + self.pregnant_stage2

@dataclass
class EcosystemState:
    """
    Full state at a given time.
    """
    carnivores: SpeciesPopulation
    herbivores: SpeciesPopulation

    time: float = 0.0

    # competition flags 
    herbivore_competition: bool = False         # when there're to herbivores
    carnivore_competition: bool = False         # when there're not enough herbivores

    def update_competition_flags(self, params) -> None:
        """
        Update competition flags based on current populations and thresholds.
        """

        H = self.herbivores.total()
        C = self.carnivores.total()

        # Herbivore competition: too many herbivores
        self.herbivore_competition = H > params.interaction.herbivore_comp_threshold

        # Carnivore competition: too few herbivores per carnivore
        if C > 0:
            ratio = H/C
            self.carnivore_competition = ratio < params.interaction.carnivore_comp_ratio_threshold
        else:   # case with denominator equal to zero
            self.carnivore_competition = False  

        