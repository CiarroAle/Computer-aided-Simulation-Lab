# file events.py
from state import EcosystemState
from params import ModelParameters

class Event:
    """
    Base class for all events in the ecosystem:
    - get_propensity()
    - apply()
    """

    def get_propensity(self, state: EcosystemState, params: ModelParameters) -> float:
        """Return the rate (propensity) of this event."""
        return 0.0
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng) -> None:
        """Apply the effect of the event to the state."""
        pass

    def name(self) -> str:
        """Human-readable name."""
        return self.__class__.__name__
    
