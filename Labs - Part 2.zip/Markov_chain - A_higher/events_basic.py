# file event_basic.py
from events import Event
from state import EcosystemState
from params import ModelParameters


class HerbivoreNaturalDeath(Event):
    def get_propensity(self, state: EcosystemState, params: ModelParameters):
        H = state.herbivores.total()
        if H == 0:
            return 0.0
        
        base = params.herbivore.death_rate

        # competition --> increased mortality
        if state.herbivore_competition:
            base *= params.interaction.herbivore_death_multiplier

        return H * base
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):
        """Remove one random herbivore (male/female/pregnant)."""
        Hm = state.herbivores.males
        Hf = state.herbivores.non_pregnant_females
        Hp1 = state.herbivores.pregnant_stage1
        Hp2 = state.herbivores.pregnant_stage2

        total = Hm + Hf + Hp1 + Hp2
        if total == 0:
            return
        
        r = rng.random() * total

        if r < Hm:
            state.herbivores.males -= 1
        elif r < Hm + Hf:
            state.herbivores.non_pregnant_females -= 1
        elif r < Hm + Hf + Hp1:
            state.herbivores.pregnant_stage1 -= 1
        else:
            state.herbivores.pregnant_stage2 -= 1

        state.update_competition_flags(params)

class CarnivoreNaturalDeath(Event):

    def get_propensity(self, state: EcosystemState, params: ModelParameters):
        C = state.carnivores.total()
        if C == 0:
            return 0.0
        
        base = params.carnivore.death_rate

        # competition --> increased mortality
        if state.carnivore_competition:
            base *= params.interaction.carnivore_death_multiplier

        return C * base
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):
        Cm = state.carnivores.males
        Cf = state.carnivores.non_pregnant_females
        Cp1 = state.carnivores.pregnant_stage1
        Cp2 = state.carnivores.pregnant_stage2

        total = Cm + Cf + Cp1 + Cp2
        if total == 0:
            return
        
        r = rng.random() * total

        if r < Cm:
            state.carnivores.males -= 1
        elif r < Cm + Cf:
            state.carnivores.non_pregnant_females -= 1
        elif r < Cm + Cf + Cp1:
            state.carnivores.pregnant_stage1 -= 1
        else:
            state.carnivores.pregnant_stage2 -= 1

        state.update_competition_flags(params)

class Predation(Event):

    def get_propensity(self, state: EcosystemState, params: ModelParameters):
        C = state.carnivores.total()
        H = state.herbivores.total()

        if C == 0 or H == 0:
            return 0.0
        
        return params.interaction.predation_rate * C * H
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):
        """Carnivore kills a random herbivore."""
        Hm = state.herbivores.males
        Hf = state.herbivores.non_pregnant_females
        Hp1 = state.herbivores.pregnant_stage1
        Hp2 = state.herbivores.pregnant_stage2

        total = Hm + Hf + Hp1 + Hp2
        if total == 0:
            return
        
        r = rng.random() * total

        if r < Hm:
            state.herbivores.males -= 1
        elif r < Hm + Hf:
            state.herbivores.non_pregnant_females -= 1
        elif r < Hm + Hf + Hp1:
            state.herbivores.pregnant_stage1 -= 1
        else:
            state.herbivores.pregnant_stage2 -= 1

        state.update_competition_flags(params)

class HerbivoreReproduction(Event):
    
    def get_propensity(self, state: EcosystemState, params: ModelParameters):
        
        M = state.herbivores.males
        F = state.herbivores.non_pregnant_females

        if M == 0 or F == 0:
            return 0.0
        
        rate = params.herbivore.birth_rate

        # competition reduces birth
        if state.herbivore_competition:
            rate *= params.interaction.herbivore_birth_multiplier

        return rate * M * F
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):
        """One non-pregnant female becomes pregnant."""
        
        if state.herbivores.non_pregnant_females > 0:
            state.herbivores.non_pregnant_females -= 1
            state.herbivores.pregnant_stage1 += 1 

        state.update_competition_flags(params)

class CarnivoreReproduction(Event):

    def get_propensity(self, state: EcosystemState, params: ModelParameters):

        M = state.carnivores.males
        F = state.carnivores.non_pregnant_females

        if M == 0 or F == 0:
            return 0.0
        
        rate = params.carnivore.birth_rate

        # competition reduces birth
        if state.carnivore_competition:
            rate *= params.interaction.carnivore_birth_multiplier

        return rate * M * F
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):
        """One non-pregnant female becomes pregnant."""
        
        if state.carnivores.non_pregnant_females > 0:
            state.carnivores.non_pregnant_females -= 1
            state.carnivores.pregnant_stage1 += 1

        state.update_competition_flags(params)

class HerbivoreGestationStage1(Event):

    def get_propensity(self, state: EcosystemState, params: ModelParameters):

        P1 = state.herbivores.pregnant_stage1

        if P1 == 0:
            return 0.0
        
        return params.herbivore.gestation_rate * P1
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):

        state.herbivores.pregnant_stage1 -= 1
        state.herbivores.pregnant_stage2 += 1
        state.update_competition_flags(params)

class HerbivoreGestationStage2(Event):
    
    def get_propensity(self, state: EcosystemState, params: ModelParameters):

        P2 = state.herbivores.pregnant_stage2
        if P2 == 0:
            return 0.0
        
        return params.herbivore.gestation_rate * P2 
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):

        state.herbivores.pregnant_stage2 -= 1
        state.herbivores.non_pregnant_females += 1

        if rng.random() < 0.5:
            state.herbivores.males += 1
        else:
            state.herbivores.non_pregnant_females += 1

        state.update_competition_flags(params)

class CarnivoreGestationStage1(Event):

    def get_propensity(self, state: EcosystemState, params: ModelParameters):

        P1 = state.carnivores.pregnant_stage1

        if P1 == 0:
            return 0.0
        
        return params.carnivore.gestation_rate * P1
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):

        state.carnivores.pregnant_stage1 -= 1
        state.carnivores.pregnant_stage2 += 1
        state.update_competition_flags(params)

class CarnivoreGestationStage2(Event):
    
    def get_propensity(self, state: EcosystemState, params: ModelParameters):

        P2 = state.carnivores.pregnant_stage2
        if P2 == 0:
            return 0.0
        
        return params.carnivore.gestation_rate * P2 
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):

        state.carnivores.pregnant_stage2 -= 1
        state.carnivores.non_pregnant_females += 1

        if rng.random() < 0.5:
            state.carnivores.males += 1
        else:
            state.carnivores.non_pregnant_females += 1

        state.update_competition_flags(params)
        
class HerbivoreConflict(Event):

    def get_propensity(self, state: EcosystemState, params: ModelParameters):

        M = state.herbivores.males
        F = state.herbivores.non_pregnant_females

        if M + F < 2:
            return 0.0
        
        rate = params.herbivore.conflict_rate

        return rate * (M*(M-1)/2 + F*(F-1)/2)
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):

        # decide sex of group involved
        M = state.herbivores.males
        F = state.herbivores.non_pregnant_females

        pool_m = M*(M-1)/2
        pool_f = F*(F-1)/2
        total = pool_m + pool_f

        r = rng.random() * total

        if r < pool_m and M > 0:
            state.herbivores.males -= 1         # male dies
        else:
            if F > 0:
                state.herbivores.non_pregnant_females -= 1

        state.update_competition_flags(params)

class CarnivoreConflict(Event):

    def get_propensity(self, state: EcosystemState, params: ModelParameters):

        M = state.carnivores.males
        F = state.carnivores.non_pregnant_females

        if M + F < 2:
            return 0.0
        
        rate = params.carnivore.conflict_rate

        return rate * (M*(M-1)/2 + F*(F-1)/2)
    
    def apply(self, state: EcosystemState, params: ModelParameters, rng):

        # decide sex of group involved
        M = state.carnivores.males
        F = state.carnivores.non_pregnant_females

        pool_m = M*(M-1)/2
        pool_f = F*(F-1)/2
        total = pool_m + pool_f

        r = rng.random() * total

        if r < pool_m and M > 0:
            state.carnivores.males -= 1                         # male dies
        else:
            if F > 0:
                state.carnivores.non_pregnant_females -= 1      # female dies

        state.update_competition_flags(params)