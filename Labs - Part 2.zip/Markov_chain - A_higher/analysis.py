# file analysis.py
import numpy as np
from utility import detect_steady_state
from simulator import GillespieSimulator
from scipy.stats import norm


# ===================================================
# Female structure
# ===================================================

def female_composition_single_run(states, steady_idx, thinning=10, species="herbivore"):
    """
    Extract average female composition (non-pregnant, stage1, stage2)
    during steady-state for ONE simulation.
    """

    # Select steady-state portion
    ss_states = states[steady_idx::thinning]

    np_list = []
    s1_list = []
    s2_list = []

    for s in ss_states:

        if species == "herbivore":
            spec = s.herbivores
        else:
            spec = s.carnivores

        np_f = spec.non_pregnant_females
        s1_f = spec.pregnant_stage1
        s2_f = spec.pregnant_stage2

        total = np_f + s1_f + s2_f
        if total == 0:
            continue

        np_list.append(np_f / total)
        s1_list.append(s1_f / total)
        s2_list.append(s2_f / total)

        return {
            "np": np.mean(np_list),
            "s1": np.mean(s1_list),
            "s2": np.mean(s2_list)
        }
    
# ===================================================
# Run multiple simulations
# ===================================================

def run_multiple_simulations(n_rep, params, events, initial_state_builder, thinning=10):

    """
    Run N independent simulations and collect steady-state statistics.

    Parameters:
        n_rep : number of replications
        params : ModelParameters
        events : list of Event objects
        initial_state_builder : take 1 sample every <thinning> steps in steady-state.

    Returns:
        dict with arrays of statistics:
        {
            "herb_mean": array,
            "carn_mean": array,
            "steady_state": array
        }
    """

    herb_means = []
    carn_means = []
    steady_times = []
    female_comp = []
    herb_death_fractions = []
    carn_death_fractions = []

    for r in range(n_rep):
        # Fresh initial state for each run
        state = initial_state_builder()
        sim = GillespieSimulator(state, params, events, seed=r + 1)

        times, states, counts = sim.run(return_counts=True)

        # --- Extract time series ---
        H = np.array([s.herbivores.total() for s in states])
        C = np.array([s.carnivores.total() for s in states])

        # --- Detect steady-state index ---
        idx = detect_steady_state(H)
        if idx is None:
            idx = int(len(H) * 0.7)
        
        steady_times.append(times[idx])

        # Thinning to reduce autocorrelation
        H_steady = H[idx::thinning]
        C_steady = C[idx::thinning]

        herb_means.append(np.mean(H_steady))
        carn_means.append(np.mean(C_steady))

        comp_h = female_composition_single_run(states, idx, thinning, species="herbivore")
        comp_c = female_composition_single_run(states, idx, thinning, species="carnivore")

        female_comp.append({
            "herb": comp_h,
            "carn": comp_c
        })

        # ---- Decomposition of causes of death ----
        # Herbivores: natural + conflict + predation
        H_nat  = counts.get("HerbivoreNaturalDeath", 0)
        H_conf = counts.get("HerbivoreConflict", 0)
        H_pred = counts.get("Predation", 0)
        H_tot  = H_nat + H_conf + H_pred

        if H_tot > 0:
            herb_death_fractions.append({
                "nat":  H_nat  / H_tot,
                "conf": H_conf / H_tot,
                "pred": H_pred / H_tot,
            })

        # Carnivores: natural + conflict (no predation on them)
        C_nat  = counts.get("CarnivoreNaturalDeath", 0)
        C_conf = counts.get("CarnivoreConflict", 0)
        C_tot  = C_nat + C_conf

        if C_tot > 0:
            carn_death_fractions.append({
                "nat":  C_nat  / C_tot,
                "conf": C_conf / C_tot,
            })

    return {
        "herb_mean": np.array(herb_means),
        "carn_mean": np.array(carn_means),
        "steady_times": np.array(steady_times),
        "female_comp": female_comp,
        "herb_death_fractions": herb_death_fractions,
        "carn_death_fractions": carn_death_fractions
    }

# ============================================================
# Compute confidence intervals
# ============================================================

def confidence_interval(values, confidence=0.95):
    """
    Compute mean, variance and CI for a sample of independent observations.
    """
    n = len(values)
    mean = np.mean(values)
    var = np.var(values, ddof=1)
    std = np.sqrt(var)

    # normal approximation (OK for n >= 20)
    z = 1.96 if confidence == 0.95 else 1.64    # extend if need

    ci_low = mean - z * std / np.sqrt(n)
    ci_high = mean + z * std / np.sqrt(n)

    return mean, var, (ci_low, ci_high)

# ===========================================================
# High-level summary function
# ===========================================================

def summarize_results(results):
    """
    Print a clean statistical summary from run_multiple_simulations(). 
    """

    herb = results["herb_mean"]
    carn = results["carn_mean"]
    ts = results["steady_times"]

    print("\n" + "="*60)
    print("         STEADY-STATE STATISTICAL SUMMARY")
    print("\n" + "="*60)

    # Herbivores
    h_mean, h_var, (h_low, h_high) = confidence_interval(herb)
    print("\nHerbivores steady-state population:")
    print(f"  Mean       : {h_mean:.2f}")
    print(f"  Variance   : {h_var:.2f}")
    print(f"  95% CI     : [{h_low:.2f}, {h_high:.2f}]")

    # Carnivores
    c_mean, c_var, (c_low, c_high) = confidence_interval(carn)
    print("\nCarnivores steady-state population:")
    print(f"  Mean       : {c_mean:.2f}")
    print(f"  Variance   : {c_var:.2f}")
    print(f"  95% CI     : [{c_low:.2f}, {c_high:.2f}]")

    # Time to reach steady-state
    t_mean, t_var, (t_low, t_high) = confidence_interval(ts)
    print("\nTime to reach steady-state (detected):")
    print(f"  Mean       : {t_mean:.2f}")
    print(f"  Variance   : {t_var:.2f}")
    print(f"  95% CI     : [{t_low:.2f}, {t_high:.2f}]")

    print("="*60 + "\n")  

    # female compositions
    fc_h = [x["herb"] for x in results["female_comp"]]

    np_vals = np.array([d["np"] for d in fc_h])
    s1_vals = np.array([d["s1"] for d in fc_h])
    s2_vals = np.array([d["s2"] for d in fc_h])

    np_mean, np_var, (np_low, np_high) = confidence_interval(np_vals)
    s1_mean, s1_var, (s1_low, s1_high) = confidence_interval(s1_vals)
    s2_mean, s2_var, (s2_low, s2_high) = confidence_interval(s2_vals)

    print("\nHERBIVORE FEMALE COMPOSITION (Steady-State)")
    print("------------------------------------------------------------")

    print(f"Non-pregnant females:")
    print(f"  Mean (%)     : {np_mean*100:6.2f}")
    print(f"  Variance     : {np_var:.6f}")
    print(f"  Std dev      : {np.sqrt(np_var):.6f}")
    print(f"  95% CI (%)   : [{np_low*100:6.2f}, {np_high*100:6.2f}]")
    print()

    print(f"Pregnant Stage 1:")
    print(f"  Mean (%)     : {s1_mean*100:6.2f}")
    print(f"  Variance     : {s1_var:.6f}")
    print(f"  Std dev      : {np.sqrt(s1_var):.6f}")
    print(f"  95% CI (%)   : [{s1_low*100:6.2f}, {s1_high*100:6.2f}]")
    print()

    print(f"Pregnant Stage 2:")
    print(f"  Mean (%)     : {s2_mean*100:6.2f}")
    print(f"  Variance     : {s2_var:.6f}")
    print(f"  Std dev      : {np.sqrt(s2_var):.6f}")
    print(f"  95% CI (%)   : [{s2_low*100:6.2f}, {s2_high*100:6.2f}]")
    print("------------------------------------------------------------\n")

    print("\nCARNIVORE FEMALE COMPOSITION (Steady-State)")
    print("------------------------------------------------------------")

    fc_c = [x["carn"] for x in results["female_comp"]]

    np_vals = np.array([d["np"] for d in fc_c])
    s1_vals = np.array([d["s1"] for d in fc_c])
    s2_vals = np.array([d["s2"] for d in fc_c])

    np_mean, np_var, (np_low, np_high) = confidence_interval(np_vals)
    s1_mean, s1_var, (s1_low, s1_high) = confidence_interval(s1_vals)
    s2_mean, s2_var, (s2_low, s2_high) = confidence_interval(s2_vals)

    print(f"Non-pregnant females:")
    print(f"  Mean (%)     : {np_mean*100:6.2f}")
    print(f"  Variance     : {np_var:.6f}")
    print(f"  Std dev      : {np.sqrt(np_var):.6f}")
    print(f"  95% CI (%)   : [{np_low*100:6.2f}, {np_high*100:6.2f}]")
    print()

    print(f"Pregnant Stage 1:")
    print(f"  Mean (%)     : {s1_mean*100:6.2f}")
    print(f"  Variance     : {s1_var:.6f}")
    print(f"  Std dev      : {np.sqrt(s1_var):.6f}")
    print(f"  95% CI (%)   : [{s1_low*100:6.2f}, {s1_high*100:6.2f}]")
    print()

    print(f"Pregnant Stage 2:")
    print(f"  Mean (%)     : {s2_mean*100:6.2f}")
    print(f"  Variance     : {s2_var:.6f}")
    print(f"  Std dev      : {np.sqrt(s2_var):.6f}")
    print(f"  95% CI (%)   : [{s2_low*100:6.2f}, {s2_high*100:6.2f}]")
    print("------------------------------------------------------------\n")

    # =====================================================
    # Decomposition of causes of death
    # =====================================================

    # Herbivores: natural, conflict, predation
    hdf = results["herb_death_fractions"]
    if len(hdf) > 0:
        nat_vals  = np.array([x["nat"]  for x in hdf])
        conf_vals = np.array([x["conf"] for x in hdf])
        pred_vals = np.array([x["pred"] for x in hdf])

        nat_mean, nat_var, (nat_low, nat_high)   = confidence_interval(nat_vals)
        conf_mean, conf_var, (conf_low, conf_high) = confidence_interval(conf_vals)
        pred_mean, pred_var, (pred_low, pred_high) = confidence_interval(pred_vals)

        print("\nHERBIVORE CAUSES OF DEATH (fractions over all deaths)")
        print("------------------------------------------------------------")
        print(f"Natural death : {nat_mean*100:6.2f}%   Var={nat_var:.6f}   CI=[{nat_low*100:6.2f}%, {nat_high*100:6.2f}%]")
        print(f"Conflicts     : {conf_mean*100:6.2f}%   Var={conf_var:.6f}   CI=[{conf_low*100:6.2f}%, {conf_high*100:6.2f}%]")
        print(f"Predation     : {pred_mean*100:6.2f}%   Var={pred_var:.6f}   CI=[{pred_low*100:6.2f}%, {pred_high*100:6.2f}%]")
    else:
        print("\nHERBIVORE CAUSES OF DEATH: no deaths observed in runs.")

    # Carnivores: natural, conflict
    cdf = results["carn_death_fractions"]
    if len(cdf) > 0:
        nat_vals  = np.array([x["nat"]  for x in cdf])
        conf_vals = np.array([x["conf"] for x in cdf])

        nat_mean, nat_var, (nat_low, nat_high)   = confidence_interval(nat_vals)
        conf_mean, conf_var, (conf_low, conf_high) = confidence_interval(conf_vals)

        print("\nCARNIVORE CAUSES OF DEATH (fractions over all deaths)")
        print("------------------------------------------------------------")
        print(f"Natural death : {nat_mean*100:6.2f}%   Var={nat_var:.6f}   CI=[{nat_low*100:6.2f}%, {nat_high*100:6.2f}%]")
        print(f"Conflicts     : {conf_mean*100:6.2f}%   Var={conf_var:.6f}   CI=[{conf_low*100:6.2f}%, {conf_high*100:6.2f}%]")
    else:
        print("\nCARNIVORE CAUSES OF DEATH: no deaths observed in runs.")



